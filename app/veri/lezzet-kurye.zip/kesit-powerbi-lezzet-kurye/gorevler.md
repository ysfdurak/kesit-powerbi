# Lezzet Kurye · görevler

Her görevi Power BI Desktop’ta çöz ve sonucunu “Beklenen” değerle karşılaştır. Çözümler cozumler.md dosyasında.

## Temel

### k1 · İptal Oranı

Tüm dönemde (Ekim–Aralık 2024) siparişlerin yüzde kaçı **iptal** edildi? Filtre yok.

**Beklenen:** %4,99

### k2 · GMV

Dönemin toplam **GMV**’si nedir? GMV: teslim edilen siparişlerde ürün tutarı − indirim + teslim ücreti. İptal ve iade dahil değil, bahşiş dahil değil.

**Beklenen:** 3.389.310,2 ₺

### k3 · Ortalama Sepet

**Ortalama sepet tutarı** nedir? Teslim edilen sipariş başına GMV (TL). Filtre yok.

**Beklenen:** 510,5921 ₺

### k4 · Kuryesiz Sipariş

Veri kalitesi kontrolü: **courier_id** alanı boş olan kaç sipariş var ve bunların hepsi iptal mi? Kurye atanmamış sipariş sayısını bul. Filtre yok.

**Beklenen:** 195

### k5 · Yemek Puanı

**İzmir**’deki restoranların ortalama **yemek puanı** nedir? Dilimleyici: lk_restaurants[city] = İzmir.

**Beklenen:** 4,1782

## Orta

### o1 · Çift Sayılan Ücret

Çift sayma tuzağı: Bir analist teslim ücretini **RELATED** ile satır tablosuna taşıyıp satırlar üzerinde topladı. Bu yöntem, doğru teslim ücretinden **kaç TL fazla** sayar? Tüm siparişler, filtre yok.

**Beklenen:** 39.621 ₺

### o2 · Medyan Teslim Süresi

Teslim edilen siparişlerde, siparişten teslime geçen sürenin **medyanı** kaç dakika? Filtre yok.

**Beklenen:** 36,8 dk

### o3 · P90 Teslim Süresi

**Aralık 2024**’te teslim süresinin **%90’lık dilimi** (P90) kaç dakika? Dilimleyici: Takvim[YilAy] = 2024-12 (sipariş tarihine göre).

**Beklenen:** 52,6233 dk

### o4 · SLA Uyum Oranı

**SLA**: Teslim edilen siparişlerin yüzde kaçı **35 dakika veya daha kısa** sürede teslim edildi? Filtre yok.

**Beklenen:** %43,01

### o5 · Teslim Tarihine Göre Teslim

**Teslim tarihine göre** Kasım 2024’te kaç sipariş teslim edildi (status = teslim)? Dilimleyici: Takvim[YilAy] = 2024-11. Etkin ilişki sipariş tarihine bağlı; teslim tarihini kullanman gerekiyor.

**Beklenen:** 2.168

### o6 · GMV Aylık Değişim %

**Aralık 2024** GMV’si Kasım’a göre yüzde kaç değişti? Dilimleyici: Takvim[YilAy] = 2024-12.

**Beklenen:** %14,2

### o7 · İndirimli Sepet Farkı

Kampanya etkisi: Teslim edilen siparişlerde **indirimli** siparişlerin ortalama ürün tutarı, **indirimsiz** siparişlerinkinden kaç TL fazla? Filtre yok.

**Beklenen:** 4,8566 ₺

## İleri

### s1 · İade Oranı Artışı

**Soruşturma 1 · Alarm.** Aralık 2024’ün iade oranı, Ekim–Kasım 2024’ün birleşik iade oranından kaç **yüzde puan** yüksek? Filtre yok; dönemleri ölçünün içinde ver.

**Beklenen:** %1,03

### s2

**Soruşturma 2 · Şüpheliler.** Aralık 2024’te en çok iade alan **restoran–kurye** ikilisi hangisi ve kaç iade almış? Sorgu görünümünde (DAX query view) restoran adı, kurye adı ve iade sayısını en yüksekten sırala.

**Beklenen:** `Köşe Dönercisi · Serdar Yalın · 21`

### s3 · Işınlanan Sipariş

**Soruşturma 3 · İmkânsız teslim.** Kuryenin siparişi restorandan aldıktan sonra **5 dakikadan kısa** sürede teslim ettiği kaç sipariş var? (picked_at → delivered_at). Filtre yok.

**Beklenen:** 21

### s4 · Davet Eden

**Soruşturma 4 · Davet halkası.** Işınlanan siparişleri veren müşterilerin hepsi aynı kişinin davetiyle (referred_by) kayıt olmuş. Davet eden müşterinin **adı** ne? Filtre yok.

**Beklenen:** Bora Keskin

### s5 · Sahte İade Zararı

**Soruşturma 5 · Zarar.** Işınlanan siparişler için müşterilere iade edilen toplam tutar ne kadar? (ürün tutarı − indirim + teslim ücreti). Filtre yok.

**Beklenen:** 10.259,2 ₺

### s6 · Yavaş Gün Sayısı

**Soruşturma 6 · Gürültüyü ayıkla.** Teslim süresindeki her sıçrama dolandırıcılık değildir. Ortalama teslim süresi **45 dakikayı aşan** kaç gün var? (Sipariş tarihine göre gün, yalnız teslim edilen siparişler.) Filtre yok.

**Beklenen:** 10
