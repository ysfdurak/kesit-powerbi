# Lezzet Kurye · örnek çözümler

## Temel

### k1 · İptal Oranı

*İpucu:* İptal edilenleri CALCULATE ile say, tüm siparişlere DIVIDE ile böl.

```dax
İptal Oranı =
DIVIDE(CALCULATE(COUNTROWS(lk_orders), lk_orders[status] = "iptal"), COUNTROWS(lk_orders))
```

Payda tüm siparişlerdir (teslim, iptal, iade). DIVIDE sıfıra bölmede hata yerine boş döndürür. Restoran kırılımına bakınca Ankara’daki Bizim Mutfak %14,9 iptal oranıyla platform ortalamasının üç katında çıkar.

### k2 · GMV

*İpucu:* Ürün tutarı satır tablosunda (qty × unit_price), indirim ve teslim ücreti başlık tablosunda. Üçünü ayrı ölçülerle topla, sonra durum filtresini CALCULATE ile ver.

```dax
GMV =
CALCULATE([Ürün Tutarı] - [İndirim Tutarı] + [Teslim Ücreti], lk_orders[status] = "teslim")
```

Her tutarı kendi tablosunda topladığın için hiçbir sipariş iki kez sayılmaz. lk_orders üzerindeki durum filtresi ilişki yoluyla satırlara da iner.

### k3 · Ortalama Sepet

*İpucu:* [GMV] ölçüsünü teslim edilen sipariş sayısına böl.

```dax
Ortalama Sepet =
DIVIDE([GMV], CALCULATE(COUNTROWS(lk_orders), lk_orders[status] = "teslim"))
```

Ortalamayı satır tablosunda AVERAGE ile alırsan ürün satırı başına tutarı bulursun. Sepet sipariş düzeyinde bir kavramdır, bu yüzden pay ve payda sipariş düzeyinde olmalı.

### k4 · Kuryesiz Sipariş

*İpucu:* ISBLANK ya da COUNTBLANK kullan. Sonra aynı filtreyi status ile birlikte bir tabloya koyup durumları gör.

```dax
Kuryesiz Sipariş =
COUNTROWS(FILTER(lk_orders, ISBLANK(lk_orders[courier_id])))
```

Boş kurye, iptal edilen 358 siparişin bir kısmında görülür; teslim ve iade siparişlerinde hep kurye vardır. Bu bir iş kuralıdır. Kurye bazlı görsellerde “(Boş)” satırı çıkmasının nedeni budur.

### k5 · Yemek Puanı

*İpucu:* Puanlar lk_ratings’te. Restoran filtresi restoran → sipariş → puan zinciriyle iner.

```dax
Yemek Puanı =
AVERAGE(lk_ratings[food_score])
```

lk_ratings ile lk_orders arasında tek yönlü *:1 ilişki kurduğun için restoran filtresi iki adımda puan tablosuna ulaşır. Puanı olmayan siparişler ortalamaya girmez.

## Orta

### o1 · Çift Sayılan Ücret

*İpucu:* SUMX(lk_order_lines, RELATED(lk_orders[delivery_fee])) ile [Teslim Ücreti] arasındaki farkı al.

```dax
Çift Sayılan Ücret =
SUMX(lk_order_lines, RELATED(lk_orders[delivery_fee])) - [Teslim Ücreti]
```

Bir siparişte kaç ürün satırı varsa ücret o kadar kez tekrar eder. Başlıkta duran bir tutar başlık tablosunda toplanır; satır düzeyindeki bir tutar da satır tablosunda.

### o2 · Medyan Teslim Süresi

*İpucu:* delivered_at − placed_at gün cinsinden bir fark verir; 1440 ile çarp. MEDIANX ile yalnız teslim edilenler üzerinde dolaş.

```dax
Medyan Teslim Süresi =
MEDIANX(FILTER(lk_orders, lk_orders[status] = "teslim"), (lk_orders[delivered_at] - lk_orders[placed_at]) * 1440)
```

Ortalama (yaklaşık 37,7 dk) birkaç çok uzun teslimle yukarı çekilir; medyan tipik müşteri deneyimini daha iyi anlatır. Desktop’ta DATEDIFF(…, MINUTE) dakika sınırlarını sayar ve saniyeleri atar; saniye hassasiyeti için tarih farkını 1440 ile çarpmak ya da DATEDIFF(…, SECOND) / 60 kullanmak gerekir.

### o3 · P90 Teslim Süresi

*İpucu:* PERCENTILEX.INC(tablo, ifade, 0.9). Tabloyu yalnız teslim edilen siparişlerle sınırla.

```dax
P90 Teslim Süresi =
PERCENTILEX.INC(FILTER(lk_orders, lk_orders[status] = "teslim"), (lk_orders[delivered_at] - lk_orders[placed_at]) * 1440, 0.9)
```

P90 “en kötü %10’luk deneyim nerede başlıyor” sorusunu cevaplar. SLA hedefi konuşulurken ortalama yerine P90 izlemek kuyruk sorunlarını görünür kılar.

### o4 · SLA Uyum Oranı

*İpucu:* FILTER içinde hem status = "teslim" hem de süre ≤ 35 koşulu. Süreyi ROUND(…, 2) ile yuvarla: tam 35:00 süren siparişler kayan nokta yüzünden 35,0000001 çıkabilir.

```dax
SLA Uyum Oranı =
DIVIDE(COUNTROWS(FILTER(lk_orders, lk_orders[status] = "teslim" && ROUND((lk_orders[delivered_at] - lk_orders[placed_at]) * 1440, 2) <= 35)), CALCULATE(COUNTROWS(lk_orders), lk_orders[status] = "teslim"))
```

Verideki 4 sipariş tam 35:00’te teslim edilmiş. Yuvarlamadan karşılaştırırsan bu siparişler motorun hesap biçimine göre SLA içine ya da dışına düşer. Eşik karşılaştırmasında süreyi önce sabit bir hassasiyete yuvarla.

### o5 · Teslim Tarihine Göre Teslim

*İpucu:* CALCULATE içinde USERELATIONSHIP(lk_orders[TeslimTarih], 'Takvim'[Tarih]).

```dax
Teslim Tarihine Göre Teslim =
CALCULATE([Teslim Edilen Sipariş], USERELATIONSHIP(lk_orders[TeslimTarih], 'Takvim'[Tarih]))
```

Gece yarısına yakın verilen siparişler ertesi gün teslim edilir. Ay sınırında iki sayım farklılaşır: sipariş tarihine göre Kasım’da 2.169 teslim varken teslim tarihine göre 2.168. Ekim’in son gecesi Kasım’a geçenler ile Kasım’ın son gecesi Aralık’a geçenler birbirini neredeyse götürür. USERELATIONSHIP yalnız bu hesap için kesikli ilişkiyi açar.

### o6 · GMV Aylık Değişim %

*İpucu:* Önceki ayın GMV’sini CALCULATE([GMV], PREVIOUSMONTH('Takvim'[Tarih])) ile al. Takvim tarih tablosu olarak işaretli olmalı.

```dax
GMV Aylık Değişim % =
VAR bu = [GMV]
VAR once = CALCULATE([GMV], PREVIOUSMONTH('Takvim'[Tarih]))
RETURN DIVIDE(bu - once, once)
```

Filtre YilAy sütunundayken PREVIOUSMONTH Tarih sütununa yeni bir filtre koyar. Takvim tarih tablosu olarak işaretli olduğu için YilAy filtresi otomatik kalkar ve gerçekten Kasım hesaplanır.

### o7 · İndirimli Sepet Farkı

*İpucu:* İki VAR: biri discount > 0, diğeri discount = 0 koşuluyla CALCULATE(DIVIDE([Ürün Tutarı], [Sipariş Sayısı]), …). Farkı döndür.

```dax
İndirimli Sepet Farkı =
VAR indirimli = CALCULATE(DIVIDE([Ürün Tutarı], [Sipariş Sayısı]), lk_orders[status] = "teslim", lk_orders[discount] > 0)
VAR indirimsiz = CALCULATE(DIVIDE([Ürün Tutarı], [Sipariş Sayısı]), lk_orders[status] = "teslim", lk_orders[discount] = 0)
RETURN indirimli - indirimsiz
```

Fark küçükse indirim sepeti büyütmüyor, yalnızca marjı eritiyor demektir. Bu karşılaştırma nedensellik kanıtlamaz; kampanyanın kime gösterildiği bilinmeden “indirim işe yaramıyor” denemez, ama A/B testi için güçlü bir gerekçedir.

## İleri

### s1 · İade Oranı Artışı

*İpucu:* İki CALCULATE: biri Takvim[YilAy] = "2024-12", diğeri Takvim[YilAy] IN {"2024-10", "2024-11"}. Farkı yüzde biçiminde göster.

```dax
İade Oranı Artışı =
VAR aralik = CALCULATE([İade Oranı], 'Takvim'[YilAy] = "2024-12")
VAR onceki = CALCULATE([İade Oranı], 'Takvim'[YilAy] IN {"2024-10", "2024-11"})
RETURN aralik - onceki
```

İki dönemin oranını ayrı ayrı hesaplayıp farkını almak, aylık oranların ortalamasını almaktan farklıdır: Ekim–Kasım oranı iki ayın siparişleri birleştirilerek bulunur. Sipariş hacmi artarken iade sayısı neredeyse ikiye katlanmış.

### s2

*İpucu:* SUMMARIZECOLUMNS(lk_restaurants[name], lk_couriers[full_name], filtre tablosu, "Iade", [İade Edilen Sipariş]) sonucunu TOPN ile kes, ORDER BY ile sırala.

```dax
EVALUATE
TOPN(
    3,
    SUMMARIZECOLUMNS(
        lk_restaurants[name],
        lk_couriers[full_name],
        TREATAS({"2024-12"}, 'Takvim'[YilAy]),
        "Iade", [İade Edilen Sipariş]
    ),
    [Iade], DESC
)
ORDER BY [Iade] DESC
```

Not: 2. sıradan sonraki ikililer 2’şer iadeyle berabere olduğu için TOPN(3, …) eşitlikleri dahil eder ve 3’ten fazla satır görebilirsin; önemli olan ilk satır. Aralık’ta ikinci sıradaki ikili yalnızca birkaç iade almışken ilk sıradaki ikili tek başına onlarca iade almış. Kurye Serdar Yalın Ağustos 2024’te işe başlamış ve kurye puanı boş: müşteri puanı ortalamasında görünmüyor.

### s3 · Işınlanan Sipariş

*İpucu:* FILTER içinde NOT ISBLANK(delivered_at) koşulunu unutma: boş − boş farkı 0 sayılır ve iptaller de 5’ten küçük görünür.

```dax
Işınlanan Sipariş =
COUNTROWS(FILTER(lk_orders, NOT ISBLANK(lk_orders[delivered_at]) && (lk_orders[delivered_at] - lk_orders[picked_at]) * 1440 < 5))
```

Normal yol süresi en hızlı kuryede bile 7–8 dakikanın altına inmez. 5 dakikanın altındaki teslimlerin hepsi Aralık akşamlarında, aynı restorandan ve aynı kuryeyle yapılmış, hepsi cüzdana iade edilmiş: teslim gerçekte yapılmamış olabilir.

### s4 · Davet Eden

*İpucu:* Hızlı siparişlerin customer_id değerlerini CALCULATETABLE ile al, TREATAS ile lk_customers[customer_id] üzerine uygula, referred_by değerini MAXX ile çek, sonra LOOKUPVALUE ile adını bul. referred_by aynı tabloya baktığı için ilişki kurulamaz.

```dax
Davet Eden =
VAR musteriler = CALCULATETABLE(VALUES(lk_orders[customer_id]), FILTER(lk_orders, NOT ISBLANK(lk_orders[delivered_at]) && (lk_orders[delivered_at] - lk_orders[picked_at]) * 1440 < 5))
VAR davetciler = CALCULATETABLE(VALUES(lk_customers[referred_by]), TREATAS(musteriler, lk_customers[customer_id]))
RETURN IF(COUNTROWS(davetciler) = 1, LOOKUPVALUE(lk_customers[full_name], lk_customers[customer_id], MAXX(davetciler, lk_customers[referred_by])), "Birden çok davetçi")
```

Sipariş tablosundaki bir filtre müşteri tablosuna kendiliğinden çıkmaz (filtre bir taraftan çok tarafa akar). TREATAS, sipariş tarafında bulunan müşteri listesini müşteri tablosuna filtre olarak taşır. Bu 9 hesabın hepsi Kasım 2024’te, iki günde bir, Kadıköy’de açılmış.

### s5 · Sahte İade Zararı

*İpucu:* Ürün, indirim ve ücret ölçülerini aynı CALCULATE içinde, hızlı teslim filtresiyle birlikte hesapla.

```dax
Sahte İade Zararı =
CALCULATE([Ürün Tutarı] - [İndirim Tutarı] + [Teslim Ücreti], FILTER(lk_orders, NOT ISBLANK(lk_orders[delivered_at]) && (lk_orders[delivered_at] - lk_orders[picked_at]) * 1440 < 5))
```

CALCULATE’in tablo filtresi lk_orders’ı süzer; ilişki üzerinden satır tablosu da süzülür, böylece üç tutar aynı sipariş kümesi için toplanır. Raporu denetim ekibine bu sayı ve sipariş listesiyle teslim et.

### s6 · Yavaş Gün Sayısı

*İpucu:* VALUES('Takvim'[Tarih]) üzerinde FILTER ile dolaş; her gün için CALCULATE(AVERAGEX(…)) bağlam geçişiyle o günün ortalamasını verir. Siparişsiz günler boş döner ve 45’i aşmaz.

```dax
Yavaş Gün Sayısı =
COUNTROWS(FILTER(VALUES('Takvim'[Tarih]), CALCULATE(AVERAGEX(FILTER(lk_orders, lk_orders[status] = "teslim"), (lk_orders[delivered_at] - lk_orders[placed_at]) * 1440)) > 45))
```

Bu günlerde hazırlık ve yol süresi birlikte uzamış, her şehirde ve her kuryede görülüyor: hava ya da trafik gibi dış bir etki. Işınlanan siparişler tam tersine tek restoran ve tek kuryede toplanıyor. Soruşturmada “yaygın mı, yoğunlaşmış mı?” sorusu sinyali gürültüden ayırır.
