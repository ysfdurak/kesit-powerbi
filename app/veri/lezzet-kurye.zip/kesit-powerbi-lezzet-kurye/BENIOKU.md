# Lezzet Kurye · Kesit Power BI vaka paketi

**Sektör:** Yemek teslimatı · **Dönem:** Ekim–Aralık 2024

> Üç şehirde yemek teslimatı: GMV, teslim süresi, SLA ve Aralık’ta patlayan iadelerin arkasındaki soruşturma.

Bu paketteki şirket, kişiler ve kayıtlar tamamen hayalidir. İçerik CC BY-NC 4.0 lisanslıdır: kaynak göstererek, ticari olmayan amaçlarla paylaşılabilir.

## Vaka

**Lezzet Kurye**, İstanbul, Ankara ve İzmir’de çalışan hayali bir yemek siparişi ve teslimat platformu. Müşteri uygulamadan sipariş verir, restoran hazırlar, kurye restorandan alıp kapıya götürür. Elinde Ekim–Aralık 2024’e ait 7.178 sipariş, 14.974 sipariş satırı, 30 restoran, 60 kurye ve 1.209 müşteri var.

Operasyon direktörü üç soru soruyor: **Büyüyor muyuz?** (GMV, sepet tutarı, aylık değişim), **Söz verdiğimiz hızda teslim ediyor muyuz?** (35 dakikalık SLA, medyan ve %90’lık dilim teslim süresi, hazırlık süresi) ve **Müşteri memnun mu?** (iptal oranı, yemek ve kurye puanı, tekrar sipariş veren müşteri payı). Pazarlama ekibi ayrıca indirim kampanyalarının sepeti gerçekten büyütüp büyütmediğini merak ediyor.

Modelde iki ayrı olgu tablosu var: **lk_orders** sipariş başlığıdır (zamanlar, durum, teslim ücreti, indirim, bahşiş), **lk_order_lines** ise sipariş detayıdır (ürün, adet, birim fiyat). Ürün tutarı satırlarda, teslim ücreti başlıkta durur. Bu başlık-detay deseni, ücreti satıra taşıyıp toplayan herkesi çift saymaya iter. Zamanlar dakika hassasiyetinde değil saniye hassasiyetinde tutulur; teslim süresini doğru ölçmek de ayrı bir beceridir.

Aralık’ta bir alarm geldi: finans ekibi iade oranının yükseldiğini fark etti. İade edilen siparişin tutarı müşterinin cüzdanına geri yatıyor. Ekim ve Kasım’da iade oranı %2 civarındayken Aralık’ta belirgin biçimde artmış. Destek ekibi “hep aynı restoran, hep aynı saatler” diyor ama kanıt yok. Raporun son bölümünde bir **soruşturma** yürüteceksin: alarmı sayıyla doğrulayacak, şüpheli restoran ve kuryeyi bulacak, fiziksel olarak imkânsız teslimleri ayıklayacak, bu siparişleri veren hesapların kimin davetiyle açıldığını ortaya çıkaracak ve zararı TL olarak hesaplayacaksın.

**Senden beklenen:** CSV’leri Power BI Desktop’a yükle, yıldız şemayı kur (takvim tablosu, rol oynayan iki tarih ilişkisi), 20 ölçülük kütüphaneyi yaz, görevlerdeki sayıları bul ve dört sayfalık bir operasyon raporu tasarla. Raporun hem yönetime “bugün nasılız” sorusunu hem de denetim ekibine “ne oldu” sorusunu cevaplamalı.

## Dosyalar

- `veri/` klasörü: CSV tabloları (UTF-8, virgülle ayrılmış, ondalık ayırıcı nokta, tarih YYYY-MM-DD)
- `olcular.dax`: ölçü kütüphanesi
- `gorevler.md`: görevler ve beklenen sonuçlar
- `cozumler.md`: örnek çözümler (önce kendin dene)

## Tablolar

### lk_orders (olgu)

Sipariş başlığı, her satır bir sipariş (7.178)

| Sütun | Tür | Açıklama |
|---|---|---|
| order_id | Tam sayı | Sipariş numarası (anahtar) |
| customer_id | Tam sayı | Siparişi veren müşteri → lk_customers |
| restaurant_id | Tam sayı | Restoran → lk_restaurants |
| courier_id | Tam sayı | Kurye → lk_couriers; iptal edilen siparişlerin bir kısmında boş |
| placed_at | Tarih/Saat | Siparişin verildiği an |
| picked_at | Tarih/Saat | Kuryenin siparişi restorandan aldığı an; iptalde boş |
| delivered_at | Tarih/Saat | Teslim anı; iptalde boş |
| status | Metin | teslim / iptal / iade |
| payment | Metin | kart / nakit / cüzdan |
| delivery_fee | Sabit ondalık sayı | Teslim ücreti (TL); ürün tutarı 400 TL ve üzerindeyse 0. Başlık düzeyinde, sipariş başına bir kez |
| discount | Sabit ondalık sayı | Kampanya indirimi (TL); indirimsiz siparişte 0 |
| tip | Sabit ondalık sayı | Kuryeye bahşiş (TL); gelir değildir, kuryeye gider |

### lk_order_lines (olgu)

Sipariş satırları, her satır bir siparişteki bir ürün (14.974)

| Sütun | Tür | Açıklama |
|---|---|---|
| order_id | Tam sayı | Sipariş → lk_orders |
| item_id | Tam sayı | Ürün → lk_menu_items |
| qty | Tam sayı | Adet |
| unit_price | Sabit ondalık sayı | Sipariş anındaki birim fiyat (TL) |

### lk_ratings (olgu)

Sipariş değerlendirmeleri, siparişlerin bir kısmında (3.979)

| Sütun | Tür | Açıklama |
|---|---|---|
| order_id | Tam sayı | Değerlendirilen sipariş → lk_orders (her siparişe en çok bir değerlendirme) |
| food_score | Tam sayı | Yemek puanı (1–5) |
| courier_score | Tam sayı | Kurye puanı (1–5) |
| comment | Metin | Yorum; çoğunlukla boş |

### lk_customers (boyut)

Müşteriler (1.209)

| Sütun | Tür | Açıklama |
|---|---|---|
| customer_id | Tam sayı | Müşteri numarası (anahtar) |
| full_name | Metin | Ad soyad |
| city | Metin | Şehir |
| district | Metin | İlçe; 74 müşteride boş |
| signup_date | Tarih | Kayıt tarihi |
| referred_by | Tam sayı | Bu müşteriyi davet eden müşterinin customer_id değeri (aynı tabloya bakar); davetsiz kayıtta boş |
| is_premium | Tam sayı | Premium üye mi (1/0) |

### lk_restaurants (boyut)

Restoranlar (30)

| Sütun | Tür | Açıklama |
|---|---|---|
| restaurant_id | Tam sayı | Restoran numarası (anahtar) |
| name | Metin | Restoran adı |
| cuisine | Metin | Mutfak türü (Döner, Pizza, Kebap…) |
| city | Metin | Şehir |
| district | Metin | İlçe |
| opened_date | Tarih | Platforma katılma tarihi; bazı restoranlarda boş |
| commission_pct | Ondalık sayı | Platformun aldığı komisyon yüzdesi (15 = %15) |
| is_active | Tam sayı | Aktif mi (1/0) |

### lk_couriers (boyut)

Kuryeler (60)

| Sütun | Tür | Açıklama |
|---|---|---|
| courier_id | Tam sayı | Kurye numarası (anahtar) |
| full_name | Metin | Ad soyad |
| city | Metin | Çalıştığı şehir |
| vehicle | Metin | motosiklet / bisiklet / araba |
| hired_date | Tarih | İşe başlama tarihi |
| rating | Ondalık sayı | Müşterilerin verdiği kurye puanlarının ortalaması; boş olabilir |

### lk_menu_items (boyut)

Menü ürünleri (168)

| Sütun | Tür | Açıklama |
|---|---|---|
| item_id | Tam sayı | Ürün numarası (anahtar) |
| restaurant_id | Tam sayı | Ürünün restoranı → lk_restaurants |
| name | Metin | Ürün adı |
| category | Metin | Ana yemek / Yan ürün / İçecek / Tatlı / Çorba |
| price | Sabit ondalık sayı | Güncel menü fiyatı (TL); geçmiş siparişler için unit_price kullan |
| is_vegetarian | Tam sayı | Vejetaryen mi (1/0) |

## Başlamadan önce

1. **Yerel ayar:** CSV’ler ondalık ayırıcı olarak nokta kullanır. Desktop Türkçe yerel ayardaysa yüklerken `-664.74` gibi değerler −66474’e dönüşür. Boş bir dosya açıp Dosya → Seçenekler ve ayarlar → Seçenekler → GEÇERLİ DOSYA → Bölgesel Ayarlar (Regional Settings) → İçeri aktarma için yerel ayar (Locale for import) değerini İngilizce (ABD) yap, sonra veriyi yükle. Ya da Power Query’de otomatik eklenen “Değiştirilen Tür” adımını silip türleri yerel ayarla yeniden ver: `Table.TransformColumnTypes(Kaynak, {{"amount", type number}}, "en-US")`.
2. **Otomatik ilişkileri kapat:** GEÇERLİ DOSYA → Veri Yükleme → İlişkiler altında “Veri yüklendikten sonra yeni ilişkileri otomatik algıla” seçeneğini kaldır. İlişkileri aşağıdaki listeye göre kendin kur; sonra Model → İlişkileri yönet listesini karşılaştır.
3. **Boş hücreler:** Boş tarih ve sayılar tür verilince null olur; boş metin hücreleri boş metin (“”) kalır. Gerekirse Değerleri değiştir ile null yap.
4. **Otomatik tarih/saat:** Kendi Takvim tablonu kullanacağın için GEÇERLİ DOSYA → Veri Yükleme altında “Otomatik tarih/saat” seçeneğini kapat.

## Hazırlık (Power Query)

1. **Veri al → Metin/CSV** (Get data → Text/CSV) ile yedi CSV’yi yükle. Her biri için **Verileri dönüştür** (Transform data) seçerek Power Query Düzenleyicisi’ni aç. Dosya UTF-8 olduğundan “Dosya kaynağı” 65001: Unicode (UTF-8) olmalı; yoksa Türkçe karakterler bozulur.
2. Veri türlerini kontrol et: `placed_at`, `picked_at`, `delivered_at` → **Tarih/Saat**; `signup_date`, `hired_date`, `opened_date` → **Tarih**; `delivery_fee`, `discount`, `tip`, `unit_price`, `price` → **Sabit ondalık sayı** (Fixed decimal number). Bölgesel ayarın Türkçe ise ondalık nokta yanlış okunabilir: tür değiştirirken **Yerel ayarı kullanarak** (Using locale) → İngilizce (ABD) seç.
3. lk_orders tablosuna üç sütun ekle. **Sütun ekle → Özel sütun** (Add column → Custom column): `Tarih = Date.From([placed_at])`, `TeslimTarih = Date.From([delivered_at])` (iptallerde null kalır), `Saat = Time.Hour([placed_at])`. Türlerini Tarih, Tarih ve Tam sayı yap.
4. Boşları silme: iptal edilen siparişlerde `picked_at` ve `delivered_at`, bir kısmında `courier_id` boştur ve bu bir hata değil, iş kuralıdır. **Kapat ve uygula** (Close & Apply).
5. **Modelleme → Yeni tablo** (Modeling → New table) ile aşağıdaki DAX’la Takvim tablosunu kur. Tablo 2024 ve 2025’in tamamını kapsar; 1 Ocak 2025 00:xx’te verilen 3 sipariş de takvimde karşılık bulur. Takvimi seç → **Tablo araçları → Tarih tablosu olarak işaretle** (Mark as date table) → Tarih sütunu.
6. Takvim[Ay] sütununu seç → **Sütun araçları → Sütuna göre sırala** (Sort by column) → AyNo. Aynısını HaftaninGunu → GunNo için yap.
7. **Model görünümü**nde ilişkileri kur: lk_orders → lk_customers, lk_restaurants, lk_couriers (customer_id, restaurant_id, courier_id); lk_order_lines → lk_orders (order_id) ve lk_menu_items (item_id); lk_orders[Tarih] → Takvim[Tarih] etkin; lk_orders[TeslimTarih] → Takvim[Tarih] **etkin değil** (kesikli çizgi).
8. lk_ratings → lk_orders ilişkisinde iki taraf da benzersiz olduğu için Desktop bunu **Bire bir** (One to one) olarak önerir; bire bir ilişkide çapraz filtre yönü her zaman **Her ikisi**dir (Both). İlişkiyi düzenle: kardinaliteyi **Çoğa bir** (Many to one, *:1), çapraz filtre yönünü **Tek** (Single) yap. Böylece puan tablosu siparişleri süzmez, yalnızca siparişlerden süzülür.
9. lk_menu_items → lk_restaurants ilişkisini ekleyince Desktop iki yol olduğu için onu etkin yapamaz. Etkin olmayan olarak bırak. Restoranın satış filtresi zaten lk_orders üzerinden gelir.
10. Anahtar sütunları (order_id, customer_id, restaurant_id, courier_id, item_id ve olgu tablolarındaki Tarih/TeslimTarih) **Rapor görünümünde gizle**. Ölçüleri boş bir **_Ölçüler** tablosunda topla ve **Görüntüleme klasörü** (Display folder) alanıyla Temel, Gelir, Oran, Teslimat, Müşteri, Zaman klasörlerine ayır.
11. Para ölçülerine **Biçim → Para birimi** (₺ Türkçe), oran ölçülerine **Yüzde** (1 ondalık), süre ölçülerine 1 ondalıklı sayı biçimi ver. Ölçü adına “(dk)” eklemek yerine açıklamaya (Description) birim yaz.

### Türetilmiş sütunlar

- `lk_orders[Tarih]` ← `placed_at` (date): Takvim ile etkin ilişki: siparişin verildiği gün
- `lk_orders[TeslimTarih]` ← `delivered_at` (date): Takvim ile etkin olmayan ikinci ilişki: teslim günü (iptalde boş)
- `lk_orders[Saat]` ← `placed_at` (hour): Öğle ve akşam yoğunluğunu görmek için siparişin saati (0–23)

## Takvim tablosu

Modelleme → Yeni tablo:

```dax
Takvim =
ADDCOLUMNS(
    CALENDAR(DATE(2024, 1, 1), DATE(2025, 12, 31)),
    "Tarih", [Date],
    "Yil", YEAR([Date]),
    "CeyrekNo", QUARTER([Date]),
    "Ceyrek", "Ç" & QUARTER([Date]),
    "AyNo", MONTH([Date]),
    "Ay", SWITCH(MONTH([Date]), 1, "Oca", 2, "Şub", 3, "Mar", 4, "Nis", 5, "May", 6, "Haz", 7, "Tem", 8, "Ağu", 9, "Eyl", 10, "Eki", 11, "Kas", 12, "Ara"),
    "YilAy", YEAR([Date]) & "-" & IF(MONTH([Date]) < 10, "0", "") & MONTH([Date]),
    "Gun", DAY([Date]),
    "GunNo", WEEKDAY([Date], 2),
    "HaftaninGunu", SWITCH(WEEKDAY([Date], 2), 1, "Pazartesi", 2, "Salı", 3, "Çarşamba", 4, "Perşembe", 5, "Cuma", 6, "Cumartesi", 7, "Pazar"),
    "HaftaSonu", IF(WEEKDAY([Date], 2) >= 6, "Evet", "Hayır")
)
-- Not: CALENDAR "Date" adlı bir sütun üretir. Tabloyu kurduktan sonra Date sütununu gizle (ya da SELECTCOLUMNS ile at); ilişki ve işaretleme için Tarih sütununu kullan.
```

Takvimi tarih tablosu olarak işaretle (Tablo araçları → Tarih tablosu olarak işaretle → Tarih) ve Ay sütununu AyNo’ya göre sırala.

## Model ve ilişkiler

- `lk_orders[customer_id]` → `lk_customers[customer_id]`
- `lk_orders[restaurant_id]` → `lk_restaurants[restaurant_id]`
- `lk_orders[courier_id]` → `lk_couriers[courier_id]`
- `lk_orders[Tarih]` → `Takvim[Tarih]`
- `lk_orders[TeslimTarih]` → `Takvim[Tarih]` **(pasif)**: Rol oynayan tarih: teslim gününe göre saymak için USERELATIONSHIP ile açılır
- `lk_order_lines[order_id]` → `lk_orders[order_id]`
- `lk_order_lines[item_id]` → `lk_menu_items[item_id]`
- `lk_ratings[order_id]` → `lk_orders[order_id]`
- `lk_menu_items[restaurant_id]` → `lk_restaurants[restaurant_id]` **(pasif)**: Satırlardan restorana iki yol oluşur (siparişler üzerinden ve menü üzerinden); belirsizlik olmaması için bu yol kapalı tutulur. Menü analizinde USERELATIONSHIP ile açılır

## Rapor brifi

**Lezzet Kurye · Operasyon ve Denetim Raporu** · Operasyon direktörü, şehir müdürleri, pazarlama ve iç denetim

### Sayfa 1: Genel Bakış

Yönetim “bu ay nasılız?” sorusuna 10 saniyede cevap alsın.

- Kart görselleri (Card): [GMV], [Ortalama Sepet], [Teslim Edilen Sipariş], [İptal Oranı], [SLA Uyum Oranı], [Medyan Teslim Süresi]
- Çizgi ve kümelenmiş sütun grafik (Line and clustered column): Takvim[YilAy] eksende, sütun [GMV], çizgi [GMV Aylık Değişim %]
- Halka grafik (Donut): lk_orders[payment] ile [Sipariş Sayısı]
- Harita ya da çubuk grafik: lk_restaurants[city] ile [GMV] ve [SLA Uyum Oranı]

Etkileşimler:

- YilAy ve şehir dilimleyicileri; dilimleyicileri tüm sayfalarla eşitle (Görünüm → Dilimleyicileri eşitle / Sync slicers)
- KPI kartlarında koşullu biçimlendirme: SLA %50’nin altındaysa kırmızı

### Sayfa 2: Teslimat Analizi

Gecikmenin nerede doğduğunu bul: restoranda mı, yolda mı, hangi saatte?

- Matris (Matrix): satırda Takvim[HaftaninGunu], sütunda lk_orders[Saat], değer [Medyan Teslim Süresi]; arka plan rengi ile ısı haritası
- Kümelenmiş çubuk grafik: lk_restaurants[name] ile [Ort. Hazırlık Süresi], ilk 10 (Top N filtre)
- Çizgi grafik: Takvim[Tarih] ile [Medyan Teslim Süresi] ve [P90 Teslim Süresi]; 45 dk sabit çizgisi (Analiz bölmesi → Sabit çizgi)
- Dağılım grafiği (Scatter): lk_couriers[full_name] ayrıntı, X [Teslim Edilen Sipariş], Y [Medyan Teslim Süresi], boyut [Yemek Puanı]

Etkileşimler:

- Alan parametresi (Field parameter) ile ölçü seçici: Medyan / P90 / Ortalama hazırlık
- Restoran çubuğundan “Restoran Detayı” sayfasına detaya git (Drill through)

### Sayfa 3: Restoran Detayı

Detaya git hedef sayfası: tek restoranın siparişleri, puanları ve iadeleri.

- Detaya git alanı: lk_restaurants[name]; “Tüm filtreleri koru” açık
- Kartlar: [GMV], [İptal Oranı], [İade Oranı], [Yemek Puanı]
- Tablo: order_id, placed_at, picked_at, delivered_at, status, payment, kurye adı, [Ürün Tutarı]; status = iade satırları koşullu renkli
- Sütun grafik: lk_menu_items[category] ile [Ürün Tutarı]

Etkileşimler:

- Geri düğmesi otomatik eklenir
- Yer işareti (Bookmark): “Yalnız iadeler” görünümü ile tüm siparişler arasında geçiş

### Sayfa 4: Soruşturma ve Araç İpucu

Denetim ekibine kanıt zinciri: alarm → şüpheli → imkânsız teslim → davet halkası → zarar. Ayrıca kurye üzerine gelince açılan araç ipucu sayfası.

- Çizgi grafik: Takvim[YilAy] ile [İade Oranı]
- Tablo: restoran–kurye ikilileri ve [İade Edilen Sipariş], TOPN filtre 5
- Kart: [Işınlanan Sipariş] ve [Sahte İade Zararı] (görev ölçüleri)
- Ayrıştırma ağacı (Decomposition tree): [İade Edilen Sipariş] → restoran → kurye → payment
- Araç ipucu sayfası (Tooltip page; Biçim bölmesi → Sayfa bilgileri / Page information → Araç ipucu / Tooltip anahtarı Açık): kurye adı, işe başlama tarihi, [Teslim Edilen Sipariş], [Medyan Teslim Süresi], [İade Oranı]

Etkileşimler:

- Kurye görsellerinde Biçim → Araç ipuçları (Tooltips) kartı → Sayfa açılır listesinden araç ipucu sayfasını seç; ya da kurye adını sayfanın Araç ipucu alanlarına (Tooltip fields) koyup Otomatik bırak
- Yer işareti: “Soruşturma özeti” (yalnız Aralık, İstanbul)
- Satır düzeyi güvenlik (RLS) önerisi: şehir müdürleri yalnız kendi şehirlerini görsün

## Veri ve modelleme tuzakları

- **Başlık-detay çift sayma:** delivery_fee ve discount sipariş başlığında, ürün tutarı satırlarda. Ücreti RELATED ile satıra taşıyıp toplarsan ücret, siparişteki satır sayısı kadar tekrar eder: doğru toplam 79.894,40 TL iken 39.621 TL (yaklaşık %50) fazla sayılır. 400 TL üzeri sepetlerde ücret 0 olduğu için hata tam iki kat çıkmaz ve gözden kaçması kolaylaşır. Fark etmek için [Teslim Ücreti] ile satır bazlı toplamı yan yana koy. Çözüm: her tutarı kendi tablosunda topla, sonra ölçüleri birleştir.
- **Süre hesabında birim ve hassasiyet:** Tarih/saat farkı gün cinsindendir; dakika için 1440 ile çarp. DATEDIFF(…, MINUTE) saniyeyi atıp dakika sınırlarını sayar (11:07:59 → 11:08:01 = 1 dk). Tam 35:00 süren 4 sipariş kayan nokta yüzünden eşiğin iki yanına düşebilir: eşik karşılaştırmasından önce ROUND kullan.
- **Boş zamanlar 0 sayılır:** İptal edilen 358 siparişte picked_at ve delivered_at boş. Boş − boş farkı BLANK döner ve “< 5” karşılaştırmasında 0 gibi davranır; “5 dakikadan kısa teslim” gibi filtrelerde iptaller de sayılır. Her süre filtresine NOT ISBLANK ya da status koşulu ekle.
- **Gece yarısı ve ay sınırı:** 97 sipariş verildiği günden sonraki gün teslim edilmiş; 3 sipariş 1 Ocak 2025 00:xx’te verilmiş. Takvim yalnız Ekim–Aralık 2024’ü kapsarsa bu siparişler “(Boş)” tarihe düşer. Takvimi tam yıllarla kur; teslim gününe göre raporlarken USERELATIONSHIP kullan.
- **1:1 ilişki ve çift yönlü filtre:** lk_ratings → lk_orders ilişkisini Desktop bire bir ve çift yönlü önerir. Böyle kalırsa puan tablosundaki bir filtre siparişleri de süzer ve “puanlı siparişler” sessizce tüm KPI’lara uygulanır. Çoğa bir ve tek yön yap.
- **Kuryesiz ve puansız kayıtlar:** İptallerin bir kısmında courier_id boş; kurye 47’nin rating alanı boş. Kurye sıralamalarında boş puanlı kurye en alta düşmez, hiç görünmeyebilir. Puanı boş olan kurye sayısını ayrıca izle; soruşturmada boş alan bir ipucudur.
- **Veri başlangıcı etkisi:** Veri 1 Ekim 2024’te başlıyor. [Yeni Müşteri] ölçüsü Ekim’de sipariş veren herkesi “yeni” sayar, çünkü daha eski sipariş görünmüyor. Yeni müşteri trendini Kasım’dan itibaren yorumla ya da kayıt tarihini (signup_date) kullan; Kasım’daki tüm yeni kayıtların aynı davetçiden geldiği de böyle görülür.

## Portföyde nasıl anlatırsın

- Başlık-detay modelini (sipariş ve sipariş satırı iki ayrı olgu) doğru kurdum; teslim ücretinin satır düzeyinde toplandığında yaklaşık iki kat sayıldığını gösterip ölçü kütüphanesini buna göre tasarladım.
- Operasyon için ortalama yerine medyan ve P90 teslim süresi, 35 dakikalık SLA uyumu ve hazırlık süresi göstergelerini tanımladım. Gecikmeli 10 günün tüm şehirlere yayıldığını, yani dış etkili olduğunu gösterdim.
- İade alarmını bir soruşturmaya çevirdim: tek restoran–kurye ikilisinde yoğunlaşan iadeleri, 5 dakikanın altındaki fiziksel olarak imkânsız teslimleri ve bunları veren 9 hesabın tek bir davetçiye bağlandığını DAX ile kanıtlayıp zararı TL olarak raporladım.
- Teknik olarak USERELATIONSHIP (rol oynayan tarih), TREATAS (ilişkisiz filtre taşıma), bağlam geçişiyle gün bazlı filtreleme, PERCENTILEX.INC ve PREVIOUSMONTH kullandım; her sayıyı SQL ile bağımsız doğruladım.
- Mülakatta: “İndirimli siparişlerin sepeti indirimsizlerle hemen hemen aynı; kampanya sepeti büyütmüyor olabilir. Bunu kanıtlamak için A/B testi önerdim” diyerek analizden karara geçişi anlat.
