# Kanat Havayolları · örnek çözümler

## Temel

### k1 · İptal Oranı

*İpucu:* İptal edilen sefer sayısını tüm sefer sayısına böl; DIVIDE sıfıra bölmeye karşı güvenlidir.

```dax
İptal Oranı =
DIVIDE([İptal Edilen Uçuş], [Uçuş Sayısı])
```

3.173 seferin 62’si iptal. Payda planlanan tüm seferlerdir; iptal oranı dakiklikten ayrı bir KPI’dır.

### k2 · Hava Rötarı (dk)

*İpucu:* Rötar dakikasını hv_delays[reason] = "hava" filtresiyle CALCULATE içinde hesapla.

```dax
Hava Rötarı (dk) =
CALCULATE([Rötar Dakikası], hv_delays[reason] = "hava")
```

Dakika neden satırlarına bölünmüştür; nedenle filtreleyip toplamak çift sayım yaratmaz. En büyük neden ise geç gelen uçaktır (26.420 dk).

### k3 · Doluluk Oranı

*İpucu:* Koltuk sayısı uçak tablosunda. Gerçekleşen her sefer için RELATED(hv_aircraft[seats]) topla.

```dax
Doluluk Oranı =
DIVIDE([Toplam Yolcu], [Koltuk Kapasitesi])
```

Koltuk uçuş satırında değil, uçakta durur; SUMX + RELATED her seferin koltuğunu getirir. İptal seferler paydadan çıkar çünkü o koltuk satışa sunulmadı.

### k4 · No-Show Oranı

*İpucu:* Payda: status <> "cancelled". Pay: status = "no_show".

```dax
No-Show Oranı =
DIVIDE(CALCULATE([Rezervasyon Sayısı], hv_bookings[status] = "no_show"), [Biletli Yolcu])
```

4.604 biletli rezervasyonun 159’u gelmedi. İptaller paydaya katılırsa oran yapay olarak düşer.

### k5 · Rötarlı Uçuş

*İpucu:* hv_delays satır sayısı değil, içindeki farklı flight_id sayısı.

```dax
Rötarlı Uçuş =
DISTINCTCOUNT(hv_delays[flight_id])
```

hv_delays 1.350 satırdır; 122 seferin iki nedeni var. COUNTROWS rötarlı sefer sayısını 1.350 diye şişirir.

### k16 · Varışı Boş Sefer

*İpucu:* COUNTBLANK bir sütundaki boş değerleri sayar.

```dax
Varışı Boş Sefer =
COUNTBLANK(hv_flights[actual_arr])
```

62 iptal + 9 yön değiştiren (diverted) sefer. Varış rötarı ölçüsü yazarken bu satırları ayrı ele almazsan ortalama bozulur.

## Orta

### k6 · Zamanında Kalkış Oranı

*İpucu:* Gerçekleşen seferlerde (actual_dep − sched_dep) × 1440 dakika verir; 15’ten küçük olanları say, gerçekleşen sefere böl.

```dax
Zamanında Kalkış Oranı =
DIVIDE([Zamanında Kalkan Uçuş], [Gerçekleşen Uçuş])
```

Eylül’de yaklaşık %68 olan oran Aralık’ta %47’ye iner. İptaller paydada yoktur; aynı ay iptal oranı da %2,97’ye çıkar.

### k7 · Gelir / Yolcu

*İpucu:* Gelir ve biletli yolcu ölçülerini böl; ikisi de iptal edilen rezervasyonu dışarıda bırakır.

```dax
Gelir / Yolcu =
DIVIDE([Gelir], [Biletli Yolcu])
```

Maliyet olmadığı için rota karlılığı yerine gelir/yolcu kullanılır. Pay ve paydanın aynı durum filtresini kullanması tutarlılığı sağlar.

### k8 · Rezervasyon (Rezervasyon Tarihi)

*İpucu:* Takvim etkin ilişkiyle uçuş tarihine bakar. Pasif BookTarih ilişkisini USERELATIONSHIP ile aç; uçuşlar üzerinden gelen yolu CROSSFILTER(…, NONE) ile kapat.

```dax
Rezervasyon (Rezervasyon Tarihi) =
CALCULATE([Rezervasyon Sayısı], USERELATIONSHIP(hv_bookings[BookTarih], Takvim[Tarih]), CROSSFILTER(hv_bookings[flight_id], hv_flights[flight_id], NONE))
```

Etkin ilişkiyle sonuç 1.201 olur (uçuşu Kasım’da). Power BI ilişki yolu ağırlığı kuralıyla USERELATIONSHIP’li doğrudan yolu seçer; CROSSFILTER … NONE bunu açıkça güvenceye alır, iki filtrenin kesişip yalnız “Kasım’da alınıp Kasım’da uçulan” 584 kaydı sayma riskini kapatır. Yan etki: CROSSFILTER NONE bu ölçüde uçuş, rota ve havalimanı dilimleyicilerinin rezervasyonları süzmesini de keser; bu ölçüyü yalnız tarih kırılımlı görsellerde kullan.

### k9 · Varış Yolcusu

*İpucu:* Havalimanı tablosu rotaya kalkıştan (origin) etkin bağlı. Varış ilişkisini USERELATIONSHIP ile etkinleştir.

```dax
Varış Yolcusu =
CALCULATE([Toplam Yolcu], USERELATIONSHIP(hv_routes[dest], hv_airports[airport_code]))
```

Aynı iki tablo arasında USERELATIONSHIP pasif ilişkiyi açınca etkin olan (origin) bu hesap için kapanır. Ölçü olmadan aynı dilimleyici ESB’den kalkan yolcuyu verir.

### k10 · Ort. Erken Rezervasyon (gün)

*İpucu:* Satır satır DATEDIFF(BookTarih, uçuşun Tarih’i, DAY) hesapla ve AVERAGEX ile ortala; uçuş tarihini RELATED getirir.

```dax
Ort. Erken Rezervasyon (gün) =
AVERAGEX(hv_bookings, DATEDIFF(hv_bookings[BookTarih], RELATED(hv_flights[Tarih]), DAY))
```

Fark her rezervasyon için ayrı hesaplanmalı; önce ortalama tarih alıp fark almak anlamsızdır. Gün düzeyinde (saatsiz) tarih kullanıldı.

### k15 · Akşam Rötarı / Sefer

*İpucu:* Rötarlı Uçuş Başına Dakika ölçüsünü hv_flights[KalkisSaat] >= 18 filtresiyle CALCULATE et.

```dax
Akşam Rötarı / Sefer =
CALCULATE([Rötarlı Uçuş Başına Dakika], hv_flights[KalkisSaat] >= 18)
```

Filtre uçuş tablosunda; ilişki uçuştan rötar tablosuna doğru aktığı için rötar satırları da süzülür. Akşam seferlerinde zamanında kalkış oranı da belirgin düşüktür.

### k17 · Gelir Payı

*İpucu:* Payda için tier filtresini ALL(hv_passengers[tier]) ile kaldır.

```dax
Gelir Payı =
DIVIDE([Gelir], CALCULATE([Gelir], ALL(hv_passengers[tier])))
```

ALL yalnız tier sütununun filtresini kaldırır; başka dilimleyiciler (ay, sınıf) paydada korunur.

## İleri

### k11 · OTP Aylık Değişim

*İpucu:* Aynı ölçüyü PREVIOUSMONTH(Takvim[Tarih]) ile hesapla ve çıkar. Takvim tarih tablosu olarak işaretli olmalı.

```dax
OTP Aylık Değişim =
[Zamanında Kalkış Oranı] - CALCULATE([Zamanında Kalkış Oranı], PREVIOUSMONTH(Takvim[Tarih]))
```

PREVIOUSMONTH, seçili ayın tarihlerinden bir önceki ayın tarihlerini döndürür ve AyNo filtresinin yerini alır. Sonuç negatif: dakiklik kışla birlikte düşüyor.

### k12

*İpucu:* SUMMARIZECOLUMNS ile havalimanı başına [Rötar Dakikası], sonra TOPN(3, …, DESC).

```dax
EVALUATE
TOPN(
    3,
    SUMMARIZECOLUMNS(hv_airports[airport_code], "Rotar Dk", [Rötar Dakikası]),
    [Rotar Dk], DESC
)
ORDER BY [Rotar Dk] DESC
```

Filtre havalimanı → rota → uçuş → rötar zincirinde tek yönde akar. IST’nin önde olması hacimden gelir; adil kıyas için rötarlı uçuş başına dakikaya da bak.

### k13

*İpucu:* ADDCOLUMNS ile her rezervasyona gün farkını ve SWITCH(TRUE(), …) ile segmenti ekle; GROUPBY + CURRENTGROUP ile özetle.

```dax
EVALUATE
VAR T =
    ADDCOLUMNS(
        hv_bookings,
        "Segment",
            VAR g = DATEDIFF(hv_bookings[BookTarih], RELATED(hv_flights[Tarih]), DAY)
            RETURN SWITCH(TRUE(), g < 3, "1 Son dakika", g < 7, "2 Kısa", g < 21, "3 Orta", "4 Erken")
    )
RETURN
    GROUPBY(T, [Segment], "Adet", COUNTX(CURRENTGROUP(), hv_bookings[booking_id]), "Ort Fiyat", AVERAGEX(CURRENTGROUP(), hv_bookings[price]))
ORDER BY [Segment]
```

SWITCH(TRUE()) koşulları sırayla dener; ilk doğru dal kazanır, bu yüzden sınırlar küçükten büyüğe yazılır. Son dakika bileti erken alınana göre belirgin pahalı.

### k14 · Hava Rötarlı Yolcu

*İpucu:* hv_delays[reason] filtresi uçuş tablosuna akmaz (ilişki tek yönlü). Hava nedenli flight_id listesini TREATAS ile hv_flights[flight_id]’ye uygula.

```dax
Hava Rötarlı Yolcu =
CALCULATE([Toplam Yolcu], TREATAS(CALCULATETABLE(VALUES(hv_delays[flight_id]), hv_delays[reason] = "hava"), hv_flights[flight_id]))
```

CALCULATE([Toplam Yolcu], hv_delays[reason] = "hava") tüm yolcuyu (495.356) döndürür, çünkü filtre çok tarafından bir tarafına geçmez. SUMX(hv_delays, RELATED(pax)) ise iki nedenli seferleri çift sayar.

### k18 · Yolcu 7G Ortalama

*İpucu:* DATESINPERIOD(Takvim[Tarih], DATE(2024, 11, 30), -7, DAY) ile 7 günü al, AVERAGEX ile günlere ortala.

```dax
Yolcu 7G Ortalama =
AVERAGEX(DATESINPERIOD(Takvim[Tarih], DATE(2024, 11, 30), -7, DAY), [Toplam Yolcu])
```

AVERAGEX her tarih için [Toplam Yolcu]’yu bağlam geçişiyle hesaplar, sonra ortalar. Görselde DATE yerine MAX(Takvim[Tarih]) kullanınca hareketli ortalama olur.
