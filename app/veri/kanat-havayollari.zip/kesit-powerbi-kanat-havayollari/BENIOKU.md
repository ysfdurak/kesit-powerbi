# Kanat Havayolları · Kesit Power BI vaka paketi

**Sektör:** Havacılık · **Dönem:** Eylül–Aralık 2024

> Kışa girerken dakiklik neden düştü? Uçuş, rötar ve rezervasyon verisiyle operasyon ve gelir raporu.

Bu paketteki şirket, kişiler ve kayıtlar tamamen hayalidir. İçerik CC BY-NC 4.0 lisanslıdır: kaynak göstererek, ticari olmayan amaçlarla paylaşılabilir.

## Vaka

**Kanat Havayolları** hayali bir Türk havayoludur. İstanbul (IST ve SAW), Ankara ve İzmir merkezli 19 havalimanına uçar; 12'si yurt içi, 7'si yurt dışı. Filoda 15 uçak var. Eylül–Aralık 2024 arasında 3.173 sefer planlandı.

Operasyon direktörü yönetim kuruluna bir soruyla geliyor: **"Kışa girerken dakikliğimiz neden düştü ve bu müşteriye nasıl yansıdı?"** Zamanında kalkış oranı Eylül'de yüzde 68 civarındayken Aralık'ta yüzde 47'ye iniyor. Aynı dönemde iptaller artıyor. Ticari ekip ise başka bir şey soruyor: geç alınan biletler gerçekten daha mı pahalı, no-show (gelmeyen yolcu) ne kadar gelir bırakıyor?

**Paydaşlar:** Operasyon Kontrol Merkezi (günlük dakiklik ve rötar nedenleri), Gelir Yönetimi (doluluk, gelir/yolcu, erken rezervasyon), Kanat Mil sadakat ekibi (üye segmentleri) ve CFO (aylık özet).

**Veri:** Yedi CSV. Uçuşlar tablosu planlanan ve gerçekleşen kalkış/varış zamanlarını tutar. Rötar tablosunda 15 dakika ve üzeri gecikmelerin nedenleri vardır; bir uçuşun birden çok nedeni olabilir. Rezervasyonlar yalnızca Kanat Mil üyelerine aittir, uçağa binen tüm yolcuları değil. **Tüm zamanlar Türkiye saatidir (UTC+3)**; Frankfurt'a inen bir uçağın varış saati de İstanbul saatiyle yazılmıştır.

**Modelleme düğümleri:** Rotalar tablosunda kalkış (origin) ve varış (dest) aynı havalimanı tablosuna bağlanır: rol oynayan boyut (role-playing dimension). Rezervasyonun iki tarihi vardır: rezervasyon tarihi ve uçuş tarihi. Rötar tablosu uçuşa çoka-bir bağlıdır, yanlış sayımda rötarlı uçuşlar şişer.

**Senden beklenen:** CSV'leri Power Query'de temizle, yıldız şemayı kur, takvim tablosunu DAX ile oluştur. Sektörün ölçülerini yaz: zamanında kalkış oranı (15 dakika kuralı), iptal oranı, doluluk, rötar dakikası ve nedenleri, gelir/yolcu, erken rezervasyon süresi, no-show oranı. Sonra dört sayfalık bir rapor hazırla ve görevlerdeki sayıları paketteki beklenen değerlerle karşılaştır.

## Dosyalar

- `veri/` klasörü: CSV tabloları (UTF-8, virgülle ayrılmış, ondalık ayırıcı nokta, tarih YYYY-MM-DD)
- `olcular.dax`: ölçü kütüphanesi
- `gorevler.md`: görevler ve beklenen sonuçlar
- `cozumler.md`: örnek çözümler (önce kendin dene)

## Tablolar

### hv_airports (boyut)

Havalimanları (19)

| Sütun | Tür | Açıklama |
|---|---|---|
| airport_code | Metin | IATA kodu (IST, ESB, FRA…) — anahtar |
| name | Metin | Havalimanı adı |
| city | Metin | Şehir |
| country | Metin | Ülke |
| tz_offset | Tam sayı | UTC farkı (saat, kış saati). Veri Türkiye saatinde olduğu için yerel saat hesabında kullanılır |
| lat | Ondalık sayı | Enlem (harita görseli için Veri kategorisi: Enlem) |
| lon | Ondalık sayı | Boylam (Veri kategorisi: Boylam) |

### hv_aircraft (boyut)

Filo (15 uçak)

| Sütun | Tür | Açıklama |
|---|---|---|
| tail_no | Metin | Kuyruk tescili (TC-…) — anahtar |
| model | Metin | Uçak tipi |
| seats | Tam sayı | Koltuk sayısı (doluluk paydası) |
| year_built | Tam sayı | Üretim yılı |

### hv_routes (boyut)

Rotalar (45; her şehir çifti iki yönlü, ADB → FRA henüz uçuşu olmayan planlı rota)

| Sütun | Tür | Açıklama |
|---|---|---|
| route_id | Tam sayı | Rota numarası — anahtar |
| origin | Metin | Kalkış havalimanı (hv_airports ile etkin ilişki) |
| dest | Metin | Varış havalimanı (hv_airports ile pasif ilişki) |
| distance_km | Tam sayı | Büyük çember mesafesi (km) |
| block_min | Tam sayı | Planlanan uçuş süresi (dakika) |

### hv_flights (olgu)

Uçuşlar (3.173)

| Sütun | Tür | Açıklama |
|---|---|---|
| flight_id | Tam sayı | Uçuş kaydı — anahtar |
| flight_no | Metin | Sefer numarası (KN…); her gün tekrar eder, anahtar değildir |
| route_id | Tam sayı | Rota |
| tail_no | Metin | Uçak |
| sched_dep | Tarih/Saat | Planlanan kalkış (Türkiye saati) |
| sched_arr | Tarih/Saat | Planlanan varış (Türkiye saati; 156 sefer ertesi gün iner) |
| actual_dep | Tarih/Saat | Gerçek kalkış (iptalde boş) |
| actual_arr | Tarih/Saat | Gerçek varış (iptal ve yön değişikliğinde boş) |
| status | Metin | landed / cancelled / diverted |
| pax | Tam sayı | Uçağa binen yolcu sayısı (iptalde 0) |

### hv_delays (olgu)

Rötar nedenleri (1.350 satır, 1.228 uçuş)

| Sütun | Tür | Açıklama |
|---|---|---|
| flight_id | Tam sayı | Uçuş (bir uçuşta birden çok satır olabilir) |
| reason | Metin | gec_gelen_ucak / hava / teknik / yer_hizmetleri / hava_trafik |
| minutes | Tam sayı | Bu nedene bağlanan gecikme (dakika); bir uçuşun satırlarının toplamı kalkış rötarına eşittir |

### hv_passengers (boyut)

Kanat Mil üyeleri (900)

| Sütun | Tür | Açıklama |
|---|---|---|
| passenger_id | Tam sayı | Üye numarası — anahtar |
| full_name | Metin | Ad soyad |
| gender | Metin | E / K |
| birth_year | Tam sayı | Doğum yılı |
| city | Metin | Yaşadığı şehir (36 üyede boş) |
| tier | Metin | Classic / Silver / Gold / Elite |
| joined_date | Tarih | Üyelik tarihi |
| email | Metin | E-posta (64 üyede boş) |

### hv_bookings (olgu)

Rezervasyonlar (5.020)

| Sütun | Tür | Açıklama |
|---|---|---|
| booking_id | Tam sayı | Rezervasyon numarası — anahtar |
| passenger_id | Tam sayı | Yolcu |
| flight_id | Tam sayı | Uçuş |
| booked_at | Tarih/Saat | Rezervasyon zamanı (Haziran 2024’ten başlar) |
| fare_class | Metin | Eko / EkoFlex / Business |
| price | Sabit ondalık sayı | Ödenen tutar (₺) |
| status | Metin | flown / cancelled / no_show |
| bags | Tam sayı | Bagaj adedi |
| seat | Metin | Koltuk (12C gibi; iptalde boş) |

## Başlamadan önce

1. **Yerel ayar:** CSV’ler ondalık ayırıcı olarak nokta kullanır. Desktop Türkçe yerel ayardaysa yüklerken `-664.74` gibi değerler −66474’e dönüşür. Boş bir dosya açıp Dosya → Seçenekler ve ayarlar → Seçenekler → GEÇERLİ DOSYA → Bölgesel Ayarlar (Regional Settings) → İçeri aktarma için yerel ayar (Locale for import) değerini İngilizce (ABD) yap, sonra veriyi yükle. Ya da Power Query’de otomatik eklenen “Değiştirilen Tür” adımını silip türleri yerel ayarla yeniden ver: `Table.TransformColumnTypes(Kaynak, {{"amount", type number}}, "en-US")`.
2. **Otomatik ilişkileri kapat:** GEÇERLİ DOSYA → Veri Yükleme → İlişkiler altında “Veri yüklendikten sonra yeni ilişkileri otomatik algıla” seçeneğini kaldır. İlişkileri aşağıdaki listeye göre kendin kur; sonra Model → İlişkileri yönet listesini karşılaştır.
3. **Boş hücreler:** Boş tarih ve sayılar tür verilince null olur; boş metin hücreleri boş metin (“”) kalır. Gerekirse Değerleri değiştir ile null yap.
4. **Otomatik tarih/saat:** Kendi Takvim tablonu kullanacağın için GEÇERLİ DOSYA → Veri Yükleme altında “Otomatik tarih/saat” seçeneğini kapat.

## Hazırlık (Power Query)

1. **Veri al → Metin/CSV** ile yedi dosyayı yükle. Önizlemede **Dönüştür (Transform Data)** de; Power Query Düzenleyicisi açılır. Dosya kodlaması 65001 (UTF-8) olmalı, yoksa “İstanbul” bozuk görünür.
2. Veri türlerini kontrol et: `sched_dep`, `sched_arr`, `actual_dep`, `actual_arr`, `booked_at` → Tarih/Saat; `price` → Sabit ondalık sayı; `lat`/`lon` → Ondalık sayı. Bölgesel ayar Türkçe ise ondalık nokta yanlış okunabilir: sütunda **Türü değiştir → Yerel ayarı kullanarak (Using Locale)** ile “İngilizce (ABD)” seç.
3. Boş hücreler `null` gelmeli. `actual_dep` boşsa uçuş iptaldir; `actual_arr` boş ama `actual_dep` doluysa uçuş başka meydana yönlendirilmiştir (diverted). Bu satırları silme, durum bilgisi taşırlar.
4. hv_flights’e **Sütun ekle → Özel sütun**: `Tarih = Date.From([sched_dep])`, türü Tarih. Aynı yerde `KalkisSaat = Time.Hour([sched_dep])`, türü Tam sayı.
5. hv_bookings’e özel sütun: `BookTarih = Date.From([booked_at])`, türü Tarih. İlişki sütunlarının saat taşımaması önemli; Tarih/Saat sütunuyla takvime ilişki kurulursa eşleşme bozulur.
6. Saat dilimi: tüm zamanlar Türkiye saati (UTC+3). Yerel varış saati gerekiyorsa `sched_arr + #duration(0, [tz_offset] - 3, 0, 0)` ile hesaplanır (varış havalimanını birleştirerek). Bu pakette ölçüler Türkiye saatiyle çalışır; rapor başlıklarına “TSİ” notu düş.
7. **Yükle (Close & Apply)**. Ardından **Modelleme → Yeni tablo** ile aşağıdaki Takvim DAX’ını yaz.
8. Takvim’i seç → **Tablo araçları → Tarih tablosu olarak işaretle (Mark as date table)**, sütun: `Tarih`. `Ay` sütununu seç → **Sütuna göre sırala (Sort by column)** → `AyNo`; `HaftaninGunu` → `GunNo`.
9. **Model görünümü**nde ilişkileri kur. Desktop otomatik algılama yaptıysa kontrol et: `hv_routes[origin]` → `hv_airports[airport_code]` etkin, `hv_routes[dest]` → `hv_airports[airport_code]` pasif (kesikli çizgi). `hv_bookings[BookTarih]` → `Takvim[Tarih]` pasif. Tüm ilişkiler çoka-bir (*:1), çapraz filtre yönü **Tek (Single)**.
10. Alternatif tasarım (rol oynayan boyutu çoğaltmak): Power Query’de hv_airports’a sağ tık → **Başvuru (Reference)**, adını “Varış Havalimanı” yap ve `dest` ile etkin ilişki kur. Böylece matriste satırda kalkış, sütunda varış aynı anda kullanılabilir. Bu paketin beklenen değerleri tek havalimanı tablosu + USERELATIONSHIP tasarımıyla hesaplandı; iki tasarım aynı sayıları verir.
11. Ölçüler için boş bir tablo oluştur (**Giriş → Veri gir**, adı “_Ölçüler”) ve ölçüleri **Görüntüleme klasörü (Display folder)** ile grupla. Anahtar sütunları (flight_id, route_id…) **Rapor görünümünde gizle**.

### Türetilmiş sütunlar

- `hv_flights[Tarih]` ← `sched_dep` (date): Takvim ilişkisi için planlanan kalkışın tarihi (varış değil: gece yarısını geçen seferler kalkış gününe yazılır)
- `hv_flights[KalkisSaat]` ← `sched_dep` (hour): Sabah / akşam dalgası analizi için planlanan kalkış saati (0–23)
- `hv_bookings[BookTarih]` ← `booked_at` (date): Rezervasyon tarihine göre analiz için (Takvim ile pasif ilişki)

## Takvim tablosu

Modelleme → Yeni tablo:

```dax
Takvim =
VAR Gunler = CALENDAR(DATE(2024, 6, 1), DATE(2024, 12, 31))
RETURN
SELECTCOLUMNS(
    Gunler,
    "Tarih", [Date],
    "Yil", YEAR([Date]),
    "CeyrekNo", QUARTER([Date]),
    "Ceyrek", "Ç" & QUARTER([Date]),
    "AyNo", MONTH([Date]),
    "Ay", SWITCH(MONTH([Date]), 1, "Oca", 2, "Şub", 3, "Mar", 4, "Nis", 5, "May", 6, "Haz", 7, "Tem", 8, "Ağu", 9, "Eyl", 10, "Eki", 11, "Kas", 12, "Ara"),
    "YilAy", YEAR([Date]) & "-" & FORMAT(MONTH([Date]), "00"),
    "Gun", DAY([Date]),
    "GunNo", WEEKDAY([Date], 2),
    "HaftaninGunu", SWITCH(WEEKDAY([Date], 2), 1, "Pazartesi", 2, "Salı", 3, "Çarşamba", 4, "Perşembe", 5, "Cuma", 6, "Cumartesi", 7, "Pazar"),
    "HaftaSonu", IF(WEEKDAY([Date], 2) >= 6, "Evet", "Hayır")
)
```

Takvimi tarih tablosu olarak işaretle (Tablo araçları → Tarih tablosu olarak işaretle → Tarih) ve Ay sütununu AyNo’ya göre sırala.

## Model ve ilişkiler

- `hv_flights[route_id]` → `hv_routes[route_id]`
- `hv_routes[origin]` → `hv_airports[airport_code]`
- `hv_routes[dest]` → `hv_airports[airport_code]` **(pasif)**: Aynı iki tablo arasında yalnız bir etkin ilişki olabilir. Kalkış (origin) etkin; varış analizi USERELATIONSHIP ile. Görsellerde kalkış ve varışı aynı anda dilimlemek gerekiyorsa havalimanı tablosunu Power Query’de ikinci kez kullanmak (Kalkış Havalimanı / Varış Havalimanı) daha iyi tasarımdır.
- `hv_flights[tail_no]` → `hv_aircraft[tail_no]`
- `hv_delays[flight_id]` → `hv_flights[flight_id]`
- `hv_bookings[flight_id]` → `hv_flights[flight_id]`
- `hv_bookings[passenger_id]` → `hv_passengers[passenger_id]`
- `hv_flights[Tarih]` → `Takvim[Tarih]`
- `hv_bookings[BookTarih]` → `Takvim[Tarih]` **(pasif)**: Takvim rezervasyonlara zaten uçuşlar üzerinden (uçuş tarihi) ulaşır. Doğrudan ilişki etkin olsaydı iki yol belirsizlik (ambiguity) yaratırdı; bu yüzden pasif kalır ve rezervasyon tarihi ölçülerinde USERELATIONSHIP ile açılır.

## Rapor brifi

**Kanat Havayolları — Operasyon ve Gelir Raporu (Eyl–Ara 2024, TSİ)** · Operasyon direktörü, Operasyon Kontrol Merkezi, Gelir Yönetimi, CFO

### Sayfa 1: Genel Bakış

Dört ayın tek ekranda özeti: dakiklik, iptal, doluluk, gelir.

- Kart (Card) satırı: [Uçuş Sayısı], [Zamanında Kalkış Oranı], [İptal Oranı], [Doluluk Oranı], [Gelir], [No-Show Oranı]
- Çizgi ve kümelenmiş sütun grafiği: eksen Takvim[YilAy]; sütun [Gerçekleşen Uçuş], çizgi [Zamanında Kalkış Oranı]
- Harita (Map): hv_airports[lat]/[lon], kabarcık boyutu [Toplam Yolcu] (kalkışa göre)
- Yığılmış çubuk grafik: hv_delays[reason] × [Rötar Dakikası]

Etkileşimler:

- Takvim[Ay] ve hv_aircraft[model] dilimleyicileri; <b>Görünüm → Dilimleyicileri eşitle (Sync slicers)</b> ile tüm sayfalara bağla
- Kartlara koşullu biçimlendirme: OTP %60 altıysa kırmızı
- Başlıkta “Tüm saatler Türkiye saati (TSİ)” notu

### Sayfa 2: Dakiklik ve Rötar Analizi

Rötar nerede, ne zaman, neden? Kış etkisi ve akşam dalgası.

- Matris: satır hv_flights[KalkisSaat], sütun Takvim[Ay], değer [Zamanında Kalkış Oranı] (renk ölçeği)
- 100% yığılmış sütun: Takvim[Ay] × hv_delays[reason], değer [Rötar Dakikası]
- Çubuk grafik: hv_airports[city] × [Rötarlı Uçuş Başına Dakika] (TOPN 10 görsel filtresi)
- Alan parametresi (Field parameter) ile değiştirilebilen ölçü: [Zamanında Kalkış Oranı] / [İptal Oranı] / [Rötarlı Uçuş Başına Dakika]

Etkileşimler:

- <b>Modelleme → Yeni parametre → Alanlar</b> ile ölçü seçici
- Çubuktan uçuş detayına <b>Detaya git (Drillthrough)</b>
- Kalkış/varış görünümü için iki yer imi (Bookmark): biri [Toplam Yolcu], diğeri [Varış Yolcusu]

### Sayfa 3: Ticari Görünüm

Doluluk, gelir/yolcu, erken rezervasyon ve sadakat segmentleri.

- Dağılım grafiği (Scatter): her nokta hv_routes[route_id]; x [Doluluk Oranı], y [Gelir / Yolcu], boyut [Biletli Yolcu]
- Kümelenmiş sütun: hv_bookings[fare_class] × [Gelir / Yolcu]
- Çizgi grafik: Takvim[Tarih] × [Rezervasyon (Rezervasyon Tarihi)] (rezervasyon akışı Haziran’dan başlar)
- Halka grafik: hv_passengers[tier] × [Gelir]; kart [Ort. Erken Rezervasyon (gün)]

Etkileşimler:

- hv_passengers[tier] dilimleyicisi yalnız bu sayfada
- Dağılım grafiğinde nokta üzerine araç ipucu sayfası (Tooltip page)

### Sayfa 4: Uçuş Detayı (Detaya git) + Araç İpucu

Tek bir rota ya da uçağın sefer listesi; tooltip kartı.

- Tablo: hv_flights[flight_no], [sched_dep], [actual_dep], [status], [pax], rötar nedeni (hv_delays[reason])
- Kart: [Zamanında Kalkış Oranı], [Rötar Dakikası], [Doluluk Oranı]
- Ayrı araç ipucu sayfası (Sayfa bilgileri → Araç ipucu olarak kullan; Tuval ayarları → Araç ipucu boyutu): [Uçuş Sayısı], [İptal Oranı], [Gelir / Yolcu]

Etkileşimler:

- Detaya git alanları: hv_routes[route_id], hv_aircraft[tail_no]; “Tüm filtreleri koru” açık
- Geri düğmesi otomatik eklenir

## Veri ve modelleme tuzakları

- **Rötar tablosunda çift sayma:** hv_delays 1.350 satır ama 1.228 seferi anlatır; 122 seferin iki nedeni var. Rötarlı sefer için COUNTROWS değil DISTINCTCOUNT(hv_delays[flight_id]) kullan. SUMX(hv_delays, RELATED(hv_flights[pax])) ile yolcu toplarsan iki nedenli seferlerin yolcusu iki kez sayılır.
- **Filtre yönü:** rötar nedeni dilimleyicisi uçuş ve yolcu ölçülerini süzmez (ilişki uçuştan rötara tek yönlü). Çift yönlü yapmak yerine ölçüde TREATAS ya da CROSSFILTER kullan; model genelinde çift yön belirsizlik riski taşır.
- **Rol oynayan havalimanı:** origin ve dest aynı tabloya bağlı; yalnız biri etkin olabilir. Etkin ilişki kalkıştır; bir görsel “ESB” gösteriyorsa bu ESB’den kalkan seferdir. Kalkış ve varışı aynı görselde istiyorsan tabloyu Power Query’de Başvuru ile çoğalt.
- **İki tarih rolü:** rezervasyonlar takvime uçuş tarihi üzerinden ulaşır. Kasım için uçuş tarihine göre 1.201, rezervasyon tarihine göre 1.129 rezervasyon var. Rezervasyonlar Haziran 2024’te başladığı için takvim Haziran’dan başlar; Eylül’den başlatırsan erken rezervasyonlar boş tarihe düşer.
- **Gece yarısını geçen seferler ve saat dilimi:** 156 seferin planlanan varışı ertesi gündür; Tarih planlanan kalkıştan türetildi. Tüm zamanlar Türkiye saatidir; Londra varışı yerel saatle 3 saat erkendir. Varış saatine göre yerel analiz için tz_offset kullan.
- **Boş zamanlar ve durumlar:** 62 iptalde actual_dep ve actual_arr boş, 9 yön değiştiren seferde yalnız actual_arr boş. Dakiklikte payda gerçekleşen sefer olmalı; boş actual_dep için fark hesaplanırsa iptaller yanlışlıkla “zamanında” sayılabilir.
- **Üye verisi ≠ tüm yolcu:** rezervasyonlar yalnız Kanat Mil üyelerine ait (5.020 kayıt), hv_flights[pax] ise tüm yolcular (495.356). Gelir ölçüleri üye gelirini gösterir; doluluk pax’tan hesaplanır. İptal edilen 416 rezervasyonun 93’ü seferin iptalinden gelir. 112 üyenin hiç rezervasyonu yok; ADB → FRA rotasının hiç seferi yok.

## Portföyde nasıl anlatırsın

- Karar: “Kış dakiklik raporu” — zamanında kalkış oranının Eylül’den Aralık’a %68’den %47’ye düştüğünü, akşam dalgasının ve hava kaynaklı rötarların payını tek sayfada gösterdim; operasyon ekibine akşam seferlerinde tampon süre önerisi için veri sağladım.
- Modelleme: rol oynayan havalimanı boyutunu (kalkış etkin, varış pasif + USERELATIONSHIP) ve iki tarihli rezervasyon tablosunu belirsizlik yaratmadan kurdum; Learn’deki ilişki yolu önceliği kurallarına göre gerekçelendirdim.
- Doğruluk: çoka-bir rötar tablosunda çift sayımı DISTINCTCOUNT ve TREATAS ile engelledim; her ölçünün sonucunu bağımsız SQL sorgusuyla karşılaştırdım.
- Sektör KPI’ları: 15 dakika kuralıyla OTP, iptal oranı, doluluk (load factor), gelir/yolcu, erken rezervasyon süresi ve no-show oranını DAX ölçüsü olarak tanımlayıp görüntüleme klasörleriyle belgeledim.
- Mülakat cümlesi: “Bir filtrenin neden çalışmadığını ilişki yönünden açıklayabilirim: rötar nedeni uçuş tablosunu kendiliğinden süzmez, bunu ölçüde TREATAS ile çözdüm.”
