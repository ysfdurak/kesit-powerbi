# Kanat Havayolları · görevler

Her görevi Power BI Desktop’ta çöz ve sonucunu “Beklenen” değerle karşılaştır. Çözümler cozumler.md dosyasında.

## Temel

### k1 · İptal Oranı

Eylül–Aralık 2024’te planlanan seferlerin yüzde kaçı **iptal** edildi? (Filtre yok.)

**Beklenen:** %1,95

### k2 · Hava Rötarı (dk)

**Hava** nedenine bağlanan toplam rötar kaç dakika? (Filtre yok.)

**Beklenen:** 23.534 dk

### k3 · Doluluk Oranı

Dönemin genel **doluluk oranı** (yolcu / sunulan koltuk) nedir? (Filtre yok.)

**Beklenen:** %79,27

### k4 · No-Show Oranı

Biletli yolcular içinde **no-show** oranı nedir? (İptal edilen rezervasyonlar hariç, filtre yok.)

**Beklenen:** %3,45

### k5 · Rötarlı Uçuş

Kaç seferde **en az bir rötar nedeni** kayıtlı? (Filtre yok.)

**Beklenen:** 1.228

### k16 · Varışı Boş Sefer

Veri kalitesi: **gerçek varış zamanı boş** olan kaç sefer var? (Filtre yok.)

**Beklenen:** 71

## Orta

### k6 · Zamanında Kalkış Oranı

**Aralık 2024**’te zamanında kalkış oranı (15 dakika kuralı) nedir? (Takvim[AyNo] dilimleyicisinde 12 seçili.)

**Beklenen:** %47

### k7 · Gelir / Yolcu

**Business** sınıfında gelir/yolcu kaç ₺? (hv_bookings[fare_class] dilimleyicisinde Business seçili.)

**Beklenen:** 5.050,8929 ₺

### k8 · Rezervasyon (Rezervasyon Tarihi)

**Kasım 2024’te yapılan** (uçuşu değil, rezervasyonu Kasım’da olan) kaç rezervasyon var? (Takvim[AyNo] = 11 seçili.)

**Beklenen:** 1.129

### k9 · Varış Yolcusu

**Ankara Esenboğa’ya (ESB) inen** seferlerde kaç yolcu taşındı? (hv_airports[airport_code] dilimleyicisinde ESB seçili.)

**Beklenen:** 40.834

### k10 · Ort. Erken Rezervasyon (gün)

Üyeler biletlerini uçuştan **ortalama kaç gün önce** alıyor? (Tüm rezervasyonlar, filtre yok.)

**Beklenen:** 19,5279

### k15 · Akşam Rötarı / Sefer

**Akşam dalgasında** (planlanan kalkış saati 18:00 ve sonrası) rötarlı sefer başına ortalama rötar kaç dakika? (Filtre ölçünün içinde.)

**Beklenen:** 58,393 dk

### k17 · Gelir Payı

**Elite** üyeler toplam gelirin yüzde kaçını getiriyor? (hv_passengers[tier] dilimleyicisinde Elite seçili.)

**Beklenen:** %17,99

## İleri

### k11 · OTP Aylık Değişim

Aralık’ta zamanında kalkış oranı **bir önceki aya göre kaç puan** değişti? (Takvim[AyNo] = 12 seçili; sonuç oran farkı.)

**Beklenen:** %-12,12

### k12

Toplam rötar dakikasına göre **ilk 3 kalkış havalimanı** hangileri? (Sorgu; sütunlar: kod, dakika.)

**Beklenen:** `IST · 28.340`, `ADB · 8.018`, `ESB · 6.661`

### k13

Rezervasyonları erkenliğe göre segmentle: 0–2 gün “Son dakika”, 3–6 “Kısa”, 7–20 “Orta”, 21+ “Erken”. Segment başına adet ve ortalama fiyat nedir? (Sorgu; segment adına göre sıralı.)

**Beklenen:** `1 Son dakika · 536 · 2.819,6082`, `2 Kısa · 765 · 2.438,9281`, `3 Orta · 1.862 · 1.895,6122`, `4 Erken · 1.857 · 1.536,7394`

### k14 · Hava Rötarlı Yolcu

Rötar nedenleri arasında **hava** bulunan seferlerde toplam kaç yolcu vardı? (Filtre ölçünün içinde.)

**Beklenen:** 59.938

### k18 · Yolcu 7G Ortalama

30 Kasım 2024’te biten **7 günlük pencerede** günlük ortalama yolcu kaç? (Filtre yok; pencere ölçünün içinde.)

**Beklenen:** 3.921,4286
