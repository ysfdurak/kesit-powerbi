# Ilgaz Bank · Kesit Power BI vaka paketi

**Sektör:** Bankacılık · **Dönem:** Ocak–Aralık 2024

> 500 müşteri, 849 hesap ve 42 bin hareketle nakit akışı, kanal, döviz çevrimi ve şüpheli işlem analizi.

Bu paketteki şirket, kişiler ve kayıtlar tamamen hayalidir. İçerik CC BY-NC 4.0 lisanslıdır: kaynak göstererek, ticari olmayan amaçlarla paylaşılabilir.

## Başlamadan önce bil

- **Power BI Desktop gerekir ve Desktop yalnız Windows’ta çalışır.** Mac ya da telefonda CSV’lere bakabilirsin, görevleri yapamazsın.
- **Adımlar henüz gerçek Power BI Desktop’ta baştan sona denenmedi.** Beklenen sayılar Kesit Power BI’ın DAX’ı benzeten motorunda ve SQL’de hesaplandı; menü adları ve `olcular.dax` Desktop’ta çalıştırılmadı. Bir menü adı ya da adım tutmazsa hata sende olmayabilir.

## Vaka

**Ilgaz Bank**, 12 şubesi (biri yalnızca mobil ve internetten çalışan **Dijital Şube**) olan orta ölçekli, hayali bir bankadır. Müşteriler üç segmentte izlenir: Bireysel, KOBİ ve Özel Bankacılık. Her müşterinin bir vadesiz TL hesabı vardır. Bir kısmında kredi kartı ya da USD/EUR vadeli hesap da bulunur.

Yönetim kurulu 2024 yılını kapatırken üç soru soruyor: Para bankaya mı giriyor, bankadan mı çıkıyor? Müşteriler hangi kanalı kullanıyor, şube ağına hâlâ ihtiyaç var mı? Risk ekibinin "gece yarısı internet harcamaları" diye anlattığı vakalar gerçekten var mı?

Paydaşlar şunlar: **Bireysel Bankacılık Direktörü** segment ve şube performansını görmek istiyor. **Dijital Kanallar Müdürü** mobil ve internetin payını takip ediyor. **Hazine** döviz hesaplarının TL karşılığını soruyor. **Dolandırıcılık Önleme (Fraud) ekibi** ise kural tabanlı bir uyarı listesi bekliyor.

Elinde beş CSV var: müşteriler, hesaplar, şubeler, 2024'ün 42.284 hesap hareketi ve iş günü döviz kurları. Tutarlar **hesabın kendi para biriminde** tutuluyor. Giriş artı, çıkış eksi işaretli. Döviz hesaplarındaki tutarları TL'ye çevirmek için kur tablosu var. Ama kurlar yalnızca iş günleri için yayımlanmış ve faiz ay sonunda, bazen hafta sonuna denk gelen bir günde işleniyor.

Senden beklenen: Power Query'de veriyi temizleyip türetilmiş sütunları eklemen, kartopu (snowflake) biçimli bir model kurman (hareket → hesap → müşteri → şube), kur tablosunu ilişkisiz bırakıp çevrimi ölçüyle yapman, net nakit akışı, aktif müşteri, dijital kanal payı ve şüpheli işlem ölçülerini yazman. Sonra yönetime dört sayfalık bir rapor hazırlarsın. Veride bilerek bırakılmış izler var: kapanmış hesaplarda süren hareketler, açılış tarihinden önce görünen işlemler, kart limitini aşan harcamalar ve hafta sonu kur boşlukları. Bunları bulup raporda dürüstçe göstermek de işin parçası.

## Dosyalar

- `veri/` klasörü: CSV tabloları (UTF-8, virgülle ayrılmış, ondalık ayırıcı nokta, tarih YYYY-MM-DD)
- `olcular.dax`: ölçü kütüphanesi
- `gorevler.md`: görevler ve beklenen sonuçlar
- `cozumler.md`: örnek çözümler (önce kendin dene)

## Tablolar

### bank_txns (olgu)

Hesap hareketleri 2024 (42.284)

| Sütun | Tür | Açıklama |
|---|---|---|
| txn_id | Tam sayı | Hareket numarası (anahtar) |
| account_id | Tam sayı | Hareketin yapıldığı hesap → bank_accounts |
| txn_time | Tarih/Saat | İşlem zamanı |
| amount | Sabit ondalık sayı | Tutar, hesabın para biriminde; giriş artı, çıkış eksi |
| txn_type | Metin | maas / havale_giris / havale_cikis / kart_harcama / kart_odeme / fatura / atm / faiz |
| channel | Metin | mobil / internet / sube / atm / pos / sistem |
| merchant_category | Metin | Kart harcamalarında işyeri kategorisi; diğer işlemlerde boş |

### bank_accounts (boyut)

Hesaplar (849)

| Sütun | Tür | Açıklama |
|---|---|---|
| account_id | Tam sayı | Hesap numarası (anahtar) |
| customer_id | Tam sayı | Hesap sahibi → bank_customers |
| account_type | Metin | vadesiz / vadeli / kredi_karti |
| currency | Metin | TRY / USD / EUR |
| opened_date | Tarih | Açılış tarihi |
| closed_date | Tarih | Kapanış tarihi; açık hesapta boş |
| credit_limit | Sabit ondalık sayı | Kart limiti; yalnızca kredi kartında dolu |
| status | Metin | aktif / kapali |

### bank_customers (boyut)

Müşteriler (500)

| Sütun | Tür | Açıklama |
|---|---|---|
| customer_id | Tam sayı | Banka müşteri numarası (anahtar) |
| full_name | Metin | Ad soyad |
| gender | Metin | E / K |
| birth_date | Tarih | Doğum tarihi |
| city | Metin | Şehir (bağlı olduğu şubenin şehri) |
| segment | Metin | Bireysel / KOBİ / Özel Bankacılık |
| branch_id | Tam sayı | Bağlı olduğu şube → bank_branches |
| joined_date | Tarih | Müşteri olma tarihi |
| risk_score | Tam sayı | Kredi risk puanı (1 düşük – 10 yüksek) |
| kvkk_consent | Tam sayı | Pazarlama izni (1 var / 0 yok) |

### bank_branches (boyut)

Şubeler (12, biri dijital)

| Sütun | Tür | Açıklama |
|---|---|---|
| branch_id | Tam sayı | Şube numarası (anahtar) |
| name | Metin | Şube adı |
| city | Metin | Şehir |
| opened_year | Tam sayı | Açılış yılı |

### bank_fx (boyut)

İş günü döviz kurları 2024 (524)

| Sütun | Tür | Açıklama |
|---|---|---|
| rate_date | Tarih | Kur tarihi; hafta sonu yok |
| currency | Metin | USD / EUR |
| try_rate | Ondalık sayı | 1 birim dövizin TL karşılığı |

## Başlamadan önce

1. **Yerel ayar:** CSV’ler ondalık ayırıcı olarak nokta kullanır. Desktop Türkçe yerel ayardaysa yüklerken `-664.74` gibi değerler −66474’e dönüşür. Boş bir dosya açıp Dosya → Seçenekler ve ayarlar → Seçenekler → GEÇERLİ DOSYA → Bölgesel Ayarlar (Regional Settings) → İçeri aktarma için yerel ayar (Locale for import) değerini İngilizce (ABD) yap, sonra veriyi yükle. Ya da Power Query’de otomatik eklenen “Değiştirilen Tür” adımını silip türleri yerel ayarla yeniden ver: `Table.TransformColumnTypes(Kaynak, {{"amount", type number}}, "en-US")`.
2. **Otomatik ilişkileri kapat:** GEÇERLİ DOSYA → Veri Yükleme → İlişkiler altında “Veri yüklendikten sonra yeni ilişkileri otomatik algıla” seçeneğini kaldır. İlişkileri aşağıdaki listeye göre kendin kur; sonra Model → İlişkileri yönet listesini karşılaştır.
3. **Boş hücreler:** Boş tarih ve sayılar tür verilince null olur; boş metin hücreleri boş metin (“”) kalır. Gerekirse Değerleri değiştir ile null yap.
4. **Otomatik tarih/saat:** Kendi Takvim tablonu kullanacağın için GEÇERLİ DOSYA → Veri Yükleme altında “Otomatik tarih/saat” seçeneğini kapat.

## Hazırlık (Power Query)

1. Giriş (Home) → Veri al (Get data) → Metin/CSV (Text/CSV) ile beş dosyayı yükle. Dosya kökeni (File origin) **65001: Unicode (UTF-8)** olsun; yoksa "Kadıköy", "Özel Bankacılık" gibi değerler bozuk görünür.
2. Veriyi dönüştür (Transform data) ile Power Query'yi aç. `bank_txns[amount]` ve `bank_accounts[credit_limit]` için veri türünü **Sabit ondalık sayı (Fixed decimal number)** yap. Bölgesel ayar Türkçe ise ondalık nokta yanlış okunabilir: sütun başlığı → Tür değiştir → **Yerel ayarı kullanarak (Using locale)** → İngilizce (ABD). `bank_fx[try_rate]` için de aynısını yap. Not: Desktop dosyayı yüklerken kendi “Değiştirilen tür” adımını ekler; Türkçe yerel ayarda `-664.74` bu adımda −66474 olur ve sonradan tür değiştirmek geri getirmez. En güvenlisi, yüklemeden önce sayfanın başındaki “Başlamadan önce” kutusundaki dosya düzeyi ayarı yapmaktır.
3. `txn_time` türünü Tarih/Saat yap. Sütun ekle (Add column) → Özel sütun (Custom column) ile `Tarih = Date.From([txn_time])` (tür: Tarih) ve `Saat = Time.Hour([txn_time])` (tür: Tam sayı) ekle.
4. `closed_date` ve `merchant_category` boş hücreleri **null** olarak kalsın; boş metne ("") çevirme. Sütun kalitesi (Column quality) ve Sütun dağılımı (Column distribution) önizlemelerini Görünüm (View) sekmesinden aç; `closed_date` sütununda 806 boş, 43 dolu değer görmelisin (adetleri Sütun profili (Column profile) gösterir; Sütun kalitesi yüzde verir). CSV’den gelen boş metin hücreleri (ör. `merchant_category`) null değil boş metin olarak gelir; null istiyorsan Dönüştür → Değerleri değiştir ile boşu `null` yap.
5. `bank_fx` tablosunda (rate_date, currency) birlikte benzersizdir; tek başına hiçbir sütun benzersiz değildir. Bu yüzden tabloyla **ilişki kurma**. Kur çevrimini `Tutar TL` ölçüsü yapar. İstersen Power Query'de alternatif olarak sorguları birleştir (Merge queries) ile de çözülebilir; ama hafta sonu boşluğu için önce kur tablosunu tüm günlere doldurman gerekir (Doldur → Aşağı).
6. Model görünümünde ilişkileri kur: bank_txns[account_id] → bank_accounts, bank_accounts[customer_id] → bank_customers, bank_customers[branch_id] → bank_branches (hepsi çok-bir, tek yönlü). Ardından Takvim tablosunu oluştur ve bank_txns[Tarih] → Takvim[Tarih] etkin, bank_accounts[closed_date] → Takvim[Tarih] **etkin olmayan** ilişki olarak ekle.
7. Takvim için Modelleme (Modeling) → Yeni tablo (New table) ile aşağıdaki DAX'ı yapıştır. Sonra Tablo araçları (Table tools) → **Tarih tablosu olarak işaretle (Mark as date table)** → tarih sütunu: `Tarih`.
8. Rapor görünümünde (Report view) Veri (Data) bölmesinden Takvim[Ay] sütununu seç → Sütun araçları (Column tools) → **Sütuna göre sırala (Sort by column)** → `AyNo`. Aynısını HaftaninGunu → GunNo için yap. Böylece aylar Oca, Şub, Mar… sırasıyla görünür.
9. Anahtar sütunları (txn_id, account_id, customer_id, branch_id) ve Tarih/Saat kaynağını rapor görünümünden gizle (Rapor görünümünde gizle / Hide in report view). Ölçüleri bir `_Ölçüler` tablosunda ve görüntüleme klasörlerinde (Display folder) topla.

### Türetilmiş sütunlar

- `bank_txns[Tarih]` ← `txn_time` (date): Takvim ilişkisi için tarih-saatten yalnız tarih
- `bank_txns[Saat]` ← `txn_time` (hour): Gece işlemi kuralı ve saat dağılımı için (0–23)

## Takvim tablosu

Modelleme → Yeni tablo:

```dax
Takvim =
ADDCOLUMNS(
    CALENDAR(DATE(2024, 1, 1), DATE(2024, 12, 31)),
    "Tarih", [Date],
    "Yil", YEAR([Date]),
    "CeyrekNo", QUARTER([Date]),
    "Ceyrek", "Ç" & QUARTER([Date]),
    "AyNo", MONTH([Date]),
    "Ay", SWITCH(MONTH([Date]), 1, "Oca", 2, "Şub", 3, "Mar", 4, "Nis", 5, "May", 6, "Haz", 7, "Tem", 8, "Ağu", 9, "Eyl", 10, "Eki", 11, "Kas", "Ara"),
    "YilAy", YEAR([Date]) & "-" & RIGHT("0" & MONTH([Date]), 2),
    "Gun", DAY([Date]),
    "GunNo", WEEKDAY([Date], 2),
    "HaftaninGunu", SWITCH(WEEKDAY([Date], 2), 1, "Pazartesi", 2, "Salı", 3, "Çarşamba", 4, "Perşembe", 5, "Cuma", 6, "Cumartesi", "Pazar"),
    "HaftaSonu", IF(WEEKDAY([Date], 2) >= 6, "Evet", "Hayır")
)
-- CALENDAR [Date] sütununu da üretir. Tablo oluşunca [Date] sütununu gizle ya da SELECTCOLUMNS ile at; ilişkiyi Tarih sütunuyla kur.
```

Takvimi tarih tablosu olarak işaretle (Tablo araçları → Tarih tablosu olarak işaretle → Tarih) ve Ay sütununu AyNo’ya göre sırala.

## Model ve ilişkiler

- `bank_txns[account_id]` → `bank_accounts[account_id]`
- `bank_accounts[customer_id]` → `bank_customers[customer_id]`
- `bank_customers[branch_id]` → `bank_branches[branch_id]`
- `bank_txns[Tarih]` → `Takvim[Tarih]`
- `bank_accounts[closed_date]` → `Takvim[Tarih]` **(pasif)**: Kapanış tarihi ikinci bir tarih rolü. Etkin olsaydı Takvim → bank_txns için iki yol oluşur ve model belirsizleşirdi. Kapanan hesap sayısında USERELATIONSHIP ile açılır.

## Rapor brifi

**Ilgaz Bank 2024 — Nakit Akışı ve Risk Raporu** · Yönetim kurulu, Bireysel Bankacılık Direktörü, Dijital Kanallar Müdürü, Fraud ekibi

### Sayfa 1: Genel Bakış

Yılın nakit akışını ve müşteri tabanını tek bakışta göstermek.

- Kart (Card) ×4: Net Akış TL, Aktif Müşteri, Aktif Hesap, Dijital Kanal Payı
- Çizgi ve kümelenmiş sütun grafik (Line and clustered column): eksen Takvim[Ay]; sütunlar Giriş TL ve Çıkış TL; çizgi Net Akış 3 Ay Ort.
- Halka grafik (Donut): bank_txns[channel] × İşlem Sayısı
- Yığılmış çubuk (Stacked bar): bank_customers[segment] × Net Akış TL (Özel Bankacılık eksi görünür)

Etkileşimler:

- Takvim[Ceyrek] ve bank_customers[segment] dilimleyicileri; Görünüm → Dilimleyicileri eşitle (Sync slicers) ile tüm sayfalara bağla
- Kartlarda Net Akış Aylık Değişim % ile koşullu biçimlendirme (yeşil/kırmızı ok)

### Sayfa 2: Şube ve Kanal Analizi

Şube ağının ve kanalların performansını karşılaştırmak.

- Tablo (Table): bank_branches[name], bank_branches[city], Aktif Müşteri, Net Akış TL, Hesap Başına Net Akış; veri çubukları (Data bars) ile
- Matris (Matrix): satır bank_branches[name], sütun bank_txns[channel], değer İşlem Sayısı; arka plan rengi ısı haritası
- Şerit grafik (Ribbon chart): Takvim[Ay] × Dijital Kanal Payı kırılımı
- Alan parametresi (Field parameter): Net Akış TL / İşlem Sayısı / Kart Harcama TL arasında geçiş yapan tek grafik

Etkileşimler:

- Şube satırına sağ tık → Detaya git (Drill through) → Müşteri Detayı
- Alan parametresi dilimleyicisi ile ölçü değiştirme

### Sayfa 3: Risk ve Veri Kalitesi

Fraud ekibine kural tabanlı uyarı listesi ve veri sorunlarını göstermek.

- Kart ×4: Şüpheli İşlem, Şüpheli Tutar TL, Kapanış Sonrası İşlem, Kapanan Hesap
- Sütun grafik: bank_txns[Saat] (0–23) × İşlem Sayısı; gece saatlerindeki küçük tepe görünür
- Tablo: txn_time, account_id, amount, channel, merchant_category; görsel düzeyinde filtre Şüpheli İşlem = 1
- Dağılım grafiği (Scatter): kredi kartı başına credit_limit × Kart Harcama TL; limit çizgisinin üstü aşım

Etkileşimler:

- "Şüpheli" ve "Tüm işlemler" için iki yer işareti (Bookmark) ve bunlara bağlı düğmeler
- Tablo satırından Müşteri Detayı sayfasına detaya git

### Sayfa 4: Müşteri Detayı (detaya git)

Seçili şube ya da hesabın müşterilerini satır düzeyinde incelemek.

- Tablo: bank_customers[full_name], segment, risk_score, kvkk_consent, Aktif Hesap, Net Akış TL
- Çizgi grafik: Takvim[Tarih] × Net Akış YTD (seçili müşteri ya da şube için birikimli akış)
- Araç ipucu sayfası (Tooltip page, 320×240): segment, Ortalama Kart Harcaması, Dijital Kanal Payı; Genel Bakış'taki şube çubuğunun üzerine gelince açılır

Etkileşimler:

- Detaya git alanı: bank_branches[name] ve bank_accounts[account_id]; "Tüm filtreleri koru" açık
- Geri düğmesi (Back button) ile kaynak sayfaya dönüş

## Veri ve modelleme tuzakları

- **Para birimlerini toplamak.** SUM(amount) TL, USD ve EUR'yu aynı sayı gibi toplar. Fark küçük görünse de (125,01 M yerine 125,64 M) döviz hesabı analizinde tamamen yanlıştır: 19.556 "birim" aslında 644.621 TL. Fark etmek için bank_accounts[currency] ile kırılım yap; çözüm satır bazında kur çevrimi (Tutar TL).
- **Hafta sonu kur boşluğu.** bank_fx yalnızca iş günlerini içerir; faiz ise ayın son günü işlenir. 308 döviz hareketi tam tarih eşleşmesinde kursuz kalır ve TL karşılığı sıfır olur. Çözüm: işlem gününe eşit ya da önceki son kur (TOPN … DESC) ya da Power Query'de kur tablosunu tüm günlere doldurmak.
- **Bileşik anahtarlı kur tablosuyla ilişki.** bank_fx'te rate_date tek başına benzersiz değil (her gün USD ve EUR). Takvim ile çok-çok ilişki kurmak sonuçları sessizce bozar. Kur tablosunu ilişkisiz bırak ya da Power Query'de tarih+para birimi anahtarı üret.
- **Kapanmış hesapta hareket ve açılıştan önce hareket.** 84 satır kapanış tarihinden sonra, 172 satır açılış tarihinden önce görünüyor; 5 hesabın kapanışı açılışından bile önce. Kaynak, ay içindeki hareketleri tarih kontrolü yapmadan yazmış. Raporda bunları silme; ayrı bir "veri kalitesi" sayfasında say ve sahibine (BT) bildir.
- **Aktif müşteriyi yanlış tablodan saymak.** DISTINCTCOUNT(bank_accounts[customer_id]) hareket filtresinden etkilenmez ve hep 500 döner; 16 müşterinin yıl boyunca hiç hareketi yok. Filtre tek yönlü ilişkide birden çoka akar; hareketten müşteriye çıkmak için SUMMARIZE(bank_txns, …) kullan. Çift yönlü ilişkiyi (Both) hızlı çözüm diye açma.
- **Kart limiti ve limit aşımı.** 10.000 TL limitli kartlarda 25.000 TL'ye kadar harcama var; 231 hesap-ayda aylık harcama limiti aşıyor. Limit kontrolünü veriyle doğrula, "bankanın limit sistemi çalışıyor" varsayımıyla rapor yazma.
- **Aralık kart borcu.** Kart ödemesi ertesi ay yapılıyor; Aralık harcamalarının (1,94 M TL) ödemesi veride yok. Yıl sonu kart net akışı bu yüzden olduğundan kötü görünür. Raporda dipnotla açıkla.

## Portföyde nasıl anlatırsın

- Kartopu modeli (hareket → hesap → müşteri → şube) kurdum; filtre yönünü ve SUMMARIZE ile "hareketten müşteriye" sayımı bilinçli tasarladım, çift yönlü ilişkiye başvurmadım.
- Çok para birimli tutarları ilişkisiz bir kur tablosuyla, hafta sonu boşluğunu önceki iş günü kuruyla kapatarak TL'ye çevirdim; tam tarih eşleşmesinin döviz hesaplarını ~%34 eksik gösterdiğini kanıtladım.
- Fraud ekibiyle birlikte dört koşullu bir kural yazdım (gece + internet + e-ticaret + ≥25 bin TL): 25 işlem, 1,7 M TL. Bunların 3'ünün kapalı hesaplarda olduğunu bulup kuralı "kapanış sonrası işlem" sinyaliyle birleştirdim.
- Özel Bankacılık segmentinin net akışının eksi olduğunu, yani maaşların başka bankaya yattığını gösterdim; bu bulgu segment için maaş taşıma kampanyası önerisine dönüştü.
- Veri kalitesi sorunlarını (açılıştan önce hareket, limit aşımı, kursuz döviz işlemi) silmeden ölçülerle sayıp ayrı bir rapor sayfasında görünür kıldım.
