# Pusula A.Ş. İnsan Kaynakları · örnek çözümler

## Temel

### k1 · İşe Alım

*İpucu:* ik_employees ile Takvim arasındaki hire_date ilişkisi pasif. CALCULATE içinde USERELATIONSHIP ile aç.

```dax
İşe Alım =
CALCULATE(COUNTROWS(ik_employees), USERELATIONSHIP(ik_employees[hire_date], Takvim[Tarih]))
```

Takvim filtresi ancak hire_date ilişkisi etkinken çalışanlara ulaşır. USERELATIONSHIP bu ilişkiyi yalnız bu hesap için etkinleştirir.

### k2 · Gönüllü Ayrılan 2024

*İpucu:* [Ayrılan] ölçüsünü term_type = "gönüllü" filtresiyle CALCULATE içine al.

```dax
Gönüllü Ayrılan 2024 =
CALCULATE([Ayrılan], ik_employees[term_type] = "gönüllü")
```

[Ayrılan] term_date ilişkisini açar; ek filtre yalnız gönüllüleri bırakır. 2024'te 169 ayrılmanın 121'i gönüllü.

### k3 · Yıl Sonu Çalışan

*İpucu:* Satır saymak yetmez. Bağlamın son gününü MAX(Takvim[Tarih]) ile al ve o gün içeride olanları say: hire_date ≤ gün ve term_date boş ya da ≥ gün.

```dax
Yıl Sonu Çalışan =
[Çalışan Sayısı]
```

Çalışan bir olay değil, süre boyunca devam eden bir kayıttır. Takvim çalışanlara bağlı olmadığı için yalnız MAX tarihi okunur ve filtre ölçünün içinde kurulur.

### k4 · Hastalık İzni Günü

*İpucu:* ik_leaves[start_date] Takvim'e etkin bağlı. SUM(ik_leaves[days]) ve leave_type filtresi.

```dax
Hastalık İzni Günü =
CALCULATE(SUM(ik_leaves[days]), ik_leaves[leave_type] = "hastalık")
```

İzin başlangıç gününe göre dönemlenir. Yıl sınırını aşan izinlerin tamamı başladığı yıla yazılır; bu basitleştirmeyi raporda not et.

### k5 · Açık Talep

*İpucu:* ISBLANK(ik_requisitions[closed_date]) koşuluyla satır say; sonucu status = "açık" sayısıyla karşılaştır.

```dax
Açık Talep =
CALCULATE(COUNTROWS(ik_requisitions), ISBLANK(ik_requisitions[closed_date]))
```

Boş kapanış tarihi talebin sürdüğünü gösterir; status sütunuyla tutarlı (38 açık). Bu talepler işe alım süresi ortalamasına girmemeli.

## Orta

### o1 · Devir Hızı 2024

*İpucu:* [Ortalama Çalışan] = AVERAGEX(VALUES(Takvim[YilAy]), [Çalışan Sayısı]). Her ay satırında bağlam geçişi ay sonunu verir.

```dax
Devir Hızı 2024 =
DIVIDE([Ayrılan], AVERAGEX(VALUES(Takvim[YilAy]), [Çalışan Sayısı]))
```

Payda tek bir gün değil, yılın ortalama kadrosu. VALUES(Takvim[YilAy]) üzerinde gezinmek her ayı ayrı bağlama alır; [Çalışan Sayısı] o ayın son gününü okur.

### o2 · Pazartesi Hastalık Payı

*İpucu:* Payda: tüm hastalık izinleri. Pay: Takvim[GunNo] = 1. Takvim, ik_leaves[start_date] üzerinden izinleri süzer.

```dax
Pazartesi Hastalık Payı =
DIVIDE(CALCULATE([Hastalık İzni], Takvim[GunNo] = 1), [Hastalık İzni])
```

Yaklaşık üçte bir: beklenenin 1,6 katı. Yıllık izinlerde böyle bir yığılma yok; bu, hafta sonuna eklenen hastalık izinlerine işaret eder. Kişiyi değil örüntüyü raporla.

### o3 · eNPS Q4

*İpucu:* Destekçi 9–10, kötüleyen 0–6. Boş enps değerleri hem paydan hem paydadan çıkmalı. BLANK <= 6 koşulu DOĞRU döner.

```dax
eNPS Q4 =
[eNPS]
```

Q2'de yaklaşık sıfır olan eNPS Q4'te eksiye döndü (−2,8 puan). NOT ISBLANK unutulursa 41 boş yanıt kötüleyen sayılır ve skor yapay olarak düşer.

### o4 · İşe Alım Süresi (Kapanış)

*İpucu:* Takvim'in etkin ilişkisi opened_date üzerinde. CALCULATE([Ortalama İşe Alım Süresi], USERELATIONSHIP(ik_requisitions[closed_date], Takvim[Tarih])).

```dax
İşe Alım Süresi (Kapanış) =
CALCULATE([Ortalama İşe Alım Süresi], USERELATIONSHIP(ik_requisitions[closed_date], Takvim[Tarih]))
```

Rol oynayan tarih: aynı iki tablo arasında açılış etkin, kapanış pasif. USERELATIONSHIP kapanışı açınca açılış ilişkisi bu hesapta devre dışı kalır. Referans ve iç başvuruyla dolan talepler belirgin şekilde daha hızlı kapanıyor.

### o5 · İşe Alım Yıllık Değişim

*İpucu:* Önceki yılın değeri: CALCULATE([İşe Alım], SAMEPERIODLASTYEAR(Takvim[Tarih])). Fark / önceki yıl.

```dax
İşe Alım Yıllık Değişim =
VAR Bu = [İşe Alım]
VAR Onceki = CALCULATE([İşe Alım], SAMEPERIODLASTYEAR(Takvim[Tarih]))
RETURN
    DIVIDE(Bu - Onceki, Onceki)
```

Zaman zekâsı fonksiyonu Takvim üzerinde çalışır; [İşe Alım] içindeki USERELATIONSHIP kaydırılmış tarihleri çalışanlara taşır. 246 → 210, yaklaşık %14,6 düşüş.

### o6 · Ham Ücret Farkı 2024

*İpucu:* Her çalışanın maaşı ik_salaries'te effective_date ≤ gün olan son kayıttır. Önce [Maaş (Gün Sonu)], sonra içeride olanlar üzerinde AVERAGEX.

```dax
Ham Ücret Farkı 2024 =
[Ham Ücret Farkı]
```

Kadınlar ortalamada %7,3 daha az kazanıyor görünüyor. Ama bu sayı kadınların hangi bölüm ve seviyede yoğunlaştığını da içeriyor; “aynı işte eşit ücret” sorusunu yanıtlamaz (bkz. ileri görev).

### o7 · Referans İlk Yıl Ayrılma

*İpucu:* [İlk Yıl Ayrılma Oranı] kohort ölçüsü: payda işe girenler (hire_date ilişkisi), pay bunlardan DATEDIFF(hire_date, term_date, DAY) < 365 olanlar. 2024 kohortu henüz tamamlanmadığı için dışarıda.

```dax
Referans İlk Yıl Ayrılma =
[İlk Yıl Ayrılma Oranı]
```

Referansla gelenlerde ilk yıl ayrılma yaklaşık %10; kariyer sitesinde %19, ajansta %25. Referans adaylar mülakata da daha sık ulaşıyor ve performans puanları daha yüksek: kaynak kalitesi farkı.

## İleri

### i1 · Pozisyon İçi Ücret Farkı

*İpucu:* VALUES(ik_positions[position_id]) üzerinde ADDCOLUMNS ile her pozisyonun çalışan sayısını ve [Ham Ücret Farkı]'nı hesapla, boş farkları at, SUMX(n × fark) / SUMX(n).

```dax
Pozisyon İçi Ücret Farkı =
VAR Poz =
    FILTER(
        ADDCOLUMNS(VALUES(ik_positions[position_id]), "@n", [Çalışan Sayısı], "@fark", [Ham Ücret Farkı]),
        NOT ISBLANK([@fark])
    )
RETURN
    DIVIDE(SUMX(Poz, [@n] * [@fark]), SUMX(Poz, [@n]))
```

Ham %7,3'lük fark aynı pozisyonda %2,0'a iniyor. Yalnız seviyeye göre düzeltmek yetmez (yaklaşık %7,0 kalır): asıl karışım bölümler arasında, kadınlar daha düşük ücretli Çağrı Merkezi'nde yoğun. Kalan %2 açıklanamayan farktır ve politika konusudur.

### i2 · Melis Kurt Ekibi

*İpucu:* PATH(ik_employees[emp_id], ik_employees[manager_id]) her çalışan için “1|7|13|…” gibi bir yol üretir. FILTER içinde PATHCONTAINS(yol, 7) ile süz.

```dax
Melis Kurt Ekibi =
VAR Gun = DATE(2024, 12, 31)
RETURN
    COUNTROWS(
        FILTER(
            ik_employees,
            PATHCONTAINS(PATH(ik_employees[emp_id], ik_employees[manager_id]), 7)
                && ik_employees[emp_id] <> 7
                && ik_employees[hire_date] <= Gun
                && (ISBLANK(ik_employees[term_date]) || ik_employees[term_date] >= Gun)
        )
    )
```

PATH tüm hiyerarşiyi tek metinde toplar; PATHCONTAINS her kademede arar. Yazılım, Veri ve Analitik, BT Altyapı ekipleri bu ağacın altında. Aynı kalıp RLS kuralında yöneticinin yalnız kendi ağacını görmesini sağlar.

### i3 · Bant Altı Gönüllü Ayrılma

*İpucu:* FILTER(ik_employees, …) içinde CALCULATE([Maaş (Gün Sonu)], Takvim[Tarih] = Gun) o günkü maaşı verir; RELATED ile bandı oku. O gün içeride olup gönüllü ayrılan, zaten 1 Temmuz sonrası ayrılmıştır.

```dax
Bant Altı Gönüllü Ayrılma =
VAR Gun = DATE(2024, 7, 1)
VAR Dusuk =
    FILTER(
        ik_employees,
        ik_employees[hire_date] <= Gun
            && (ISBLANK(ik_employees[term_date]) || ik_employees[term_date] >= Gun)
            && DIVIDE(
                CALCULATE([Maaş (Gün Sonu)], Takvim[Tarih] = Gun),
                (RELATED(ik_positions[band_min]) + RELATED(ik_positions[band_max])) / 2
            ) < 0.9
    )
RETURN
    DIVIDE(COUNTROWS(FILTER(Dusuk, ik_employees[term_type] = "gönüllü")), COUNTROWS(Dusuk))
```

Bant ortasının %90'ının altındaki 560 kişiden 47'si altı ayda gönüllü ayrıldı (%8,4). %90–100 arasında %2,0, bant ortası ve üstünde %3,4. Bant altı maaş en güçlü ayrılma sinyallerinden biri.

### i4 · Zayıf Yönetici Puanı Ayrılma

*İpucu:* Anket tablosu çalışanları süzmez (filtre yönü çalışandan ankete). Sicilleri CALCULATETABLE(VALUES(ik_survey[emp_id]), …) ile topla, TREATAS ile ik_employees[emp_id]'ye uygula.

```dax
Zayıf Yönetici Puanı Ayrılma =
VAR Siciller =
    CALCULATETABLE(
        VALUES(ik_survey[emp_id]),
        ik_survey[wave] = "2024-Q2",
        ik_survey[manager_score] < 3,
        NOT ISBLANK(ik_survey[manager_score])
    )
RETURN
    CALCULATE(
        DIVIDE(
            COUNTROWS(FILTER(ik_employees, ik_employees[term_type] = "gönüllü" && ik_employees[term_date] > DATE(2024, 5, 15))),
            COUNTROWS(ik_employees)
        ),
        TREATAS(Siciller, ik_employees[emp_id])
    )
```

68 kişiden 9'u ayrıldı (%13,2); 3 ve üstü puan verenlerde oran %5,3. Düşük puanların tamamı Veri ve Analitik'in yeni yöneticisine (sicil 13) ait: ekibin 2024 gönüllü ayrılmalarının arkasındaki iz.

### i5 · En Cömert Değerlendirici

*İpucu:* VALUES(ik_reviews[reviewer_id]) üzerinde ADDCOLUMNS ile sayı ve ortalama, FILTER ile ≥ 20, TOPN(1, …, ortalama, DESC). Adı LOOKUPVALUE ile ik_employees'ten getir.

```dax
En Cömert Değerlendirici =
VAR Tablo =
    ADDCOLUMNS(
        VALUES(ik_reviews[reviewer_id]),
        "@adet", CALCULATE(COUNTROWS(ik_reviews)),
        "@ort", CALCULATE(AVERAGE(ik_reviews[rating]))
    )
VAR Ilk = TOPN(1, FILTER(Tablo, [@adet] >= 20), [@ort], DESC)
VAR Sicil = MAXX(Ilk, ik_reviews[reviewer_id])
RETURN
    LOOKUPVALUE(ik_employees[full_name], ik_employees[emp_id], Sicil)
```

Satış takım lideri İrem Acar 223 değerlendirmede ortalama 4,8 vermiş; diğerleri 3,3 civarında. Bu bir kalibrasyon sorunu: puanı terfi ya da prim kararında kullanmadan önce değerlendiriciye göre normalleştir. reviewer_id üzerinden pasif ilişki yerine burada ilişkisiz bir tablo kullanıldı; ik_employees'te RLS varsa USERELATIONSHIP hata verir.

### i6 · Veri Ekibi Devir Sırası

*İpucu:* RANKX(ALL(ik_departments[name]), [Gönüllü Devir Hızı]). ALL bölüm filtresini kaldırır, sıralama tüm bölümler arasında yapılır.

```dax
Veri Ekibi Devir Sırası =
RANKX(ALL(ik_departments[name]), [Gönüllü Devir Hızı])
```

Veri ve Analitik %17,6 ile yalnız Çağrı Merkezi'nin (%18,6) arkasında; şirket ortalamasının iki katından fazla. Ekip 2023 ortasında yönetici değiştirdi; anket puanlarıyla birlikte okununca bir yönetim sorunu görünür. Not: bölüm, çalışanın son pozisyonundan gelir.
