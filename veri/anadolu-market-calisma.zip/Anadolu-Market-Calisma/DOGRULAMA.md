# Kontrol değerleri

**Doğrulama durumu:** Windows'ta doğrulandı (28 Kasım 2026, Power BI Desktop, PBIP): aşağıdaki değerlerin hepsi Desktop sonucuyla birebir tuttu. Aynı turda yeni DAX işlevlerinden örneklem de denendi (PPMT, NPER, CONFIDENCE.T, INFO.VIEW.MEASURES = 80 ölçü). Değerler Kesit Power BI'ın tarayıcı motoruyla üretilir; Desktop'ta farklı bir sayı görürsen bildir.

| Kontrol | Beklenen |
|---|---|
| Satislar satır sayısı | 1620 |
| Net Satış (toplam) | 1.250.772,45 |
| Net Satış · 2022 | 102.837,2 |
| Net Satış · 2023 | 400.869,55 |
| Net Satış · 2024 | 747.065,7 |
| Net Satış · Elektronik | 339.303,65 |
| Net Satış · Ev & Yaşam | 234.252,75 |
| Net Satış · Giyim | 190.168,6 |
| Net Satış · Hediye | 17.370 |
| Net Satış · Kitap | 151.882,4 |
| Net Satış · Kozmetik | 133.563,95 |
| Net Satış · Spor | 184.231,1 |
| Sipariş Sayısı (toplam) | 838 |
| Müşteri Sayısı (toplam) | 136 |

DAX Sorgu Görünümü'nde tek seferde denemek için:

```dax
EVALUATE
SUMMARIZECOLUMNS(Tarih[Yil], "Net Satış", [Net Satış], "Sipariş Sayısı", [Sipariş Sayısı])
```
