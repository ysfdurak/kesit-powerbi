# Anadolu Market · Kesit Power BI çalışma paketi

Kesit Power BI derslerinin bütün alıştırmaları bu modelde yazılır. Bu paketle aynı modeli **Power BI Desktop'ta** açıp dersteki ölçüleri, görselleri ve ilişkileri kendi bilgisayarında kurabilirsin.

## Aç ve çalıştır

1. ZIP'in tamamını bir klasöre çıkar. `Anadolu-Market.pbip` ile `.Report` ve `.SemanticModel` klasörleri yan yana kalsın.
2. Windows'ta güncel Power BI Desktop ile `Anadolu-Market.pbip` dosyasını aç. Sürümün gerektiriyorsa **Dosya → Seçenekler ve ayarlar → Seçenekler → Önizleme özellikleri** bölümünde Power BI Project (.pbip) desteğini etkinleştir.
3. **Giriş → Yenile** ile tabloları yükle. Veri Power Query içine gömülüdür; internet ya da dosya yolu gerekmez. `Veri/` klasöründeki CSV kopyaları inceleme ve elle kurma içindir.
4. [DOGRULAMA.md](DOGRULAMA.md) içindeki kontrol sayılarını bir kart ya da tabloyla karşılaştır.

## İçinde ne var?

- 10 tablo: Satislar, Urunler, Musteriler, Tarih, Kategoriler, Hedefler, Calisanlar, Departmanlar, StokGorunum, OlcuSecimi.
- 11 ilişki (Satislar[TeslimTarihi] → Tarih ilişkisi pasif; USERELATIONSHIP dersleri için).
- 80 hazır ölçü (Satislar tablosunda; ifadeleri ayrıca `Olculer.dax` dosyasında).
- Boş bir rapor sayfası: görselleri sen kurarsın.

## Derslerle birlikte kullanmak

Her dersin konu sayfasında **Desktop'ta çalış** bölümü var. Oradan o dersin görev kâğıdını (.md) indir: her DAX alıştırmasının sorusu ve beklenen sonuç tablosu, her görsel alıştırmasının alanları ve beklenen değerleri, her model alıştırmasının kurulacak ilişkileri yazılıdır. Önce tarayıcıda dene, sonra Desktop'ta aynısını kur ve sonuçları karşılaştır.

## Bilinen farklar

- Kesit'in tarayıcı motoru Microsoft'un motoru değildir. Ölçülerin büyük çoğunluğu iki yerde aynı sonucu verir; farklı bir sonuç görürsen ders sayfasındaki **Sorun bildir** ile yaz.
- Model, öğretim için küçültülmüş sentetik veridir (Anadolu Market, 2022–2024).

Kaynak: [Kesit Power BI](https://ysfdurak.github.io/kesit-powerbi/) · Yusuf Durak. Veri ve içerik CC BY-NC 4.0, kod PolyForm Shield 1.0.0 kapsamındadır.
