# Lezzet Kurye · Power BI Desktop referans raporu

**Doğrulama durumu:** Kaynak veri, model başvuruları ve kontrol sonuçları dosya düzeyinde denetlendi. Power BI Desktop açılış, yenileme ve görsel denetimi bekliyor.

## Operasyon sorusu

**35 dakika içinde teslim oranı hangi ilçelerde düşüyor?** 1–14 Ekim 2024 tarihli 903 sentetik sipariş üzerinden önce genel durumu, ardından haftayı ve ilçeyi incele. Veri, Kesit Power BI’daki Lezzet Kurye vakasından alınan eğitim alt kümesidir.

## Aç ve çalıştır

1. ZIP’in tamamını bir klasöre çıkar. `Lezzet-Kurye.pbip` ile `.Report` ve `.SemanticModel` klasörleri yan yana kalsın.
2. Windows’ta güncel Power BI Desktop ile `Lezzet-Kurye.pbip` dosyasını aç. Sürümün gerektiriyorsa **Dosya → Seçenekler ve ayarlar → Seçenekler → Önizleme özellikleri** bölümünde Power BI Project ve geliştirilmiş rapor biçimi desteğini etkinleştirip Desktop’ı yeniden aç.
3. **Giriş → Yenile** ile gömülü üç tabloyu yükle. Veri Power Query içindedir. `Veri/` klasöründeki CSV kopyaları inceleme ve elle yeniden kurma içindir.
4. **Teslimat Özeti** sayfasında sipariş sayısını, teslim sayısını, 35 dakika uyumunu, medyan süreyi, günlük eğilimi ve durum dağılımını incele. **İlçe Performansı** sayfasında ilçelere göre bu ölçüleri karşılaştır.
5. Her iki sayfada hafta ve ilçe dilimleyicileri vardır. Önce ikisini temizle. Sonra `01–07 Ekim` ve `Kadıköy` seçerek [kontrol tablosundaki](DOGRULAMA.md) iki satırı karşılaştır. DAX Sorgu Görünümü’nde `Kontrol-Sorgusu.dax` içeriğini çalıştırarak beş senaryoyu tek seferde sınayabilirsin.

## Model ve iş kuralları

| Tablo | Tane düzeyi | İlişki |
|---|---|---|
| Tarih | Her takvim günü için bir satır | `Tarih[Tarih]` 1 → * `Sipariş[Sipariş Tarihi]` |
| Restoran | Her restoran için bir satır | `Restoran[RestoranID]` 1 → * `Sipariş[RestoranID]` |
| Sipariş | Her sipariş için bir satır | İki boyuttan da tek yönlü filtre alır |

- Tarih filtresi siparişin verildiği güne, ilçe filtresi restoranın ilçesine uygulanır.
- `teslim`, `iptal` ve `iade` ayrı durumlardır. SLA ve medyan hesabına yalnızca `teslim` durumundaki siparişler girer.
- SLA payı 2.100 saniye veya daha kısa sürede teslim edilen siparişlerdir. Payda teslim edilen tüm siparişlerdir. Medyan, teslim sürelerinin saniye cinsinden ortancasının 60’a bölümüdür.
- Sipariş, teslim, iptal, iade, SLA içi teslim, SLA oranı ve medyan süre için yedi DAX ölçüsü vardır. Ölçülerin tamamı model içinde ve `Olculer.dax` dosyasında bulunur.

## Elle yeniden kurma

Power BI Desktop’ta `Veri/` altındaki üç CSV’yi **Veri al → Metin/CSV** ile UTF‑8 olarak içe aktar. Tablo adlarını yukarıdaki gibi ver. Anahtar ve saniye alanlarını tam sayı, tarih alanlarını tarih, kalan sütunları metin yap. Model görünümünde iki etkin, bire-çok ve tek yönlü ilişkiyi kur. `Olculer.dax` içindeki ifadeleri sırasıyla **Yeni ölçü** ile Sipariş tablosuna ekle. Ardından yukarıdaki iki sayfayı oluştur ve [beklenen sonuçları](DOGRULAMA.md) kontrol et.

Kaynak: [Kesit Power BI – Yusuf Durak, Lezzet Kurye vaka paketi](https://ysfdurak.github.io/kesit-powerbi/veri/lezzet-kurye.zip). Referans raporu için tarih aralığı sınırlandı, sütunlar seçilip Türkçeleştirildi ve teslim süresi türetildi. Veri ve referans içerik CC BY-NC 4.0 kapsamındadır.
