# Lezzet Kurye · doğrulama kaydı

## Beklenen sonuçlar

| Hafta | İlçe | Sipariş | Teslim | İptal | İade | SLA içi | SLA uyumu | Medyan (dk) |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| Tümü | Tümü | 903 | 831 | 58 | 14 | 325 | %39,11 | 37,60 |
| 01–07 Ekim | Tümü | 432 | 396 | 26 | 10 | 180 | %45,45 | 36,24 |
| Tümü | Kadıköy | 188 | 174 | 11 | 3 | 53 | %30,46 | 39,36 |
| 01–07 Ekim | Kadıköy | 100 | 92 | 5 | 3 | 31 | %33,70 | 37,81 |
| 08–14 Ekim | Kadıköy | 88 | 82 | 6 | 0 | 22 | %26,83 | 42,025 |

Son satırdaki medyan yuvarlanmamış değerdir. Görselde iki ondalık basamak gösterilir. Sayımlar tam eşleşmeli. Oranlarda 0,01 yüzde puan, sürelerde 0,01 dakika görüntüleme toleransı kullan.

## İnceleme durumu

| Kontrol | Durum |
|---|---|
| Sipariş ve restoran anahtarları, tüm boyut eşleşmeleri, veri aralığı | Dosya düzeyinde geçti |
| Beş kontrol senaryosu | Kaynak sipariş kayıtlarından bağımsız hesaplandı |
| PBIP, PBIR ve model giriş dosyalarının JSON şemaları | 20/20 geçti |
| Görsel alanlarının modeldeki karşılıkları | 12/12 geçti |
| Modeldeki gömülü veri | CSV kopyaları ile bayt düzeyinde eşleşti |
| Power BI Desktop’ta projeyi açma ve üç tabloyu yenileme | Bekliyor |
| Beş DAX sonucunu ve iki rapor sayfasını Desktop’ta inceleme | Bekliyor |

Desktop inceleme kaydına tarihi, Desktop sürümünü, yenileme sonucunu, beş senaryonun gerçek değerlerini ve gözlenen farkları yaz.
