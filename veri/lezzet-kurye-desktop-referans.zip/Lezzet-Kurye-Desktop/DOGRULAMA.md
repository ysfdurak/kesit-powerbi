# Lezzet Kurye · doğrulama kaydı

## Beklenen sonuçlar

| Hafta | İlçe | Sipariş | Teslim | İptal | İade | SLA içi | SLA uyumu | Medyan (dk) |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| Tümü | Tümü | 903 | 831 | 58 | 14 | 325 | %39,11 | 37,60 |
| 01–07 Ekim | Tümü | 432 | 396 | 26 | 10 | 180 | %45,45 | 36,24 |
| Tümü | Kadıköy | 188 | 174 | 11 | 3 | 53 | %30,46 | 39,36 |
| 01–07 Ekim | Kadıköy | 100 | 92 | 5 | 3 | 31 | %33,70 | 37,81 |
| 08–14 Ekim | Kadıköy | 88 | 82 | 6 | 0 | 22 | %26,83 | 42,025 |

Son satırdaki medyan yuvarlanmamış değerdir. Görselde iki ondalık basamak gösterilir. Sayımlar tam eşleşmeli. Oranlarda 0,01 yüzde puan, sürelerde 0,01 dakika görüntüleme toleransı kullan.

## İnceleme durumu

| Kontrol | Durum |
|---|---|
| Sipariş ve restoran anahtarları, tüm boyut eşleşmeleri, veri aralığı | Dosya düzeyinde geçti |
| Beş kontrol senaryosu | Kaynak sipariş kayıtlarından bağımsız hesaplandı |
| PBIP, PBIR ve model giriş dosyalarının JSON şemaları | 20/20 geçti |
| Görsel alanlarının modeldeki karşılıkları | 12/12 geçti |
| Modeldeki gömülü veri | CSV kopyaları ile bayt düzeyinde eşleşti |
| Power BI Desktop’ta projeyi açma ve üç tabloyu yenileme | Geçti (22.11.2026, Desktop 2.159.1231.0, Ekim 2026) |
| Beş DAX sonucunu ve iki rapor sayfasını Desktop’ta inceleme | Geçti (22.11.2026) |

## Desktop inceleme kaydı

22 Kasım 2026, Power BI Desktop 2.159.1231.0 (Ekim 2026, Microsoft Store), Windows 11, tr-TR.

- **Açılış ve yenileme:** Proje açıldı. Üstteki uyarıda **Şimdi yenile** iki kez gerekti: ilk tıklama ilişki uyarısını kapatır, ikincisi üç tabloyu yükler. Yenileme hatasız tamamlandı.
- **Kontrol sorgusu:** `Kontrol-Sorgusu.dax`'ın beş satırı yukarıdaki tabloyla birebir aynı çıktı. Sayımlar tam tuttu. Oranlar 0,391095 / 0,454545 / 0,304598 / 0,336957 / 0,268293, medyanlar 37,6 / 36,2417 / 39,3583 / 37,8083 / 42,025.
- **Teslimat Özeti sayfası:** Kartlar 903, 831, %39,11 ve 37,60 gösterdi. Günlük eğilim ve durum dağılımı doğru çizildi.
- **İlçe Performansı sayfası:** Çubuk grafik ilçeleri SLA uyumuna göre sıralar. Karşıyaka'nın %0 görünmesi doğrudur: 4 siparişin hiçbiri 35 dakikada teslim edilmedi. Tablo ilk incelemede yalnız İlçe sütununu gösterdi ve görsel çizim hatası verdi. Nedeni, PBIR tablo projeksiyonundaki `"active": true` işaretiydi; Desktop bu durumda diğer sütunları gizli sayar. İşaret kaldırıldı. Düzeltilmiş pakette tablo sekiz sütunun hepsini gösterir; 903 / 831 / 58 / 14 / 325 / %39,11 / 37,60 toplamları tutar.
- **Kaydetme:** Desktop kaydederken anlam modelini TMDL biçimine yükseltmeyi önerebilir. Bu inceleme için gerekmez.
