# Pusula İK · görevler

Her görevi Power BI Desktop’ta çöz ve sonucunu “Beklenen” değerle karşılaştır. Çözümler cozumler.md dosyasında.

## Temel

### k1 · İşe Alım

2024 yılında kaç kişi işe girdi? Bağlam: Takvim[Yil] dilimleyicisinde 2024.

**Beklenen:** 210

### k2 · Gönüllü Ayrılan 2024

2024'te kaç kişi kendi isteğiyle (gönüllü) ayrıldı? Bağlam: Takvim[Yil] = 2024.

**Beklenen:** 121

### k3 · Yıl Sonu Çalışan

2024 yıl sonunda (31.12.2024) şirkette kaç kişi çalışıyor? Bağlam: Takvim[Yil] = 2024.

**Beklenen:** 1.407

### k4 · Hastalık İzni Günü

2024'te hastalık izni olarak toplam kaç iş günü kullanıldı? Bağlam: Takvim[Yil] = 2024.

**Beklenen:** 4.193

### k5 · Açık Talep

**Veri kalitesi:** Kapanış tarihi boş olan (hâlâ açık) kaç kadro talebi var? Bağlam: filtre yok.

**Beklenen:** 38

## Orta

### o1 · Devir Hızı 2024

Pusula'nın 2024 yıllık devir hızı nedir? Ayrılanları, 2024'ün 12 ay sonu çalışan sayısının ortalamasına böl. Bağlam: Takvim[Yil] = 2024.

**Beklenen:** %12,12

### o2 · Pazartesi Hastalık Payı

Hastalık izinlerinin yüzde kaçı **Pazartesi** başlıyor? Hafta içi beş gün eşit olsaydı %20 beklerdik. Bağlam: tüm dönem (2022–2024).

**Beklenen:** %32

### o3 · eNPS Q4

2024-Q4 anketinde eNPS kaç? Bağlam: ik_survey[wave] = "2024-Q4".

**Beklenen:** %-2,8

### o4 · İşe Alım Süresi (Kapanış)

2024'te **kapanan** (doldurulan) kadro taleplerinde ortalama işe alım süresi kaç gün? Bağlam: Takvim[Yil] = 2024; tarih olarak kapanış tarihi kullanılmalı.

**Beklenen:** 40,1333

### o5 · İşe Alım Yıllık Değişim

2024'teki işe alım sayısı 2023'e göre yüzde kaç değişti? Bağlam: Takvim[Yil] = 2024.

**Beklenen:** %-14,63

### o6 · Ham Ücret Farkı 2024

31.12.2024 itibarıyla **ham** cinsiyet ücret farkı nedir? (1 − kadın ortalama maaşı / erkek ortalama maaşı) Bağlam: Takvim[Yil] = 2024.

**Beklenen:** %7,31

### o7 · Referans İlk Yıl Ayrılma

2019–2023 arasında **referansla** işe girenlerin yüzde kaçı ilk 365 gününü doldurmadan ayrıldı? Bağlam: Takvim[Yil] 2019–2023, ik_employees[hire_source] = "referans".

**Beklenen:** %10,13

## İleri

### i1 · Pozisyon İçi Ücret Farkı

31.12.2024 itibarıyla **aynı pozisyondaki** (aynı bölüm ve seviye) kadın ve erkekler arasındaki ücret farkı, pozisyonların çalışan sayısıyla ağırlıklandırıldığında kaçtır? Her iki cinsiyetin de bulunmadığı pozisyonları hesaba katma. Bağlam: Takvim[Yil] = 2024.

**Beklenen:** %1,96

### i2 · Melis Kurt Ekibi

Yazılım Direktörü **Melis Kurt**'a (sicil 7) doğrudan ya da dolaylı bağlı, 31.12.2024'te çalışan kaç kişi var? Kendisini sayma. Bağlam: filtre yok; tarih ölçünün içinde.

**Beklenen:** 392

### i3 · Bant Altı Gönüllü Ayrılma

1 Temmuz 2024'te çalışan ve maaşı pozisyonunun bant ortasının %90'ından düşük olanların yüzde kaçı yılın geri kalanında **gönüllü** ayrıldı? Bant ortası = (band_min + band_max) / 2. Bağlam: filtre yok; tarih ölçünün içinde.

**Beklenen:** %8,39

### i4 · Zayıf Yönetici Puanı Ayrılma

2024-Q2 anketinde yöneticisine **3'ün altında** puan verenlerin yüzde kaçı anketten (15.05.2024) sonra gönüllü ayrıldı? Boş manager_score yanıtlarını dışarıda bırak. Bağlam: filtre yok.

**Beklenen:** %13,24

### i5 · En Cömert Değerlendirici

En az 20 değerlendirme yapmış yöneticiler arasında **ortalama puanı en yüksek** olan değerlendirici kim? Bağlam: filtre yok.

**Beklenen:** İrem Acar

### i6 · Veri Ekibi Devir Sırası

2024 gönüllü devir hızına göre bölümler sıralandığında **Veri ve Analitik** kaçıncı sırada? (1 = en yüksek) Bağlam: Takvim[Yil] = 2024, ik_departments[name] = "Veri ve Analitik".

**Beklenen:** 2
