# Pusula İK · Kesit Power BI vaka paketi

**Sektör:** İnsan kaynakları · **Dönem:** Ocak 2019 – Aralık 2024

> Çalışan sayısı, devir hızı, işe alım süresi ve ücret eşitliğini zaman aralıklı İK verisiyle doğru ölçmek

Bu paketteki şirket, kişiler ve kayıtlar tamamen hayalidir. İçerik CC BY-NC 4.0 lisanslıdır: kaynak göstererek, ticari olmayan amaçlarla paylaşılabilir.

## Vaka

**Pusula A.Ş.** mağaza, çağrı merkezi, lojistik ve teknoloji ekipleri olan, 12 bölümlü hayali bir perakende şirketi. 2024 sonunda **1.407** kişi çalışıyor. Altı yılda 2.199 kişinin kaydı birikti: işe girişler, terfiler, maaş değişiklikleri, performans puanları, izinler, kadro talepleri, adaylar, bağlılık anketi ve eğitimler.

Yönetim kurulu İK direktöründen tek sayfalık bir tablo istiyor: “Kaç kişiyiz, kimi neden kaybediyoruz, boş kadroyu ne kadar sürede dolduruyoruz, ücretlerimiz adil mi?” 2024'te 169 kişi ayrıldı. 2019'dan bu yana ayrılan 792 kişinin 221'i (%28) ilk yılını doldurmadan gitti. Veri ve Analitik ekibinde yönetici 2023 ortasında değişti, 2024'te bu ekipte 19 kişi kendi isteğiyle ayrıldı. Kadın çalışanların ortalama maaşı erkeklerden yaklaşık %7 düşük görünüyor; bunun ne kadarının aynı işte gerçek bir fark olduğu bilinmiyor.

**Paydaşlar:** İK direktörü (devir hızı ve işe alım hedefleri), bölüm yöneticileri (kendi ekiplerinin sayısı ve izinleri), ücret ve yan haklar ekibi (bant uyumu, ücret eşitliği), yönetim kurulu (özet KPI'lar).

**Senden beklenen:** 11 CSV'yi Power BI Desktop'a yükle, bir takvim tablosu kur, ilişkileri doğru yönde ve doğru etkinlikte bağla. İK verisinin zor yanı şu: çalışan bir “olay” değil, belli bir süre boyunca var olan bir kayıttır. Bu yüzden çalışan sayısını satır sayarak değil, “o gün içeride olanlar” diye sayacaksın. Maaşı da tarihe göre etkin olan son kayıttan okuyacaksın. Ardından devir hızını, ilk yıl ayrılmasını, işe alım süresini, eNPS'yi ve ücret farkını ölç. Yönetici hiyerarşisini PATH fonksiyonlarıyla aç. Veriye bilerek yerleştirilmiş izleri bul: bant altı maaş ve zayıf yönetici puanıyla artan ayrılma, Pazartesi yığılan hastalık izinleri, referansla gelenlerin daha uzun kalması, herkese yüksek puan veren bir yönetici.

**Gizlilik ve etik:** Bu veri hayali, ama gerçek İK verisi kişisel veridir; sağlık (hastalık izni), maaş ve performans bilgisi KVKK kapsamında özenle korunmalıdır. Raporu yayımlarken satır düzeyi güvenlik (RLS, row-level security) ile her yöneticinin yalnız kendi ekibini görmesini sağla. Ad soyad yerine sicil numarası göster, küçük grupları (ör. 5 kişiden az) tek tek gösterme. Ücret farkı analizini kişileri suçlamak için değil, politikayı düzeltmek için kullan.

## Dosyalar

- `veri/` klasörü: CSV tabloları (UTF-8, virgülle ayrılmış, ondalık ayırıcı nokta, tarih YYYY-MM-DD)
- `olcular.dax`: ölçü kütüphanesi
- `gorevler.md`: görevler ve beklenen sonuçlar
- `cozumler.md`: örnek çözümler (önce kendin dene)

## Tablolar

### ik_departments (boyut)

Bölümler (12)

| Sütun | Tür | Açıklama |
|---|---|---|
| dept_id | Tam sayı | Bölüm numarası (anahtar) |
| name | Metin | Bölüm adı |
| function_area | Metin | Fonksiyon: Yönetim / Ticari / Operasyon / Teknoloji / Destek |
| parent_id | Tam sayı | Üst bölüm (bölüm hiyerarşisi; Genel Müdürlük için boş) |

### ik_positions (boyut)

Pozisyonlar (67)

| Sütun | Tür | Açıklama |
|---|---|---|
| position_id | Tam sayı | Pozisyon numarası (anahtar) |
| title | Metin | Unvan |
| dept_id | Tam sayı | Bölüm → ik_departments |
| level | Tam sayı | Seviye: 1 Uzman Yardımcısı … 4 Takım Lideri, 5 Müdür, 6 Direktör |
| band_min | Sabit ondalık sayı | Maaş bandı alt sınırı (2024, aylık brüt TL) |
| band_max | Sabit ondalık sayı | Maaş bandı üst sınırı (2024, aylık brüt TL) |

### ik_employees (boyut)

Çalışanlar (2.199; 1.407 hâlâ çalışıyor)

| Sütun | Tür | Açıklama |
|---|---|---|
| emp_id | Tam sayı | Sicil numarası (anahtar) |
| full_name | Metin | Ad soyad (kişisel veri) |
| gender | Metin | K / E |
| birth_year | Tam sayı | Doğum yılı |
| city | Metin | Çalıştığı şehir |
| education | Metin | Eğitim düzeyi |
| hire_date | Tarih | İşe giriş tarihi |
| term_date | Tarih | Ayrılış tarihi (çalışıyorsa boş); bu gün hâlâ içeride sayılır |
| term_type | Metin | gönüllü / gönülsüz (çalışıyorsa boş) |
| term_reason | Metin | Ayrılış nedeni |
| position_id | Tam sayı | Güncel ya da son pozisyon → ik_positions |
| manager_id | Tam sayı | Yöneticisinin sicili (aynı tablo; hiyerarşi) |
| hire_source | Metin | İşe alım kaynağı: kariyer sitesi, LinkedIn, referans, ajans, üniversite, iç başvuru |
| work_mode | Metin | ofis / hibrit / uzaktan |

### ik_job_history (olgu)

Görev geçmişi (2.848)

| Sütun | Tür | Açıklama |
|---|---|---|
| emp_id | Tam sayı | Çalışan → ik_employees |
| position_id | Tam sayı | Pozisyon |
| start_date | Tarih | Görev başlangıcı |
| end_date | Tarih | Görev bitişi (devam ediyorsa boş) |
| change_type | Metin | işe giriş / terfi / yatay geçiş |

### ik_salaries (olgu)

Maaş geçmişi (11.352; zaman aralıklı)

| Sütun | Tür | Açıklama |
|---|---|---|
| emp_id | Tam sayı | Çalışan → ik_employees |
| effective_date | Tarih | Geçerlilik başlangıcı; bir sonraki kayda kadar geçerli |
| monthly_gross | Sabit ondalık sayı | Aylık brüt maaş (TL) |
| reason | Metin | devir (2019 açılış) / işe giriş / yıllık zam / ara zam / terfi / düzeltme |

### ik_reviews (olgu)

Yıl sonu performans değerlendirmeleri (6.618)

| Sütun | Tür | Açıklama |
|---|---|---|
| emp_id | Tam sayı | Değerlendirilen çalışan → ik_employees |
| review_year | Tam sayı | Değerlendirme yılı |
| rating | Tam sayı | Performans puanı (1–5) |
| potential | Metin | düşük / orta / yüksek (bazen boş) |
| reviewer_id | Tam sayı | Değerlendiren yöneticinin sicili |

### ik_leaves (olgu)

İzinler 2022–2024 (16.577)

| Sütun | Tür | Açıklama |
|---|---|---|
| leave_id | Tam sayı | İzin kaydı (anahtar) |
| emp_id | Tam sayı | Çalışan → ik_employees |
| leave_type | Metin | yıllık / hastalık / mazeret / ücretsiz |
| start_date | Tarih | İznin başladığı gün |
| days | Tam sayı | İş günü |

### ik_requisitions (olgu)

Kadro talepleri (807)

| Sütun | Tür | Açıklama |
|---|---|---|
| req_id | Tam sayı | Kadro talebi (anahtar) |
| position_id | Tam sayı | Pozisyon → ik_positions |
| opened_date | Tarih | Talebin açıldığı gün |
| closed_date | Tarih | Kapanış (dolduruldu ya da iptal; açıksa boş) |
| status | Metin | dolduruldu / açık / iptal |

### ik_candidates (olgu)

Adaylar (14.159)

| Sütun | Tür | Açıklama |
|---|---|---|
| cand_id | Tam sayı | Aday (anahtar) |
| req_id | Tam sayı | Kadro talebi → ik_requisitions |
| source | Metin | Aday kaynağı |
| applied_date | Tarih | Başvuru tarihi |
| stage | Metin | Ulaştığı son aşama: başvuru, ön eleme, mülakat, teklif, teklif reddedildi, işe alındı |
| stage_date | Tarih | Son aşama tarihi |
| emp_id | Tam sayı | İşe alındıysa sicil numarası (diğerlerinde boş) |

### ik_survey (olgu)

Bağlılık anketi yanıtları (2.222)

| Sütun | Tür | Açıklama |
|---|---|---|
| emp_id | Tam sayı | Çalışan → ik_employees |
| wave | Metin | Anket dönemi: 2024-Q2 (15 Mayıs) / 2024-Q4 (15 Kasım) |
| enps | Tam sayı | Tavsiye puanı 0–10 (bazen boş) |
| engagement | Ondalık sayı | Bağlılık 1–5 (bazen boş) |
| manager_score | Ondalık sayı | Yöneticiye verilen puan 1–5 (bazen boş) |

### ik_training (olgu)

Tamamlanan eğitimler 2022–2024 (3.126)

| Sütun | Tür | Açıklama |
|---|---|---|
| emp_id | Tam sayı | Çalışan → ik_employees |
| course | Metin | Eğitim adı |
| completed_date | Tarih | Tamamlanma tarihi |
| hours | Tam sayı | Eğitim saati |

## Başlamadan önce

1. **Yerel ayar:** CSV’ler ondalık ayırıcı olarak nokta kullanır. Desktop Türkçe yerel ayardaysa yüklerken `-664.74` gibi değerler −66474’e dönüşür. Boş bir dosya açıp Dosya → Seçenekler ve ayarlar → Seçenekler → GEÇERLİ DOSYA → Bölgesel Ayarlar (Regional Settings) → İçeri aktarma için yerel ayar (Locale for import) değerini İngilizce (ABD) yap, sonra veriyi yükle. Ya da Power Query’de otomatik eklenen “Değiştirilen Tür” adımını silip türleri yerel ayarla yeniden ver: `Table.TransformColumnTypes(Kaynak, {{"amount", type number}}, "en-US")`.
2. **Otomatik ilişkileri kapat:** GEÇERLİ DOSYA → Veri Yükleme → İlişkiler altında “Veri yüklendikten sonra yeni ilişkileri otomatik algıla” seçeneğini kaldır. İlişkileri aşağıdaki listeye göre kendin kur; sonra Model → İlişkileri yönet listesini karşılaştır.
3. **Boş hücreler:** Boş tarih ve sayılar tür verilince null olur; boş metin hücreleri boş metin (“”) kalır. Gerekirse Değerleri değiştir ile null yap.
4. **Otomatik tarih/saat:** Kendi Takvim tablonu kullanacağın için GEÇERLİ DOSYA → Veri Yükleme altında “Otomatik tarih/saat” seçeneğini kapat.

## Hazırlık (Power Query)

1. **Veri al → Metin/CSV** (Get data → Text/CSV) ile 11 dosyayı yükle. Her biri için **Verileri Dönüştür** (Transform Data) de; dosya kökeni 65001: Unicode (UTF-8) olsun, yoksa “Çağrı”, “gönüllü” gibi değerler bozulur.
2. Power Query'de veri türlerini düzelt: `*_date` sütunları **Tarih**, `monthly_gross`, `band_min`, `band_max` **Sabit ondalık sayı**, `engagement` ve `manager_score` **Ondalık sayı**. Bölgesel ayar nedeniyle “57700.0” 577000 olarak okunursa adımı **Yerel ayarı kullanarak** (Using Locale) İngilizce (ABD) ile değiştir.
3. Boş hücreler `null` gelmeli. `term_date`, `term_type`, `closed_date`, `ik_candidates[emp_id]`, `enps`, `manager_score` boşlukları bilgi taşır (hâlâ çalışıyor, talep açık, yanıt yok); bunları 0 ile doldurma.
4. ik_employees'e iki türetilmiş sütun ekle: **Sütun ekle → Tarih → Yıl → Yıl** (Add Column → Date → Year) ya da özel sütun `Date.Year([hire_date])` → adı `IseGirisYili`; aynısı `term_date` için → `AyrilisYili`.
5. **Modelleme → Yeni tablo** (Modeling → New table) ile aşağıdaki Takvim DAX'ını yapıştır. Takvim'i seç, **Tablo araçları → Tarih tablosu olarak işaretle** (Table tools → Mark as date table) ve tarih sütunu olarak `Tarih`'i seç.
6. Takvim[Ay] sütununu seç, **Sütun araçları → Sütuna göre sırala → AyNo** (Column tools → Sort by column); `HaftaninGunu` için de `GunNo`.
7. **Model görünümünde** ilişkileri listedeki gibi kur. ik_employees ile Takvim arasındaki iki ilişkiyi (`hire_date`, `term_date`) ve `ik_requisitions[closed_date]` ilişkisini **pasif** bırak: ilişki çizgisine çift tıkla → **Bu ilişkiyi etkin yap** (Make this relationship active) kutusunu kaldır. Çapraz filtre yönü **Tek** (Single) kalsın.
8. Anahtar ve teknik sütunları (`*_id`, `AyNo`, `GunNo`) rapor görünümünde gizle; bölüm, pozisyon ve takvim alanlarını boyut tablolarından kullan.
9. İsteğe bağlı hesaplanmış sütun: ik_employees'te `Yonetici Yolu = PATH(ik_employees[emp_id], ik_employees[manager_id])` ve `Kademe = PATHLENGTH([Yonetici Yolu])`. Bu veri setinde en derin yol 5 kademe.
10. **Gizlilik:** **Modelleme → Rolleri yönet** (Modeling → Manage roles) ile “Yönetici” rolü oluştur. ik_employees için DAX kuralı: kullanıcının sicilini `USERPRINCIPALNAME()` ile eşleyen bir e-posta tablosundan bul, `PATHCONTAINS(PATH(ik_employees[emp_id], ik_employees[manager_id]), sicil)` ile kendi ekibini süz. **Rol olarak görüntüle** (View as) ile dene. RLS yalnız Görüntüleyici (Viewer) rolündeki kullanıcılara uygulanır; çalışma alanı Yönetici/Üye/Katkıda bulunan rolleri tüm veriyi görür. **Dikkat:** RLS tanımlı bir tablo üzerinde USERELATIONSHIP kullanılamaz; İşe Alım, Ayrılan, İlk Yıl Ayrılma Oranı ve Devir Hızı ölçüleri “Rol olarak görüntüle” açıkken hata verir. RLS kuracaksan bu ölçüleri TREATAS ile yaz: `İşe Alım = CALCULATE(COUNTROWS(ik_employees), TREATAS(VALUES(Takvim[Tarih]), ik_employees[hire_date]))`; Ayrılan için aynısını `term_date` ile yap. Takvim çalışan tablosunu doğrudan süzmediği için sonuç değişmez.

### Türetilmiş sütunlar

- `ik_employees[IseGirisYili]` ← `hire_date` (year): İşe giriş kohortu (2019 öncesi işe girenler takvime bağlanmadığı için ayrı bir yıl sütunu gerekir)
- `ik_employees[AyrilisYili]` ← `term_date` (year): Ayrılanları yıla göre hızlı gruplamak için; çalışanlarda boş kalır

## Takvim tablosu

Modelleme → Yeni tablo:

```dax
Takvim =
ADDCOLUMNS(
    SELECTCOLUMNS(CALENDAR(DATE(2019, 1, 1), DATE(2024, 12, 31)), "Tarih", [Date]),
    "Yil", YEAR([Tarih]),
    "CeyrekNo", QUARTER([Tarih]),
    "Ceyrek", "Ç" & QUARTER([Tarih]),
    "AyNo", MONTH([Tarih]),
    "Ay", SWITCH(MONTH([Tarih]), 1, "Oca", 2, "Şub", 3, "Mar", 4, "Nis", 5, "May", 6, "Haz", 7, "Tem", 8, "Ağu", 9, "Eyl", 10, "Eki", 11, "Kas", 12, "Ara"),
    "YilAy", YEAR([Tarih]) & "-" & FORMAT(MONTH([Tarih]), "00"),
    "Gun", DAY([Tarih]),
    "GunNo", WEEKDAY([Tarih], 2),
    "HaftaninGunu", SWITCH(WEEKDAY([Tarih], 2), 1, "Pazartesi", 2, "Salı", 3, "Çarşamba", 4, "Perşembe", 5, "Cuma", 6, "Cumartesi", 7, "Pazar"),
    "HaftaSonu", IF(WEEKDAY([Tarih], 2) >= 6, "Evet", "Hayır")
)
```

Takvimi tarih tablosu olarak işaretle (Tablo araçları → Tarih tablosu olarak işaretle → Tarih) ve Ay sütununu AyNo’ya göre sırala.

## Model ve ilişkiler

- `ik_positions[dept_id]` → `ik_departments[dept_id]`
- `ik_employees[position_id]` → `ik_positions[position_id]`
- `ik_job_history[emp_id]` → `ik_employees[emp_id]`
- `ik_job_history[position_id]` → `ik_positions[position_id]` **(pasif)**: ik_job_history → ik_employees → ik_positions yolu zaten var; ikinci etkin yol belirsizlik (ambiguity) yaratır. Tarihsel pozisyon kırılımında USERELATIONSHIP ile aç.
- `ik_salaries[emp_id]` → `ik_employees[emp_id]`
- `ik_reviews[emp_id]` → `ik_employees[emp_id]`
- `ik_reviews[reviewer_id]` → `ik_employees[emp_id]` **(pasif)**: Aynı iki tablo arasında ikinci yol: değerlendiren yönetici. Gerektiğinde USERELATIONSHIP ile etkinleşir; ik_employees tablosunda RLS varsa bunun yerine TREATAS kullan.
- `ik_leaves[emp_id]` → `ik_employees[emp_id]`
- `ik_survey[emp_id]` → `ik_employees[emp_id]`
- `ik_training[emp_id]` → `ik_employees[emp_id]`
- `ik_requisitions[position_id]` → `ik_positions[position_id]`
- `ik_candidates[req_id]` → `ik_requisitions[req_id]`
- `ik_candidates[emp_id]` → `ik_employees[emp_id]` **(pasif)**: ik_candidates → ik_requisitions → ik_positions ile ik_candidates → ik_employees → ik_positions iki ayrı yol olur; biri pasif kalmalı.
- `ik_leaves[start_date]` → `Takvim[Tarih]`
- `ik_requisitions[opened_date]` → `Takvim[Tarih]`
- `ik_requisitions[closed_date]` → `Takvim[Tarih]` **(pasif)**: Rol oynayan tarih: “o ay kapanan talepler” için USERELATIONSHIP ile etkinleşir.
- `ik_employees[hire_date]` → `Takvim[Tarih]` **(pasif)**: Etkin olsaydı bir ay seçildiğinde yalnız o ay işe girenler görünür, anlık çalışan sayısı bozulurdu. İşe alım ölçüsünde USERELATIONSHIP ile açılır.
- `ik_employees[term_date]` → `Takvim[Tarih]` **(pasif)**: Ayrılan ölçüsü için ikinci rol oynayan tarih; USERELATIONSHIP ile açılır.

## Rapor brifi

**Pusula İK Panosu** · İK direktörü, bölüm yöneticileri, yönetim kurulu

### Sayfa 1: Genel bakış

Kadronun büyüklüğü ve yönü tek bakışta.

- Kart satırı: [Çalışan Sayısı] (yıl sonu), [İşe Alım], [Ayrılan], [Devir Hızı], [Gönüllü Devir Hızı], [eNPS]
- Çizgi grafik: X = Takvim[YilAy], değer = [Çalışan Sayısı] (ay sonu kadro); ikinci eksende [Devir Hızı]
- Kümelenmiş sütun: X = Takvim[Yil], değerler = [İşe Alım] ve [Ayrılan] (net değişimi gösterir)
- Yatay çubuk: ik_employees[term_reason] × [Gönüllü Ayrılan], azalan sırada

Etkileşimler:

- Dilimleyici: Takvim[Yil] ve ik_departments[function_area]; <b>Görünüm → Dilimleyicileri eşitle</b> (Sync slicers) ile tüm sayfalarda aynı
- Yer işareti (bookmark): “Yalnız gönüllü” görünümü, term_type filtresi uygulanmış hâli
- Kart araç ipuçlarında bir önceki yıla göre değişim

### Sayfa 2: Ayrılma analizi

Kimi, ne zaman ve neden kaybediyoruz?

- Matris: satır = ik_departments[name], sütun = Takvim[Yil], değer = [Gönüllü Devir Hızı]; koşullu biçimlendirme ile ısı haritası (Veri ve Analitik 2024 parlıyor)
- Sütun grafik: X = ik_employees[hire_source], değer = [İlk Yıl Ayrılma Oranı] (2019–2023 kohortları)
- Dağılım grafiği: her nokta bir bölüm, X = ortalama bant konumu, Y = [Gönüllü Devir Hızı], boyut = [Çalışan Sayısı]
- Alan parametresi (field parameter) ile ölçü seçici: [Devir Hızı] / [Gönüllü Devir Hızı] / [İlk Yıl Ayrılma Oranı]

Etkileşimler:

- Bölüm satırından <b>Detaya git</b> (drill through) ile “Ekip detayı” sayfasına
- Matrisin satır hiyerarşisi: function_area → name → pozisyon unvanı (detaya inme)

### Sayfa 3: Ücret ve eşitlik

Bant uyumu ve cinsiyet ücret farkı, ham ve düzeltilmiş.

- Kartlar: [Ham Ücret Farkı], pozisyon içi fark (görev i1 ölçüsü), [Bant Altı Çalışan]
- Kümelenmiş çubuk: satır = ik_positions[level], değerler = [Kadın Ortalama Maaş], [Erkek Ortalama Maaş]
- Tablo: pozisyon unvanı, çalışan sayısı, [Ham Ücret Farkı]; 5 kişiden az pozisyonlar görsel düzeyinde filtreyle gizli
- Metin kutusu: “Ham fark ≠ aynı işte fark” açıklaması ve yöntem notu

Etkileşimler:

- Takvim[Tarih] yalnız 2024 seçili kilitli filtre (bantlar 2024'e ait)
- Bu sayfa “Ücret” rolü dışındakilere yayımlanmaz; RLS ve ayrı uygulama kitlesi (app audience)

### Sayfa 4: Ekip detayı (detaya git)

Bir yöneticinin ya da bölümün ekibi; detaya git hedefi.

- Detaya git alanı: ik_departments[name]; geri düğmesi otomatik
- Tablo: sicil, unvan, kıdem, son performans puanı, anket yönetici puanı (ad soyad yerine sicil)
- Çizgi: [Hastalık İzni] × Takvim[HaftaninGunu] (Pazartesi yığılması)
- Huni: ik_candidates[stage] × aday sayısı, açık talepler için

Etkileşimler:

- Araç ipucu sayfası (tooltip page): bölüm üzerine gelince [Çalışan Sayısı], [Gönüllü Devir Hızı], [Ortalama İşe Alım Süresi], anket yönetici puanı ortalaması
- RLS “Yönetici” rolü bu sayfayı yalnız kendi ağacıyla gösterir

## Veri ve modelleme tuzakları

- **Çalışanı olay gibi saymak:** Takvim'i hire_date'e etkin bağlarsan ay seçince yalnız o ay işe girenler kalır, “çalışan sayısı” 1.407 yerine 12–25 çıkar. Fark etme: aylık kadro çizgisi testere dişi gibi iner çıkar. Çözüm: ilişkiyi pasif bırak, [Çalışan Sayısı]'nı MAX(Takvim[Tarih]) ile “o gün içeride olanlar” diye kur.
- **Ayrılıştan sonra kayıt:** 123 ayrılmış çalışanın ayrılış tarihinden sonra 129 maaş kaydı (114 ara zam, 15 terfi) ve 17 görev kaydı var; bu 17 satırda end_date, start_date'ten önce. Fark etme: COUNTROWS(FILTER(ik_salaries, ik_salaries[effective_date] > RELATED(ik_employees[term_date]))). Çözüm: Power Query'de bu satırları ayıkla ya da ölçülerde yalnız içeride olanları iterasyona al (bu paketteki ölçüler bunu yapıyor).
- **Bantlar 2024'e ait:** band_min / band_max 2024 maaşlarına göre kuruldu. 2019 maaşını bu banda bölersen yüksek enflasyon yüzünden herkes bant altı görünür. Bant ölçülerini yalnız 2024 tarihli bağlamda göster; sayfaya kilitli filtre koy.
- **BLANK sayılara karışır:** enps, engagement, manager_score bazı yanıtlarda boş. DAX'ta BLANK <= 6 ve BLANK < 3 DOĞRU döner; NOT ISBLANK eklemezsen boş yanıtlar “kötüleyen” ya da “düşük puan” sayılır. Ortalamalar (AVERAGE) boşları zaten atlar, sayımlar atlamaz.
- **Güncel durum sütunları tarihsel değildir:** ik_employees[position_id] ve manager_id son durumu gösterir. 2020'de Satış'tan Pazarlama'ya geçen biri 2020 kırılımında da Pazarlama'da görünür. Tarihsel bölüm kadrosu için ik_job_history'yi (pasif position_id ilişkisi) kullan.
- **Hayatta kalan yanlılığı ve takvim sınırı:** 2019 öncesinde ayrılanlar veri setinde yok; 2019'a devreden 861 kişinin hepsi 1.1.2019'da çalışıyor. Takvim 2019'da başladığı için 2010–2018 işe girişleri hire_date ilişkisinde (Boş) satıra düşer. Kohort analizlerini IseGirisYili ≥ 2019 ile sınırla.
- **Cömert değerlendirici:** Bir Satış takım lideri 223 değerlendirmesinin %80'ine 5 veriyor. Şirket geneli “ortalama performans” bu ekipte şişer, performans–ayrılma ilişkisi bulanıklaşır. Değerlendiriciye göre dağılımı kontrol et; gerekirse z-puanı ile normalleştir.

## Portföyde nasıl anlatırsın

- Zaman aralıklı İK verisinde “devam eden olay” desenini kurdum: anlık ve ay sonu çalışan sayısı, ortalama kadro ve yıllık devir hızı (%12,1). Takvim–çalışan ilişkilerini bilinçli olarak pasif bırakıp USERELATIONSHIP ile işe alım ve ayrılmayı ayrı ölçtüm.
- Cinsiyet ücret farkını üç katmanda gösterdim: ham %7,3, aynı seviyede %7,0, aynı pozisyonda %2,0. Mülakatta “karışım etkisi” ile “açıklanamayan fark” ayrımını ve hangi kararın hangisine dayanması gerektiğini anlatırım.
- Ayrılmanın üç sinyalini veriyle bağladım: bant ortasının %90'ı altında maaş (%8,4 vs %2,0–3,4), yöneticiye düşük anket puanı (%13,2 vs %5,3) ve işe alım kaynağı (referansta ilk yıl ayrılma %10, ajansta %25). Öneri: bant altı ve düşük puanlı ekipler için hedefli elde tutma bütçesi.
- PATH / PATHCONTAINS ile yönetici ağacını açtım ve aynı kalıbı RLS kuralına taşıdım: her yönetici yalnız kendi ekibini görüyor. KVKK açısından ad soyad yerine sicil, küçük grupları gizleme ve ücret sayfasını ayrı kitleye yayımlama kararlarını belgeledim.
- Veri kalitesi denetimi: ayrılış sonrası 129 maaş ve 17 görev kaydını, boş anket yanıtlarının eNPS'yi bozma riskini ve tek bir değerlendiricinin puan şişirmesini rapora not olarak ekledim.
