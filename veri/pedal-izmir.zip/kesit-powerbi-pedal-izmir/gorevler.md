# Pedal İzmir · görevler

Her görevi Power BI Desktop’ta çöz ve sonucunu “Beklenen” değerle karşılaştır. Çözümler cozumler.md dosyasında.

## Temel

### k1 · Ağustos Yolculuk

**Ağustos 2024**’te kaç yolculuk başladı? (Takvim[AyNo] = 8 dilimleyicisi seçili)

**Beklenen:** 39.389

### k2 · Kapanmamış Kontrol

Veri kalitesi: dönem boyunca **bitiş zamanı boş** (kapanmamış) kaç yolculuk var?

**Beklenen:** 316

### k3 · Ortalama Süre Kontrol

Tamamlanan yolculukların **ortalama süresi** kaç dakika? (filtre yok)

**Beklenen:** 29,268 dk

### k4 · Tek Seferlik Gelir

**Tek seferlik** kullanıcıların ödediği toplam ücret ne kadar? (dönemin tamamı)

**Beklenen:** 2.628.851,52 ₺

### k5 · Fren Bakım Süresi

**Fren** arızası için açılıp kapanmış bakım kayıtları ortalama kaç saat sürdü?

**Beklenen:** 21,3057

## Orta

### o1 · Sahil Çıkış Payı

Yolculukların yüzde kaçı **sahil istasyonlarından** (is_coastal = 1) başlıyor?

**Beklenen:** %53,4

### o2 · Elektrikli Hız

**Elektrikli** bisikletlerin ortalama hızı kaç km/sa? (bk_bikes[model] = "elektrikli" dilimleyicisi seçili)

**Beklenen:** 12,7969

### o3 · Abone Ücretli Oranı

Abonelik kuralı: tamamlanan **abone** yolculuklarının yüzde kaçı ücretli (30 dakikayı aşmış, fare > 0)?

**Beklenen:** %40,57

### o4 · Alsancak Varış

**Alsancak** ilçesindeki istasyonlara kaç yolculuk **vardı**? (bk_stations[district] = "Alsancak" dilimleyicisi seçili)

**Beklenen:** 20.834

### o5 · Ağustos Değişim

**Ağustos**’ta yolculuk sayısı Temmuz’a göre yüzde kaç değişti? (Takvim[AyNo] = 8 seçili)

**Beklenen:** %0,43

### o6 · Filo Kullanımı

Filonun yüzde kaçı dönem boyunca **en az bir kez** kullanıldı? (bisiklet kullanım oranı)

**Beklenen:** %100

### o7

Saat profili: **hafta içi** günlerde en çok yolculuğun başladığı 3 saat hangileri? (Saat ve yolculuk sayısı)

**Beklenen:** `18 · 10.912`, `8 · 9.676`, `17 · 9.132`

## İleri

### i1 · Yağmur Etkisi %

Yağmur etkisi: 10:00–19:59 arasında, **yağmurlu bir saatte** (rain_mm > 1) başlayan ortalama yolculuk sayısı, **kuru bir saate** (rain_mm = 0) göre yüzde kaç farklı?

**Beklenen:** %-77,37

### i2

İstasyon dengesizliği: **çıkış − varış** farkı en büyük (en hızlı boşalan) 3 istasyon hangileri?

**Beklenen:** `Alsancak Çarşı · 708`, `Alsancak Meydan · 674`, `Karşıyaka Park · 607`

### i3 · Yolculuk Sıcaklığı

**Temmuz**’da yolculukların başladığı saatteki **ortalama sıcaklık** kaç °C? (Takvim[AyNo] = 7 seçili)

**Beklenen:** 33,5813

### i4 · Toplama Tablosu Satırı

Performans: `bk_trips`’i **Tarih × Saat** düzeyinde özetleyen bir toplama tablosu kaç satır olur?

**Beklenen:** 2.035

### i5 · Yoğun Kullanıcı

Segmentasyon: dönem boyunca **30 veya daha fazla** yolculuk yapan “yoğun” kullanıcı kaç kişi?

**Beklenen:** 877

### i6 · Çakışan Yolculuk

Veri kalitesi: **539 numaralı bisiklet** için, aynı bisikletin önceki bir yolculuğu henüz bitmemişken başlayan kaç yolculuk var? (bk_bikes[bike_id] = 357 seçili)

**Beklenen:** 1
