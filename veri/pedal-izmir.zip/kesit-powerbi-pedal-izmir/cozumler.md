# Pedal İzmir · örnek çözümler

## Temel

### k1 · Ağustos Yolculuk

*İpucu:* Dilimleyici zaten bağlamı veriyor; yalnızca satır say.

```dax
Ağustos Yolculuk =
[Yolculuk Sayısı]
```

Takvim[Tarih] → bk_trips[Tarih] ilişkisi ay filtresini yolculuklara taşır. Yolculuk, başladığı güne sayılır.

### k2 · Kapanmamış Kontrol

*İpucu:* ended_at sütununda BLANK olan satırlar.

```dax
Kapanmamış Kontrol =
CALCULATE([Yolculuk Sayısı], ISBLANK(bk_trips[ended_at]))
```

Bu yolculuklarda varış istasyonu, mesafe ve ücret de boştur. Süre, gelir ve varış ölçüleri bu satırları dışarıda bırakır. Yolculuk sayısı ise onları sayar. Raporda bu fark açıkça gösterilmeli.

### k3 · Ortalama Süre Kontrol

*İpucu:* Bitiş − başlangıç gün cinsinden bir sayı verir; 1.440 ile çarp. Boş bitişleri dışarıda bırak.

```dax
Ortalama Süre Kontrol =
[Ortalama Süre (dk)]
```

SUMX satır satır süreyi hesaplar, DIVIDE tamamlanan yolculuk sayısına böler. Kapanmamış yolculukları paydaya katmak ortalamayı düşürür.

### k4 · Tek Seferlik Gelir

*İpucu:* Kullanıcı türü bk_users tablosunda; filtre ilişki üzerinden yolculuklara iner.

```dax
Tek Seferlik Gelir =
CALCULATE([Gelir], bk_users[user_type] = "tek seferlik")
```

Kullanıcıların %42’si tek seferlik ama gelirin yaklaşık %65’ini onlar getiriyor. Abonelerin çoğu 30 dakikanın altında kalıp ücret ödemiyor.

### k5 · Fren Bakım Süresi

*İpucu:* Hazır ölçüyü CALCULATE ile issue = "fren" bağlamında çalıştır.

```dax
Fren Bakım Süresi =
CALCULATE([Ortalama Bakım Süresi (saat)], bk_maintenance[issue] = "fren")
```

Açık kayıtların süresi henüz yok, ölçü onları FILTER ile dışarıda bırakır. 60 açık kayıt ayrı bir “bekleyen iş” kartında izlenmeli.

## Orta

### o1 · Sahil Çıkış Payı

*İpucu:* Pay: sahil filtresiyle yolculuk; payda: tüm yolculuklar. DIVIDE kullan.

```dax
Sahil Çıkış Payı =
DIVIDE(CALCULATE([Yolculuk Sayısı], bk_stations[is_coastal] = 1), CALCULATE([Yolculuk Sayısı], ALL(bk_stations)))
```

62 istasyonun 22’si sahilde ama yolculukların yarıdan fazlası oradan başlıyor. İstasyon başına bakınca sahil istasyonu iç kesimdekinin iki katından fazla çıkış alıyor.

### o2 · Elektrikli Hız

*İpucu:* Ortalama Hız ölçüsü toplam km’yi toplam saate böler; filtreyi dilimleyici verir.

```dax
Elektrikli Hız =
[Ortalama Hız (km/sa)]
```

Klasik bisikletle karşılaştır: elektrikli daha hızlıdır ve yolculuklar daha kısa sürer. Bu, abonelerin 30 dakikalık ücretsiz süreyi aşmadan daha uzağa gidebilmesi demektir.

### o3 · Abone Ücretli Oranı

*İpucu:* Pay ve paydada aynı kullanıcı türü filtresi; pay için ek olarak fare &gt; 0.

```dax
Abone Ücretli Oranı =
DIVIDE(CALCULATE([Yolculuk Sayısı], bk_users[user_type] = "abone", bk_trips[fare] > 0), CALCULATE([Tamamlanan Yolculuk], bk_users[user_type] = "abone"))
```

Abone gelirinin tamamı bu küçük gruptan gelir. Fiyat değişikliği konuşulacaksa (ör. ücretsiz süreyi 45 dakikaya çıkarmak) etkilenecek yolculuk payı budur.

### o4 · Alsancak Varış

*İpucu:* Etkin ilişki çıkış istasyonudur. Varış için pasif end_station ilişkisini aç.

```dax
Alsancak Varış =
[Varış Sayısı]
```

USERELATIONSHIP hesap süresince end_station ilişkisini etkin yapar; istasyon filtresi varışa uygulanır. Aynı dilimleyiciyle [Yolculuk Sayısı] çıkışları verir; ikisinin farkı ilçenin dengesidir.

### o5 · Ağustos Değişim

*İpucu:* PREVIOUSMONTH, bağlamdaki aydan bir önceki ayın tarihlerini döndürür.

```dax
Ağustos Değişim =
[Aylık Değişim %]
```

Ağustos 39.389, Temmuz 39.222 yolculuk: artış yaklaşık %0,43. Zaman zekâsı fonksiyonları işaretlenmiş bir Takvim tablosu ister. Haziran için önceki ay verisi olmadığından ölçü orada boş döner (DIVIDE sıfıra bölmeyi engeller).

### o6 · Filo Kullanımı

*İpucu:* Yolculuklardaki farklı bike_id sayısını bisiklet tablosundaki satır sayısına böl.

```dax
Filo Kullanımı =
[Bisiklet Kullanım Oranı]
```

700 bisikletin yalnızca 300’ü yola çıkmış; kullanılanlar ise günde 4’ten fazla yolculuk yapıyor. Ya kayıtlar yanlış bisiklete yazılıyor ya da filonun yarısı depoda. Bu kartı operasyon müdürüne götür.

### o7

*İpucu:* SUMMARIZECOLUMNS içine Takvim[HaftaSonu] = "Hayır" filtre tablosu ver, TOPN ile 3 satır al.

```dax
EVALUATE
TOPN(3,
    SUMMARIZECOLUMNS(bk_trips[Saat], FILTER(ALL(Takvim[HaftaSonu]), Takvim[HaftaSonu] = "Hayır"), "Yolculuk", [Yolculuk Sayısı]),
    [Yolculuk], DESC)
ORDER BY [Yolculuk] DESC
```

Hafta içi iki zirve var: sabah 8 ve akşam 17–18. Bu, işe gidiş-geliş kullanımıdır. Aynı sorguyu HaftaSonu = "Evet" ile çalıştırınca zirve öğleden sonraya kayar.

## İleri

### i1 · Yağmur Etkisi %

*İpucu:* Hava saatlerini iki gruba ayır, her grubun Tarih + Saat çiftlerini TREATAS ile bk_trips[Tarih], bk_trips[Saat] sütunlarına uygula. Saat başına yolculukları oranla.

```dax
Yağmur Etkisi % =
VAR Yagmurlu = FILTER(bk_weather, bk_weather[rain_mm] > 1 && bk_weather[Saat] >= 10 && bk_weather[Saat] <= 19)
VAR Kuru = FILTER(bk_weather, bk_weather[rain_mm] = 0 && bk_weather[Saat] >= 10 && bk_weather[Saat] <= 19)
VAR YagmurluYolculuk = CALCULATE([Yolculuk Sayısı], TREATAS(SELECTCOLUMNS(Yagmurlu, "T", bk_weather[Tarih], "S", bk_weather[Saat]), bk_trips[Tarih], bk_trips[Saat]))
VAR KuruYolculuk = CALCULATE([Yolculuk Sayısı], TREATAS(SELECTCOLUMNS(Kuru, "T", bk_weather[Tarih], "S", bk_weather[Saat]), bk_trips[Tarih], bk_trips[Saat]))
RETURN DIVIDE(DIVIDE(YagmurluYolculuk, COUNTROWS(Yagmurlu)), DIVIDE(KuruYolculuk, COUNTROWS(Kuru))) - 1
```

Karşılaştırmayı aynı saat aralığında yapmak önemli: yağmur yalnız gündüz yağdı. Tüm günün saatleriyle kıyaslarsan gece saatleri kuru tarafı düşürür, etki olduğundan küçük görünür. TREATAS iki sütunlu bir tabloyu iki sütuna birlikte uygular; ilişki kurmadan birleşik anahtar eşleşmesi yapar.

### i2

*İpucu:* Her istasyon için [İstasyon Dengesi] hesapla: çıkış etkin ilişkiden, varış USERELATIONSHIP ile gelir. TOPN ile sırala.

```dax
EVALUATE
TOPN(3,
    ADDCOLUMNS(VALUES(bk_stations[name]), "Denge", [İstasyon Dengesi]),
    [Denge], DESC)
ORDER BY [Denge] DESC
```

ADDCOLUMNS her istasyon satırında bağlam geçişi yapar; iki ölçü aynı istasyonu iki farklı ilişkiden görür. Artı denge gerçek bir sistemde istasyonun boşaldığını, eksi denge (ör. Bayraklı Kordon) dolduğunu gösterir. Bu veride bisiklet konumu izlenmediği için sonuç yöntemi öğretir, kamyon kararına dayanak olmaz.

### i3 · Yolculuk Sıcaklığı

*İpucu:* Her yolculuk için LOOKUPVALUE ile bk_weather’dan Tarih ve Saat’i eşleşen temp_c değerini getir, AVERAGEX ile ortala.

```dax
Yolculuk Sıcaklığı =
AVERAGEX(bk_trips, LOOKUPVALUE(bk_weather[temp_c], bk_weather[Tarih], bk_trips[Tarih], bk_weather[Saat], bk_trips[Saat]))
```

LOOKUPVALUE iki arama sütunu alabilir; birleşik anahtarı ilişkisiz eşleştirir. 39 bin satırda her satır için arama yapar, büyük tabloda pahalıdır. Sık kullanılacaksa sıcaklığı Power Query’de birleştirme (Merge) ile yolculuk tablosuna taşımak ya da Tarih × Saat toplama tablosunda hesaplamak daha iyidir. Kıyas için: Temmuz’un saatlik ortalama sıcaklığı 31,8 °C. Yolculuklar gündüz ve akşam yapıldığı için bu değerden yüksek, ama 12–16 arasının 35–37 °C’sinin altında kalır: öğle sıcağında kullanım düşer.

### i4 · Toplama Tablosu Satırı

*İpucu:* SUMMARIZE ile iki sütunun dolu birleşimlerini al, COUNTROWS ile say.

```dax
Toplama Tablosu Satırı =
COUNTROWS(SUMMARIZE(bk_trips, bk_trips[Tarih], bk_trips[Saat]))
```

116.517 satır yerine 2.035 satır, yaklaşık 57 kat küçülme. 92 gün × 24 saat = 2.208 olası saatin bir kısmında (çoğu gece 03–05) hiç yolculuk yok. İstasyonu da eklersen 59.653 satır olur; toplamanın faydası gruplama düzeyine bağlıdır.

### i5 · Yoğun Kullanıcı

*İpucu:* Kullanıcı listesinde gezin, her kullanıcı için [Yolculuk Sayısı]’nı bağlam geçişiyle hesapla, eşiği geçenleri say. SWITCH(TRUE()) ile segment sütunu da kurabilirsin.

```dax
Yoğun Kullanıcı =
COUNTROWS(FILTER(VALUES(bk_users[user_id]), [Yolculuk Sayısı] >= 30))
```

FILTER içinde ölçü çağırmak her kullanıcı satırında bağlam geçişi yapar. Segment ölçüsü için: SWITCH(TRUE(), [Yolculuk Sayısı] >= 30, "Yoğun", [Yolculuk Sayısı] >= 10, "Düzenli", "Ara sıra").

### i6 · Çakışan Yolculuk

*İpucu:* Bisikletin yolculuklarını bir değişkene al. Her yolculuk için başlangıcını sakla; daha önce başlamış ve bitişi bu başlangıçtan sonra olan (ya da boş olan) başka bir yolculuk var mı bak.

```dax
Çakışan Yolculuk =
VAR Yolculuklar = CALCULATETABLE(bk_trips)
RETURN COUNTROWS(FILTER(Yolculuklar,
    VAR Bas = bk_trips[started_at]
    VAR No = bk_trips[trip_id]
    RETURN NOT ISEMPTY(FILTER(Yolculuklar, bk_trips[trip_id] <> No && bk_trips[started_at] <= Bas && (ISBLANK(bk_trips[ended_at]) || bk_trips[ended_at] > Bas)))))
```

Fiziksel bir bisiklet aynı anda iki yolculukta olamaz. Bu kadar çakışma, kilit cihazının yanlış bisiklet numarası gönderdiğine ya da kayıtların birleştirildiğine işaret eder. Bu kontrol 600 satırlık bir bisiklette hızlıdır; tüm tabloda iç içe FILTER çok yavaşlar, toplu kontrolü Power Query ya da kaynak sistemde yap.
