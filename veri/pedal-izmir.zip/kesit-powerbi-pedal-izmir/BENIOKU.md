# Pedal İzmir · Kesit Power BI vaka paketi

**Sektör:** Kentsel ulaşım / mikromobilite · **Dönem:** Haziran–Ağustos 2024

> 116.517 yolculuk, saatlik hava durumu ve 62 istasyonla bir yaz boyunca İzmir’in bisiklet paylaşım sistemini modelle: zirve saatleri, yağmur etkisi, istasyon dengesizliği ve filo kullanımı.

Bu paketteki şirket, kişiler ve kayıtlar tamamen hayalidir. İçerik CC BY-NC 4.0 lisanslıdır: kaynak göstererek, ticari olmayan amaçlarla paylaşılabilir.

## Vaka

**Pedal İzmir**, İzmir’de 10 ilçede 62 istasyon ve 700 bisikletle çalışan hayali bir bisiklet paylaşım sistemidir. Filonun dörtte biri elektriklidir. Sisteme kayıtlı 6.000 kullanıcının 3.480’i **abone**, geri kalanı **tek seferlik** kullanıcıdır. Haziran–Ağustos 2024 arasında 116.517 yolculuk yapıldı.

Yaz bitti ve belediye ile yapılan sözleşme yenilenecek. Belediye üç soru soruyor: “Sistem kimin işine yarıyor, işe gidip gelene mi, sahilde gezene mi?”, “Hava kötü olunca ne oluyor?” ve “Neden bazı istasyonlarda hiç bisiklet kalmıyor, bazılarında yuva bulunmuyor?” Operasyon müdürü ise filonun bir kısmının hiç yola çıkmadığından şüpheleniyor. Bakım ekibi de kayıtların uzun süre açık kaldığını söylüyor.

Elinde altı CSV var. `bk_trips` büyük bir tablo. Her satırda başlangıç ve bitiş istasyonu, saniyeli tarih-saat, mesafe ve ücret var. Hava durumu ise **saatlik** tutuluyor (`bk_weather`). Yolculukla hava arasında hazır bir anahtar yok. Eşleştirmeyi saat başına yuvarlanmış bir anahtarla sen kuracaksın. İstasyon tablosu yolculuğa iki kez bağlanıyor: bir kez çıkış, bir kez varış istasyonu olarak. Ücret kuralı basit ama analizde önemli. Abonelerin ilk 30 dakikası ücretsiz, sonrası dakikası 2 TL. Tek seferlik kullanıcı 10 TL açılış ve dakikası 1,5 TL öder.

**Paydaşlar:** belediyenin ulaşım dairesi (sözleşme ve yatırım kararı), operasyon müdürü (bisiklet dağıtımı), bakım şefi (atölye kapasitesi), pazarlama (abonelik kampanyası).

**Senden beklenen:** CSV’leri Power BI Desktop’a yükle. Büyük tabloyu gereksiz sütunlardan arındır ve tarih-saati tarih ve saat olarak böl. Rol oynayan istasyon ilişkisini kur (biri etkin, biri pasif). Saatlik hava durumunu yolculuklarla eşleştir. Yolculuk, süre, km, gelir, saat profili, yağmur etkisi, istasyon dengesizliği (çıkış − varış), bisiklet kullanım oranı ve bakım süresi ölçülerini yaz. Sonunda belediyeye sunulacak 4 sayfalık bir rapor tasarla. Her görevin sonucunu paketteki beklenen değerle karşılaştır. Verideki tuzakları da (kapanmamış yolculuklar, aynı anda iki yolculukta görünen bisikletler) bulup raporla.

## Dosyalar

- `veri/` klasörü: CSV tabloları (UTF-8, virgülle ayrılmış, ondalık ayırıcı nokta, tarih YYYY-MM-DD)
- `olcular.dax`: ölçü kütüphanesi
- `gorevler.md`: görevler ve beklenen sonuçlar
- `cozumler.md`: örnek çözümler (önce kendin dene)

## Tablolar

### bk_trips (olgu)

Yolculuklar (116.517) — büyük tablo; kapanmamış yolculukta bitiş alanları boş

| Sütun | Tür | Açıklama |
|---|---|---|
| trip_id | Tam sayı | Yolculuk numarası (anahtar) |
| user_id | Tam sayı | Kullanıcı → bk_users |
| bike_id | Tam sayı | Bisiklet → bk_bikes |
| start_station | Tam sayı | Başlangıç (çıkış) istasyonu → bk_stations (etkin ilişki) |
| end_station | Tam sayı | Bitiş (varış) istasyonu → bk_stations (pasif ilişki); kapanmamışsa boş |
| started_at | Tarih/Saat | Başlangıç zamanı (saniyeli) |
| ended_at | Tarih/Saat | Bitiş zamanı; kapanmamışsa boş |
| distance_km | Ondalık sayı | Yaklaşık mesafe (km); kapanmamışsa boş |
| fare | Sabit ondalık sayı | Ücret (TL); abonede ilk 30 dakika ücretsiz, sonrası 2 TL/dk; tek seferlikte 10 TL + 1,5 TL/dk |

### bk_stations (boyut)

İstasyonlar (62)

| Sütun | Tür | Açıklama |
|---|---|---|
| station_id | Tam sayı | İstasyon numarası (anahtar) |
| name | Metin | İstasyon adı (benzersiz) |
| district | Metin | İlçe / semt (10 ilçe) |
| lat | Ondalık sayı | Enlem (harita görseli için Veri kategorisi: Enlem) |
| lon | Ondalık sayı | Boylam (Veri kategorisi: Boylam) |
| capacity | Tam sayı | Yuva sayısı (15 / 20 / 25 / 30) |
| is_coastal | Tam sayı | Sahil istasyonu (1 = evet, 0 = hayır) |

### bk_bikes (boyut)

Bisikletler (700)

| Sütun | Tür | Açıklama |
|---|---|---|
| bike_id | Tam sayı | Bisiklet numarası (anahtar) |
| model | Metin | klasik / elektrikli |
| commissioned | Tarih | Service’e giriş tarihi |

### bk_users (boyut)

Kullanıcılar (6.000)

| Sütun | Tür | Açıklama |
|---|---|---|
| user_id | Tam sayı | Kullanıcı numarası (anahtar) |
| user_type | Metin | abone / tek seferlik |
| signup_date | Tarih | Kayıt tarihi |
| birth_year | Tam sayı | Doğum yılı (420 kişide boş) |
| gender | Metin | K / E (300 kişide boş) |

### bk_weather (boyut)

Saatlik hava durumu (2.208 saat)

| Sütun | Tür | Açıklama |
|---|---|---|
| obs_hour | Tarih/Saat | Gözlem saati (her zaman saat başı, ör. 2024-06-04 14:00:00) |
| temp_c | Ondalık sayı | Sıcaklık (°C) |
| rain_mm | Ondalık sayı | Yağış (mm/saat); 0 = kuru |
| wind_kmh | Ondalık sayı | Rüzgâr (km/saat) |

### bk_maintenance (olgu)

Bakım kayıtları (1.400; 60’ı hâlâ açık)

| Sütun | Tür | Açıklama |
|---|---|---|
| ticket_id | Tam sayı | Bakım kaydı numarası (anahtar) |
| bike_id | Tam sayı | Bisiklet → bk_bikes |
| opened_at | Tarih/Saat | Kaydın açılışı |
| closed_at | Tarih/Saat | Kaydın kapanışı; bakım sürüyorsa boş |
| issue | Metin | batarya / fren / lastik / zincir / kilit / temizlik |

## Başlamadan önce

1. **Yerel ayar:** CSV’ler ondalık ayırıcı olarak nokta kullanır. Desktop Türkçe yerel ayardaysa yüklerken `-664.74` gibi değerler −66474’e dönüşür. Boş bir dosya açıp Dosya → Seçenekler ve ayarlar → Seçenekler → GEÇERLİ DOSYA → Bölgesel Ayarlar (Regional Settings) → İçeri aktarma için yerel ayar (Locale for import) değerini İngilizce (ABD) yap, sonra veriyi yükle. Ya da Power Query’de otomatik eklenen “Değiştirilen Tür” adımını silip türleri yerel ayarla yeniden ver: `Table.TransformColumnTypes(Kaynak, {{"amount", type number}}, "en-US")`.
2. **Otomatik ilişkileri kapat:** GEÇERLİ DOSYA → Veri Yükleme → İlişkiler altında “Veri yüklendikten sonra yeni ilişkileri otomatik algıla” seçeneğini kaldır. İlişkileri aşağıdaki listeye göre kendin kur; sonra Model → İlişkileri yönet listesini karşılaştır.
3. **Boş hücreler:** Boş tarih ve sayılar tür verilince null olur; boş metin hücreleri boş metin (“”) kalır. Gerekirse Değerleri değiştir ile null yap.
4. **Otomatik tarih/saat:** Kendi Takvim tablonu kullanacağın için GEÇERLİ DOSYA → Veri Yükleme altında “Otomatik tarih/saat” seçeneğini kapat.

## Hazırlık (Power Query)

1. **Verileri al (Get data) → Metin/CSV (Text/CSV)** ile altı dosyayı yükle. Önizlemede **Dönüştür (Transform Data)** diyerek Power Query Düzenleyicisi’ni aç. Dosya kökeni 65001: Unicode (UTF-8) olmalı; yoksa “Karşıyaka”, “Göztepe” gibi adlar bozulur.
2. **Bölgesel ayar:** CSV’de ondalık ayırıcı noktadır. Türkçe bölge ayarlı bir bilgisayarda `13.52` bin üç yüz elli iki olarak okunabilir. Ondalık sütunlarda **Türü değiştir → Yerel ayarı kullanarak (Using Locale…)** seçip İngilizce (Amerika Birleşik Devletleri) ver. Ya da **Dosya → Seçenekler ve ayarlar → Seçenekler → Bölgesel Ayarlar** bölümünden içeri aktarma yerel ayarını değiştir.
3. **Veri türleri:** `started_at`, `ended_at`, `obs_hour`, `opened_at`, `closed_at` → Tarih/Saat; `commissioned`, `signup_date` → Tarih; `fare` → Sabit ondalık sayı; `distance_km`, `lat`, `lon`, hava sütunları → Ondalık sayı. Boş hücreler `null` gelmeli. “Değiştirilen tür” adımında boşların hata vermediğini kontrol et.
4. **Tarih-saati böl (bk_trips):** `started_at` seçiliyken **Sütun ekle (Add Column) → Tarih (Date) → Yalnızca Tarih (Date Only)**, sütunu `Tarih` diye adlandır. Sonra **Sütun ekle → Saat (Time) → Saat (Hour) → Saat (Hour)** ile `Saat` sütununu ekle. M karşılığı: `Table.AddColumn(Kaynak, "Tarih", each DateTime.Date([started_at]), type date)` ve `Table.AddColumn(…, "Saat", each Time.Hour([started_at]), Int64.Type)`.
5. **Aynı bölmeyi bk_weather’da yap:** `obs_hour` → `Tarih` (`DateTime.Date`) ve `Saat` (`Time.Hour`). Hava gözlemi her zaman saat başıdır. Yolculuğun saat başına yuvarlanmış **Tarih + Saat** çifti, gözlemin **Tarih + Saat** çiftiyle birebir eşleşir. Bu iki sütun birlikte birleşik anahtardır.
6. **Birleşik anahtar seçeneği (isteğe bağlı):** Hava ile yolculuk arasında gerçek bir ilişki istersen iki tabloya da tek sütunlu bir anahtar türet: `each DateTime.ToText([started_at], "yyyy-MM-dd HH")` ve hava tarafında `each DateTime.ToText([obs_hour], "yyyy-MM-dd HH")`. Sonra `bk_trips[SaatAnahtari]` → `bk_weather[SaatAnahtari]` çoka-bir ilişkisi kur. Ama dikkat: hava tablosu hem Takvim’e hem yolculuğa bağlanırsa Takvim → hava → yolculuk ve Takvim → yolculuk diye iki yol oluşur; Power BI ikinci ilişkiyi pasif yapar. Bu pakette hava tablosu Takvim’e bağlı kalır. Yolculuk–hava eşleşmesi ölçülerde `TREATAS` (iki sütunla) ya da `LOOKUPVALUE` ile yapılır. Doğrulanabilir görevler bu yolu kullanır.
7. **bk_maintenance:** `opened_at` → **Yalnızca Tarih** ile `AcilisTarih` sütunu ekle (Takvim ilişkisi için).
8. **Büyük tablo performansı:** Kullanmadığın sütunları Power Query’de kaldır (**Giriş → Sütunları Yönet → Sütunları Kaldır**); model belleği sütun sayısı ve benzersiz değer sayısıyla büyür. Saniyeli `started_at` neredeyse her satırda farklıdır ve en pahalı sütundur. Süre hesabı için onu tutuyorsan görsellerde değil yalnız ölçülerde kullan. Daha ileri adım: süreyi Power Query’de `Duration.TotalMinutes([ended_at] - [started_at])` ile `SureDk` sütunu olarak hesapla, sonra `started_at` ve `ended_at` sütunlarını kaldır. Tarih + Saat yeterli. Bu paketteki ölçüler doğrulanabilirlik için ham sütunlarla yazıldı.
9. **Toplama tablosu (aggregation) fikri:** Saat profili ve yağmur analizinin çoğu `Tarih × Saat` düzeyinde yeterlidir. Power Query’de `bk_trips` sorgusunu çoğalt, **Dönüştür → Gruplandırma ölçütü (Group By)** ile Tarih ve Saat’e göre satır say, km ve ücret topla. Sonuç 2.035 satırdır (yaklaşık 57 kat küçük). İstasyonu da gruba eklersen 59.653 satır olur; kazanç ancak 2 katta kalır. **Toplamaları yönet (Manage aggregations)** penceresi ayrıntı tablosunun DirectQuery olmasını ister. İçeri aktarma (Import) modelinde toplama tablosunu ayrı bir tablo olarak tutup ona kendi ölçülerini yazarsın.
10. **Takvim:** **Modelleme → Yeni tablo** ile aşağıdaki DAX’ı yapıştır. Sonra tabloyu seç ve **Tablo araçları (Table tools) → Tarih tablosu olarak işaretle (Mark as date table)** de, tarih sütunu olarak `Tarih`’i seç. `Ay` sütununu seçip **Sütun araçları → Sütuna göre sırala (Sort by column) → AyNo**; `HaftaninGunu` için de **GunNo**.
11. **İlişkiler (Model görünümü):** `bk_trips[start_station]` → `bk_stations[station_id]` etkin, `bk_trips[end_station]` → `bk_stations[station_id]` pasif (çizgi kesikli görünür). `bk_trips[Tarih]`, `bk_weather[Tarih]` ve `bk_maintenance[AcilisTarih]` → `Takvim[Tarih]`. `bike_id` ve `user_id` ilişkileri çoka-bir, tek yönlü. Otomatik algılanan ilişkileri kontrol et; Power BI ikinci istasyon ilişkisini kendiliğinden pasif yapar.
12. **Gizle ve düzenle:** Yabancı anahtarları (`bike_id`, `user_id`, istasyon sütunları, `Tarih`, `AcilisTarih`) rapor görünümünde gizle. Kullanıcılar dilimleyiciyi boyut tablosundan seçsin. Ölçüleri boş bir **_Ölçüler** tablosunda topla ve **Görüntüleme klasörü (Display folder)** ile Temel, Zaman, İstasyon, Hava, Filo klasörlerine ayır. `lat` / `lon` için **Sütun araçları → Veri kategorisi**: Enlem / Boylam.

### Türetilmiş sütunlar

- `bk_trips[Tarih]` ← `started_at` (date): Takvim ilişkisi ve hava eşleşmesinin ilk parçası: başlangıcın yalnız tarihi
- `bk_trips[Saat]` ← `started_at` (hour): Saat profili ve hava eşleşmesinin ikinci parçası: saat başına yuvarlanmış başlangıç (0–23)
- `bk_weather[Tarih]` ← `obs_hour` (date): Hava gözlemini Takvim’e bağlamak ve yolculukla eşleştirmek için tarih
- `bk_weather[Saat]` ← `obs_hour` (hour): Yolculuğun Saat sütunuyla eşleşecek gözlem saati (0–23)
- `bk_maintenance[AcilisTarih]` ← `opened_at` (date): Bakım kayıtlarını Takvim’e bağlamak için açılış tarihi

## Takvim tablosu

Modelleme → Yeni tablo:

```dax
Takvim =
VAR Gunler =
    SELECTCOLUMNS(CALENDAR(DATE(2024, 6, 1), DATE(2024, 8, 31)), "Tarih", [Date])
RETURN
    ADDCOLUMNS(
        Gunler,
        "Yil", YEAR([Tarih]),
        "CeyrekNo", QUARTER([Tarih]),
        "Ceyrek", "Ç" & QUARTER([Tarih]),
        "AyNo", MONTH([Tarih]),
        "Ay", SWITCH(MONTH([Tarih]), 1, "Oca", 2, "Şub", 3, "Mar", 4, "Nis", 5, "May", 6, "Haz", 7, "Tem", 8, "Ağu", 9, "Eyl", 10, "Eki", 11, "Kas", 12, "Ara"),
        "YilAy", YEAR([Tarih]) & "-" & RIGHT("0" & MONTH([Tarih]), 2),
        "Gun", DAY([Tarih]),
        "GunNo", WEEKDAY([Tarih], 2),
        "HaftaninGunu", SWITCH(WEEKDAY([Tarih], 2), 1, "Pazartesi", 2, "Salı", 3, "Çarşamba", 4, "Perşembe", 5, "Cuma", 6, "Cumartesi", 7, "Pazar"),
        "HaftaSonu", IF(WEEKDAY([Tarih], 2) >= 6, "Evet", "Hayır")
    )
```

Takvimi tarih tablosu olarak işaretle (Tablo araçları → Tarih tablosu olarak işaretle → Tarih) ve Ay sütununu AyNo’ya göre sırala.

## Model ve ilişkiler

- `bk_trips[start_station]` → `bk_stations[station_id]`
- `bk_trips[end_station]` → `bk_stations[station_id]` **(pasif)**: İstasyon tablosu rol oynayan bir boyut: aynı iki tablo arasında yalnızca bir etkin yol olabilir. Varış sayıları USERELATIONSHIP ile bu pasif ilişkiyi açar.
- `bk_trips[bike_id]` → `bk_bikes[bike_id]`
- `bk_trips[user_id]` → `bk_users[user_id]`
- `bk_trips[Tarih]` → `Takvim[Tarih]`
- `bk_weather[Tarih]` → `Takvim[Tarih]`
- `bk_maintenance[bike_id]` → `bk_bikes[bike_id]`
- `bk_maintenance[AcilisTarih]` → `Takvim[Tarih]`

## Rapor brifi

**Pedal İzmir — Yaz 2024 Operasyon Raporu** · Belediye ulaşım dairesi, operasyon müdürü, bakım şefi

### Sayfa 1: Genel bakış

Yazın tek bakışta özeti: hacim, gelir, filo ve kalite.

- Kartlar: Yolculuk Sayısı, Gelir, Toplam Km, Ortalama Süre (dk), Bisiklet Kullanım Oranı, Kapanmamış Yolculuk (koşullu biçim: 0’dan büyükse turuncu)
- Çizgi grafik: X = Takvim[Tarih], Y = Yolculuk Sayısı ve 7 Günlük Hareketli Ortalama (hafta sonu dalgası ve yağmurlu günlerdeki çukurlar görünür)
- Kümelenmiş sütun grafik: X = Takvim[Ay], Y = Yolculuk Sayısı; araç ipucunda Aylık Değişim %
- Halka grafik: bk_users[user_type] × Gelir (tek seferlik kullanıcıların gelir payı)

Etkileşimler:

- Takvim[Ay] ve bk_users[user_type] dilimleyicileri, tüm sayfalarda <b>dilimleyici eşitleme (Sync slicers)</b> ile aynı
- Kartlardan “Kapanmamış Yolculuk” kartına <b>detaya git (drill-through)</b> düğmesi: Detay sayfasına götürür

### Sayfa 2: Ne zaman, hangi havada?

Saat profili ve hava etkisi: işe gidiş-geliş kullanımını ve yağmurun bedelini göster.

- Matris ısı haritası: satır = Takvim[HaftaninGunu] (GunNo’ya göre sıralı), sütun = bk_trips[Saat], değer = Yolculuk Sayısı, arka plan rengi koşullu biçimli
- Çizgi grafik: X = bk_trips[Saat], açıklama = Takvim[HaftaSonu], Y = Yolculuk Sayısı (hafta içi iki zirve, hafta sonu tek öğleden sonra tepesi)
- Kartlar: Yağmurlu Saat Sayısı, Yağmurda Saatlik Yolculuk ve kuru saatle kıyas (Yağmur Etkisi % ölçüsü)
- Dağılım grafiği: X = günlük toplam yağış (SUM(bk_weather[rain_mm])), Y = Yolculuk Sayısı, ayrıntı = Takvim[Tarih]

Etkileşimler:

- <b>Alan parametresi (field parameter)</b>: Y eksenini Yolculuk Sayısı / Gelir / Toplam Km arasında değiştir
- <b>Yer işaretleri (bookmarks)</b>: “Hafta içi” ve “Hafta sonu” görünümleri arasında düğmeyle geçiş

### Sayfa 3: İstasyonlar ve denge

Operasyon: hangi istasyondan çıkış, hangisine varış ağır basıyor? Bu veride bisiklet konumu izlenmediği için yöntemi gösterir, kamyon rotası kararı çıkarılmaz.

- Harita (Azure Maps ya da Harita): enlem/boylam = bk_stations[lat]/[lon], kabarcık boyutu = Yolculuk Sayısı, renk = İstasyon Dengesi (ıraksak renk: artı kırmızı, eksi mavi)
- Tablo: bk_stations[name], [district], Yolculuk Sayısı, Varış Sayısı, İstasyon Dengesi, İstasyon Sırası; dengeye göre sıralı, veri çubukları
- Kümelenmiş çubuk: bk_stations[district] × Yolculuk Sayısı ve Varış Sayısı yan yana
- Kart: sahil istasyonlarının çıkış payı (Sahil Çıkış Payı)

Etkileşimler:

- Tablodan istasyona sağ tık → <b>Detaya git</b> ile Detay sayfasına (istasyon filtresi taşınır)
- bk_stations[is_coastal] dilimleyicisi; harita ve tablo birbirini <b>çapraz filtreler</b>

### Sayfa 4: Detay ve veri kalitesi

Detaya git hedefi: seçilen istasyon/bisiklet için yolculuk listesi ve kalite kontrolleri.

- Tablo: trip_id, started_at, ended_at, start/end istasyon adı, bike_id, distance_km, fare (kapanmamışlar ended_at boş olarak en üstte)
- Kartlar: Kapanmamış Yolculuk, Çakışan Yolculuk (seçili bisiklet için), Ortalama Bakım Süresi (saat), açık bakım kaydı sayısı
- Sütun grafik: bk_maintenance[issue] × Ortalama Bakım Süresi (saat)
- <b>Araç ipucu sayfası (tooltip page)</b>: istasyonun üzerine gelince saat profili mini çizgi grafiği ve İstasyon Dengesi

Etkileşimler:

- Detaya git alanları: bk_stations[name], bk_bikes[bike_id]; “Geri” düğmesi otomatik
- Araç ipucu sayfası İstasyonlar sayfasındaki harita ve tabloya bağlanır (Biçim → Araç ipuçları → Tür: Rapor sayfası)

## Veri ve modelleme tuzakları

- **Kapanmamış yolculuklar (316):** ended_at, end_station, distance_km ve fare boş. COUNTROWS bunları sayar, SUM ve varış ölçüleri saymaz. Sonuç olarak toplam çıkış toplam varıştan 316 fazla görünür. Fark etmek için bir “Kapanmamış Yolculuk” kartı koy. Ortalama süre ve ücretin paydasında Tamamlanan Yolculuk kullan.
- **Aynı anda iki yolculukta görünen bisikletler:** 700 bisikletin yalnız 300’ü kayıtlarda geçiyor ve bunlar günde 4’ten fazla, süreleri üst üste binen yolculuk yapıyor (ör. 357 numaralı bisiklet; toplam 18.493 yolculuk önceki yolculuk bitmeden başlıyor, yolculukların %98,5’i bisikletin son bıraktığı istasyondan başlamıyor). Bisiklet bazlı kullanım ve bakım analizleri bu yüzden güvenilmez. Kontrolü bir bisiklet üzerinde DAX ile göster, tüm tablo için kaynak sistemde ya da Power Query’de düzelt ve sorunu veri sahibine raporla.
- **Rol oynayan istasyon:** İki istasyon ilişkisi birden etkin olamaz. İstasyon dilimleyicisi varsayılan olarak yalnız çıkışı filtreler. Varış görselinde USERELATIONSHIP’li ölçü kullanılmazsa “Alsancak’a varış” aslında “Alsancak’tan çıkış” olur. Alternatif: istasyon tablosunu Power Query’de çoğaltıp Çıkış İstasyonu / Varış İstasyonu adlı iki ayrı boyut yapmak.
- **Saatlik hava ile saniyeli yolculuk:** started_at ile obs_hour doğrudan eşleşmez (14:37:12 ≠ 14:00:00). Saat başına yuvarlamadan birleştirirsen neredeyse hiç satır eşleşmez. Tarih + Saat birleşik anahtarını iki tarafta da aynı kuralla türet. Hava tablosunu hem Takvim’e hem yolculuğa bağlamak belirsiz yol yaratır; ilişki yerine TREATAS / LOOKUPVALUE ya da Power Query birleştirmesi kullan.
- **Yağmur karşılaştırmasında saat yanlılığı:** Yağmur yalnız 10:00–19:59 arasında yağdı. Yağmurlu saatleri tüm kuru saatlerle (gece dahil) kıyaslamak etkiyi küçük gösterir. Aynı saat aralığını karşılaştır ya da saat başına normalleştir.
- **Büyük tabloda saniyeli tarih-saat:** started_at ve ended_at neredeyse benzersizdir; sıkıştırılamaz ve model boyutunu şişirir. Görsellerde bu sütunları eksen yapma; Tarih + Saat kullan. Süreyi Power Query’de dakika olarak hesaplayıp ham sütunları kaldırmayı değerlendir.
- **Ücret kuralı ve gelir yorumu:** Abonelerin tamamlanan yolculuklarının yaklaşık %59’u ücretsiz (fare = 0); bu bir hata değil. “Yolculuk başına gelir” ölçüsünü kullanıcı türüne bölmeden sunarsan aboneliğin değeri yanlış anlaşılır. Abonelik ücreti bu veride yok; abone gelirini yalnız aşım ücreti olarak yorumla.

## Portföyde nasıl anlatırsın

- “116 bin satırlık bir mikromobilite verisinde rol oynayan istasyon boyutu kurdum. Çıkış etkin, varış USERELATIONSHIP ile hesaplanıyor. İstasyon dengesizliği (çıkış − varış) ölçüsünü yazdım; bisiklet konumu izlenmeyen bu veride dengeleme kararı çıkmayacağını da not ettim.”
- “Saatlik hava durumunu saniyeli yolculuklarla Tarih + Saat birleşik anahtarıyla eşleştirdim. Aynı saat aralığında kıyaslayınca yağmurun saatlik kullanımı yaklaşık %77 düşürdüğünü gösterdim. Bu, belediyeye yağmurlu günlerde dağıtım ekibini azaltma önerisi oldu.”
- “Büyük tabloda gereksiz sütunları kaldırdım, tarih-saati böldüm. Tarih × Saat toplama tablosunun 116 binden 2 bin satıra indiğini, istasyon eklenince kazancın 2 kata düştüğünü ölçtüm. Toplama düzeyini soruya göre seçmeyi anlatabilirim.”
- “Veri kalitesi denetimiyle filonun yalnız %43’ünün kayıtlarda göründüğünü ve aynı bisikletin aynı anda iki yolculukta olduğunu buldum. Bunu raporda gizlemek yerine ayrı bir kalite sayfasıyla paydaşlara sundum.”
- “Abonelik ücret kuralını (ilk 30 dakika ücretsiz) analiz edip gelirin yaklaşık üçte ikisinin tek seferlik kullanıcılardan geldiğini, ücretli abone yolculuklarının payını gösterdim; fiyatlandırma tartışmasına veri sağladım.”
