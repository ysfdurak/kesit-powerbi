# Ilgaz Bank · örnek çözümler

## Temel

### k1 · Aralık İşlem Sayısı

*İpucu:* Satır sayan temel ölçü yeterli; filtreyi dilimleyici verir.

```dax
Aralık İşlem Sayısı =
[İşlem Sayısı]
```

COUNTROWS(bank_txns) Takvim filtresini bank_txns[Tarih] ilişkisi üzerinden alır. Dilimleyici olmasaydı yılın tamamı (42.284) sayılırdı.

### k2 · Kart Harcama TL

*İpucu:* txn_type = "kart_harcama" ile CALCULATE; tutar eksi olduğu için işareti çevir.

```dax
Kart Harcama TL =
-CALCULATE([Tutar TL], bank_txns[txn_type] = "kart_harcama")
```

Kart harcamaları yalnızca TL vadesiz hesap ve kredi kartlarında olduğu için kur çevrimi sonucu değiştirmez. Çıkışlar eksi kaydedildiği için başa eksi konur.

### k3 · Dijital Pay

*İpucu:* Payda tüm işlemler, pay IN {"mobil", "internet"} filtreli işlemler. DIVIDE kullan.

```dax
Dijital Pay =
DIVIDE(CALCULATE([İşlem Sayısı], bank_txns[channel] IN {"mobil", "internet"}), [İşlem Sayısı])
```

27.660 / 42.284 ≈ %65,4. "sistem" kanalı (faiz) ve "pos" da paydada kalır; payı yalnız müşterinin seçtiği kanallarla ölçmek istersen paydayı ayrıca filtrelemelisin.

### k4 · Aktif Hesap

*İpucu:* Hareket tablosundaki farklı account_id sayısı.

```dax
Aktif Hesap =
DISTINCTCOUNT(bank_txns[account_id])
```

bank_accounts 849 satır; 71 hesap yıl boyunca hiç hareket görmemiş. Aktiflik hesap tablosundan değil hareket tablosundan sayılır.

### k5 · Kapalı Hesap

*İpucu:* bank_accounts üzerinde COUNTROWS ve status filtresi.

```dax
Kapalı Hesap =
CALCULATE(COUNTROWS(bank_accounts), bank_accounts[status] = "kapali")
```

Kapalı hesapların hepsinde closed_date dolu ve 2024 içinde. Bu sayı, ileride "kapanıştan sonra hareket" kontrolünün de tabanıdır.

## Orta

### o1 · Net Akış TL

*İpucu:* Giriş TL − Çıkış TL. Ham SUM(amount) USD ve EUR'yu TL gibi toplar.

```dax
Net Akış TL =
[Giriş TL] - [Çıkış TL]
```

Ham toplam 125.012.817,55 çıkar; aradaki ~625 bin TL fark döviz hesaplarındaki faizin TL karşılığıdır. Kur çevrimi satır bazında yapılmalı, çünkü kur her gün değişir.

### o2 · Aktif Müşteri Sayısı

*İpucu:* customer_id hareket tablosunda yok; ilişki üzerinden hesap sahibine çık. SUMMARIZE(bank_txns, bank_accounts[customer_id]).

```dax
Aktif Müşteri Sayısı =
COUNTROWS(SUMMARIZE(bank_txns, bank_accounts[customer_id]))
```

DISTINCTCOUNT(bank_accounts[customer_id]) hareket filtresi almadan 500 döner; çünkü filtre bank_accounts'tan bank_txns'e akar, tersine akmaz. SUMMARIZE hareket satırlarından hesap sahibine giden ilişkiyi kullanır.

### o3 · Özel Bankacılık Net Akış

*İpucu:* Net Akış TL ölçüsünü olduğu gibi kullan; filtre müşteri → hesap → hareket yönünde akar.

```dax
Özel Bankacılık Net Akış =
[Net Akış TL]
```

Sonuç eksi: bu segmentte maaş ya da gelen havale yok, yalnız harcama ve döviz faizi var. Yani varlıklı müşterilerin ana geliri başka bankaya yatıyor; bu bir ticari bulgu.

### o4 · Ekim Net Akış

*İpucu:* PREVIOUSMONTH(Takvim[Tarih]) ile CALCULATE.

```dax
Ekim Net Akış =
CALCULATE([Net Akış TL], PREVIOUSMONTH(Takvim[Tarih]))
```

PREVIOUSMONTH, Kasım bağlamını Ekim'in tüm günlerine kaydırır. Takvim tarih tablosu olarak işaretli ve kesintisiz olduğu için zaman zekâsı doğru çalışır.

### o5 · Şüpheli İşlem

*İpucu:* Saat sütununu Power Query'de türettin. CALCULATE içine dört koşulu ayrı filtre olarak yaz.

```dax
Şüpheli İşlem =
CALCULATE([İşlem Sayısı], bank_txns[Saat] < 6, bank_txns[channel] = "internet", bank_txns[merchant_category] = "e_ticaret", bank_txns[amount] <= -25000)
```

Normal işlemler 07:00'den önce başlamıyor ve en büyük normal kart harcaması 25.000 TL'nin altında. 25 işlemin toplamı 1.703.500 TL; 3'ü kapanmış hesaplarda, 4'ü kart limitini aşıyor.

### o6 · Ç1 Kapanan Hesap

*İpucu:* USERELATIONSHIP(bank_accounts[closed_date], Takvim[Tarih]) ile CALCULATE.

```dax
Ç1 Kapanan Hesap =
CALCULATE(COUNTROWS(bank_accounts), USERELATIONSHIP(bank_accounts[closed_date], Takvim[Tarih]))
```

Etkin olmayan ilişki olmasaydı Takvim bank_accounts'u hiç filtrelemezdi ve 849 dönerdi. USERELATIONSHIP yalnız bu hesaplama için kapanış tarihini devreye alır.

### o7 · Yoğun Hesap

*İpucu:* VALUES(bank_accounts[account_id]) üzerinde FILTER; her satırda [İşlem Sayısı] bağlam geçişiyle hesaplanır. Segmenti SWITCH(TRUE()) ile ver.

```dax
Yoğun Hesap =
COUNTROWS(
    FILTER(
        VALUES(bank_accounts[account_id]),
        VAR n = [İşlem Sayısı]
        RETURN SWITCH(TRUE(), n >= 80, "Yoğun", n >= 40, "Düzenli", n >= 1, "Seyrek", "Hareketsiz") = "Yoğun"
    )
)
```

Ölçü bir satır bağlamında çağrılınca CALCULATE gibi davranır (bağlam geçişi) ve o hesabın işlemlerini sayar. Dağılım: 55 Yoğun, 544 Düzenli, 179 Seyrek, 71 Hareketsiz.

## İleri

### i1 · Kursuz Döviz İşlemi

*İpucu:* Her hareket için hesabın para birimini ve tarihini VAR ile al; bank_fx'te aynı tarih ve para birimini FILTER ile ara, ISEMPTY ile boş mu bak.

```dax
Kursuz Döviz İşlemi =
COUNTROWS(
    FILTER(
        bank_txns,
        VAR pb = RELATED(bank_accounts[currency])
        VAR gun = bank_txns[Tarih]
        RETURN pb <> "TRY" && ISEMPTY(FILTER(ALL(bank_fx), bank_fx[currency] = pb && bank_fx[rate_date] = gun))
    )
)
```

Faiz ayın son günü işleniyor; 31 Mart, 30 Haziran (Pazar), 31 Ağustos ve 30 Kasım (Cumartesi) hafta sonuna denk geliyor. Bu 308 satır tam eşleşmeyle TL'ye çevrilirse sıfır sayılır; doğru çözüm önceki son iş gününün kurudur.

### i2 · Döviz Hesapları TL

*İpucu:* Tutar TL ölçüsünü para birimi filtresiyle çalıştır: bank_accounts[currency] <> "TRY".

```dax
Döviz Hesapları TL =
CALCULATE([Tutar TL], bank_accounts[currency] <> "TRY")
```

Ham toplam yalnız 19.556 "birim" çıkar ve anlamsızdır. TOPN(1, …, rate_date, DESC) işlem tarihine eşit ya da önceki en son kuru seçer. Tam tarih eşleşmesiyle sonuç 425.705 TL olur; yani ~219 bin TL eksik raporlanırdı.

### i3

*İpucu:* SUMMARIZECOLUMNS(bank_branches[name], "Net", [Net Akış TL]) sonucunu TOPN ile sırala. Filtre müşteri üzerinden şubeye kadar gider.

```dax
EVALUATE
TOPN(
    3,
    SUMMARIZECOLUMNS(bank_branches[name], "Net Akis", [Net Akış TL]),
    [Net Akis], DESC
)
ORDER BY [Net Akis] DESC
```

Dijital Şube, müşterilerin %19'unu (95 kişi) tek başına taşıdığı için ikinciyi iki kat geçiyor. Adil karşılaştırma için Hesap Başına Net Akış ölçüsüyle de sırala.

### i4 · Kapanış Sonrası Hareket

*İpucu:* FILTER(bank_txns, …) içinde RELATED(bank_accounts[closed_date]) ile karşılaştır; boş kapanışları ele.

```dax
Kapanış Sonrası Hareket =
COUNTROWS(
    FILTER(
        bank_txns,
        VAR kapanis = RELATED(bank_accounts[closed_date])
        RETURN NOT ISBLANK(kapanis) && bank_txns[Tarih] > kapanis
    )
)
```

Bir kısmı kaynak sistemin ay sonuna kadar işlem yazmasından (faiz, kart ödemesi) gelen kayıt hatası. Ama 3 tanesi şüpheli gece harcaması: kapalı hesaptan 237.300 TL çıkmış. Bu iki sinyal birlikte en güçlü fraud uyarısıdır.

### i5 · Aralık 3 Ay Ortalama

*İpucu:* DATESINPERIOD(Takvim[Tarih], MAX(Takvim[Tarih]), -3, MONTH) ile ayları al, AVERAGEX ile aylık net akışların ortalamasını bul. Dikkat: AyNo filtresi her ayın hesabına da taşınır.

```dax
Aralık 3 Ay Ortalama =
VAR aylar =
    CALCULATETABLE(VALUES(Takvim[YilAy]), DATESINPERIOD(Takvim[Tarih], MAX(Takvim[Tarih]), -3, MONTH))
RETURN
    AVERAGEX(
        aylar,
        VAR ay = Takvim[YilAy]
        RETURN CALCULATE([Net Akış TL], REMOVEFILTERS(Takvim), Takvim[YilAy] = ay)
    )
```

DATESINPERIOD Aralık'ın son gününden üç ay geriye gider. Tuzak: AyNo = 12 filtresi bağlamda durduğu için [Net Akış TL] ay ay doğrudan çağrılsaydı Ekim ve Kasım boş döner, sonuç yalnız Aralık (10.897.403) olurdu. Bu yüzden her ay REMOVEFILTERS(Takvim) ve YilAy = ay ile yeniden hesaplanır.

### i6 · Limit Aşan Hesap-Ay

*İpucu:* SUMMARIZE(bank_txns, bank_accounts[account_id], Takvim[YilAy]) üzerinde FILTER; her satırda kart harcamasını hesapla ve RELATED olmadan limiti CALCULATE(MAX(bank_accounts[credit_limit])) ile al.

```dax
Limit Aşan Hesap-Ay =
COUNTROWS(
    FILTER(
        CALCULATETABLE(SUMMARIZE(bank_txns, bank_accounts[account_id], Takvim[YilAy]), bank_accounts[account_type] = "kredi_karti"),
        [Kart Harcama TL] > CALCULATE(MAX(bank_accounts[credit_limit]))
    )
)
```

Kaynak sistem limit kontrolü yapmadan harcama yazmış: 10.000 TL limitli kartta 25.000 TL'lik elektronik alışveriş var. Bu bir veri üretim kusuru ya da kontrol açığı; raporda "limit aşımı" ayrı bir uyarı olarak gösterilmeli.
