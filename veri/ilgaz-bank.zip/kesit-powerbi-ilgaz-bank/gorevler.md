# Ilgaz Bank · görevler

Her görevi Power BI Desktop’ta çöz ve sonucunu “Beklenen” değerle karşılaştır. Çözümler cozumler.md dosyasında.

## Temel

### k1 · Aralık İşlem Sayısı

**2024 Aralık** ayında kaç hesap hareketi var? Takvim[AyNo] dilimleyicisinde yalnız 12 seçili.

**Beklenen:** 3.584

### k2 · Kart Harcama TL

2024 yılı boyunca **kart harcamalarının** toplamı kaç TL? Filtre yok.

**Beklenen:** 63.840.506,18 ₺

### k3 · Dijital Pay

Tüm işlemlerin yüzde kaçı **dijital kanaldan** (mobil + internet) yapıldı? 2024 tamamı.

**Beklenen:** %65,41

### k4 · Aktif Hesap

2024 içinde **en az bir hareketi olan** kaç hesap var?

**Beklenen:** 778

### k5 · Kapalı Hesap

Hesap tablosunda durumu **kapali** olan kaç hesap var?

**Beklenen:** 43

## Orta

### o1 · Net Akış TL

2024 yılı **net nakit akışı** TL karşılığıyla kaç TL? Döviz hesaplarını işlem gününün (yoksa önceki son iş gününün) kuruyla çevir.

**Beklenen:** 125.637.882,7655 ₺

### o2 · Aktif Müşteri Sayısı

2024'te en az bir hesabında hareket olan kaç **aktif müşteri** var?

**Beklenen:** 484

### o3 · Özel Bankacılık Net Akış

**Özel Bankacılık** segmentinin 2024 net akışı kaç TL? bank_customers[segment] dilimleyicisinde yalnız bu segment seçili.

**Beklenen:** -1.877.592,633 ₺

### o4 · Ekim Net Akış

Rapor **Kasım 2024** filtresindeyken (Takvim[AyNo] = 11) "önceki ay net akış" kartı kaç TL göstermeli?

**Beklenen:** 10.030.242,0303 ₺

### o5 · Şüpheli İşlem

Fraud ekibinin kuralı: **gece 00:00–05:59**, **internet** kanalı, **e-ticaret** kategorisi ve tek seferde **25.000 TL ve üstü** harcama. 2024'te kurala uyan kaç işlem var?

**Beklenen:** 25

### o6 · Ç1 Kapanan Hesap

**2024 Ç1**'de kaç hesap kapandı? Takvim[CeyrekNo] = 1 seçili. Kapanış tarihi etkin olmayan ilişkide.

**Beklenen:** 17

### o7 · Yoğun Hesap

Hesapları yıllık işlem sayısına göre segmentle: **80 ve üstü "Yoğun"**, 40–79 "Düzenli", 1–39 "Seyrek", 0 "Hareketsiz". Kaç hesap **Yoğun**?

**Beklenen:** 55

## İleri

### i1 · Kursuz Döviz İşlemi

Veri kalitesi: döviz (USD/EUR) hesaplarındaki hareketlerden kaçının **işlem gününde kur kaydı yok**? (LOOKUPVALUE ile tam tarih eşleştirmesi boş dönerdi.)

**Beklenen:** 308

### i2 · Döviz Hesapları TL

Hazine soruyor: **USD ve EUR hesaplarındaki** tüm 2024 hareketlerinin TL karşılığı kaç TL? Hafta sonu işlemlerinde önceki son iş günü kurunu kullan.

**Beklenen:** 644.621,2155 ₺

### i3

Şube performansı: 2024 **net akışına göre ilk 3 şube** hangileri ve net akışları kaç TL?

**Beklenen:** `Dijital Şube · 26.162.286,4219`, `Alsancak Şubesi · 12.888.046,3749`, `Nilüfer Şubesi · 11.464.384,3853`

### i4 · Kapanış Sonrası Hareket

Kapanış tarihinden **sonra** hareket görmüş kaç işlem satırı var? (Kapanış günü sayılmaz.)

**Beklenen:** 84

### i5 · Aralık 3 Ay Ortalama

**Aralık 2024** için son üç ayın (Ekim–Kasım–Aralık) aylık net akış **hareketli ortalaması** kaç TL? Takvim[AyNo] = 12 seçili.

**Beklenen:** 10.473.450,4912 ₺

### i6 · Limit Aşan Hesap-Ay

Kredi kartlarında **aylık kart harcaması limiti aşan** kaç hesap-ay var? (Bir kart Mart'ta ve Nisan'da aşarsa 2 sayılır.)

**Beklenen:** 231
